import { build } from 'esbuild';
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const result = await build({
  entryPoints: [path.join(root, 'src/app.js')], bundle: true, write: false,
  format: 'iife', target: ['chrome120'], minify: false,
  loader: { '.wgsl': 'text' }, legalComments: 'inline', metafile: true,
});
const js = result.outputFiles[0].text;
const css = await readFile(path.join(root, 'src/styles.css'), 'utf8');
const template = await readFile(path.join(root, 'src/index.html'), 'utf8');
if (/\bimport\s*\(/.test(js)) throw new Error('Unbundled dynamic import in offline artifact');
if (/<script\b[^>]+src=|<link\b[^>]+href=|<img\b[^>]+src=["']https?:/i.test(template)) throw new Error('External HTML asset');
if (/url\(\s*["']?https?:/i.test(css)) throw new Error('External CSS asset');
const html = template.replace('/* INLINE_STYLES */', css).replace('/* INLINE_APPLICATION */', () => js.replace(/<\/script/gi, '<\\/script'));
await writeFile(path.join(root, 'cloth-studio.html'), html, 'utf8');
console.log(`Built cloth-studio.html — ${(Buffer.byteLength(html) / 1024).toFixed(1)} KiB, ${Object.keys(result.metafile.inputs).length} bundled sources, no runtime dependencies.`);
