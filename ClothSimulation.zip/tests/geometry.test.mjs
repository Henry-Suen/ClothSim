import test from 'node:test';
import assert from 'node:assert/strict';
import { BODY_PRESETS, DENSITIES, generateHumanoid, normalizeBodyWeights, validateMesh } from '../src/geometry.js';
import { evaluateRig, skinCPU } from '../src/rig.js';

const regular = generateHumanoid();

for (const { id } of BODY_PRESETS) {
  test(`${id}: one closed, outward-wound manifold with normalized skin weights`, () => {
    const mesh = id === 'regular' ? regular : generateHumanoid({ preset: id });
    const report = validateMesh(mesh);
    assert.deepEqual(report.errors, []);
    assert.equal(report.valid, true);
    assert.equal(report.eulerCharacteristic, 2);
    assert.equal(report.components, 1);
    assert.ok(report.volume > .025 && report.volume < .2);
    assert.equal(mesh.restVolume, report.volume);
    assert.equal(mesh.positions.length, mesh.vertexCount * 4);
    assert.equal(mesh.normals.length, mesh.positions.length);
    assert.equal(mesh.indices.length, mesh.triangleCount * 3);
    for (let i = 0; i < mesh.vertexCount; i++) {
      assert.equal(mesh.positions[i * 4 + 3], 1);
      const norm = Math.hypot(...mesh.normals.subarray(i * 4, i * 4 + 3));
      assert.ok(Math.abs(norm - 1) < 1e-5);
    }
  });
}

test('preset and slit changes preserve face identity and corner ordering', () => {
  for (const { id } of BODY_PRESETS) {
    const mesh = id === 'regular' ? regular : generateHumanoid({ preset: id });
    assert.deepEqual(mesh.indices, regular.indices, `${id} must preserve surface attachment indices`);
  }
  const slit = generateHumanoid({ seam: true }), duplicates = new Map();
  for (let i = 0; i < slit.seamPairs.length; i += 2) duplicates.set(slit.seamPairs[i + 1], slit.seamPairs[i]);
  const canonical = slit.indices.map(id => duplicates.get(id) ?? id);
  assert.deepEqual(canonical, regular.indices);
  for (let i = 0; i < regular.indices.length; i += 6) {
    assert.equal(regular.indices[i], regular.indices[i + 3]);
    assert.equal(regular.indices[i + 2], regular.indices[i + 4]);
  }
});

test('all subdivisions preserve the digits and closed topology', () => {
  const counts = [];
  for (const { id } of DENSITIES) {
    const mesh = id === 0 ? regular : generateHumanoid({ density: id });
    counts.push(mesh.vertexCount);
    assert.equal(validateMesh(mesh).valid, true);
    assert.equal(mesh.metadata.digitCount.fingers, 10);
    assert.equal(mesh.metadata.digitCount.toes, 10);
    for (const suffix of ['L', 'R']) {
      for (const name of ['thumb', 'index', 'middle', 'ring', 'little', 'toe1', 'toe2', 'toe3', 'toe4', 'toe5']) {
        const bone = mesh.bones.findIndex(b => b.name === `${name}.${suffix}`);
        assert.ok(bone >= 0);
        let supported = 0;
        for (let vertex = 0; vertex < mesh.vertexCount; vertex++) for (let k = 0; k < 4; k++) {
          if (mesh.boneIndices[vertex * 4 + k] === bone && mesh.boneWeights[vertex * 4 + k] > .5) supported++;
        }
        assert.ok(supported >= 20, `${name}.${suffix} must have its own surface`);
      }
    }
  }
  assert.deepEqual(counts, [4860, 19434, 77730]);
});

test('nose is modeled in the connected shell and front is positive Z', () => {
  let noseFront = -Infinity, minimumY = Infinity, maximumY = -Infinity;
  for (let i = 0; i < regular.vertexCount; i++) {
    const [x, y, z] = regular.positions.subarray(i * 4, i * 4 + 3);
    if (Math.abs(x) < .015 && y > 1.69 && y < 1.745) noseFront = Math.max(noseFront, z);
    minimumY = Math.min(minimumY, y); maximumY = Math.max(maximumY, y);
  }
  assert.ok(noseFront > .112);
  assert.ok(minimumY >= -.01 && minimumY < .025);
  assert.ok(maximumY > 1.875 && maximumY <= 1.9);
});

test('optional spine slit is a single intentional boundary with coincident seam pairs', () => {
  for (const density of [0, 1, 2]) {
    const mesh = generateHumanoid({ density, seam: true });
    const report = validateMesh(mesh);
    assert.equal(report.valid, true, report.errors.join('; '));
    assert.equal(report.eulerCharacteristic, 1);
    assert.equal(report.boundaryEdges, 16 * 2 ** density);
    assert.equal(mesh.seamPairs.length / 2, 8 * 2 ** density - 1);
    for (let i = 0; i < mesh.seamPairs.length; i += 2) {
      const a = mesh.seamPairs[i], b = mesh.seamPairs[i + 1];
      assert.deepEqual(mesh.positions.slice(a * 4, a * 4 + 4), mesh.positions.slice(b * 4, b * 4 + 4));
      assert.ok(mesh.positions[a * 4 + 1] > mesh.metadata.boxerMax);
      assert.ok(mesh.positions[a * 4 + 2] < 0);
    }
  }
});

test('preset mass volumes follow the intended silhouettes', () => {
  const volumes = Object.fromEntries(BODY_PRESETS.map(({ id }) => [id, generateHumanoid({ preset: id }).restVolume]));
  assert.ok(volumes.fat > volumes.chubby);
  assert.ok(volumes.chubby > volumes.regular);
  assert.ok(volumes.muscular > volumes.regular);
  assert.ok(volumes.regular > volumes.skinny);
});

test('stand skin transforms are identity and root translation is column major', () => {
  const standing = evaluateRig(regular);
  const skinned = skinCPU(regular, standing.matrices);
  for (let i = 0; i < skinned.length; i++) assert.ok(Math.abs(skinned[i] - regular.positions[i]) < 2e-7);
  const root = [.12, .5, -.3], translated = evaluateRig(regular, { root });
  const moved = skinCPU(regular, translated.matrices);
  for (let i = 0; i < regular.vertexCount; i++) for (let k = 0; k < 3; k++) {
    assert.ok(Math.abs(moved[i * 4 + k] - regular.positions[i * 4 + k] - root[k]) < 4e-7);
  }
  assert.equal(translated.matrices.length, regular.bones.length * 16);
});

test('FK posing preserves parent-child lengths and moves only descendants', () => {
  const posed = evaluateRig(regular, { pose: { 'upperArm.L': [25, 0, 35], 'head': [0, 40, 0] } });
  const rest = evaluateRig(regular);
  regular.bones.forEach((bone, index) => {
    if (bone.parent < 0) return;
    const restLength = Math.hypot(...bone.position.map((p, axis) => p - regular.bones[bone.parent].position[axis]));
    const posedLength = Math.hypot(...posed.joints[index].map((p, axis) => p - posed.joints[bone.parent][axis]));
    assert.ok(Math.abs(restLength - posedLength) < 1e-10);
  });
  const left = regular.bones.findIndex(b => b.name === 'hand.L');
  const right = regular.bones.findIndex(b => b.name === 'hand.R');
  assert.notDeepEqual(posed.joints[left], rest.joints[left]);
  assert.deepEqual(posed.joints[right], rest.joints[right]);
});

test('walk loops, speed scales phase, sit eases and then holds', () => {
  const walk = evaluateRig(regular, { clip: 'walk', time: .34 });
  const faster = evaluateRig(regular, { clip: 'walk', time: .17, speed: 2 });
  assert.deepEqual(walk.matrices, faster.matrices);
  assert.notDeepEqual(walk.matrices, evaluateRig(regular).matrices);
  const sitStart = evaluateRig(regular, { clip: 'sit', time: 0 });
  assert.deepEqual(sitStart.matrices, evaluateRig(regular).matrices);
  const sitHalf = evaluateRig(regular, { clip: 'sit', time: 1 });
  const sitEnd = evaluateRig(regular, { clip: 'sit', time: 2 });
  assert.deepEqual(sitEnd.matrices, evaluateRig(regular, { clip: 'sit', time: 5 }).matrices);
  assert.ok(sitHalf.joints[0][1] < sitStart.joints[0][1]);
  assert.ok(sitEnd.joints[0][1] < sitHalf.joints[0][1]);
  const hip = regular.bones.findIndex(b => b.name === 'thigh.L');
  const knee = regular.bones.findIndex(b => b.name === 'shin.L');
  assert.ok(Math.abs(sitEnd.joints[hip][1] - sitEnd.joints[knee][1]) < .02);
  assert.ok(sitEnd.joints[knee][2] > sitEnd.joints[hip][2] + .35);
});

function surfaceIntersections(mesh) {
  const bins = new Map(), triangles = [], cell = .035 / 2 ** mesh.metadata.density;
  const p = id => Array.from(mesh.positions.subarray(id * 4, id * 4 + 3));
  const sub = (a, b) => a.map((v, i) => v - b[i]);
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const dot = (a, b) => a.reduce((sum, v, i) => sum + v * b[i], 0);
  const intersects = (start, end, triangle) => {
    const direction = sub(end, start), e1 = sub(triangle[1], triangle[0]), e2 = sub(triangle[2], triangle[0]);
    const h = cross(direction, e2), determinant = dot(e1, h);
    if (Math.abs(determinant) < 1e-13) return false;
    const s = sub(start, triangle[0]), u = dot(s, h) / determinant;
    if (u < 1e-7 || u > 1 - 1e-7) return false;
    const q = cross(s, e1), v = dot(direction, q) / determinant;
    if (v < 1e-7 || u + v > 1 - 1e-7) return false;
    const t = dot(e2, q) / determinant;
    return t > 1e-7 && t < 1 - 1e-7;
  };
  for (let i = 0; i < mesh.indices.length; i += 3) {
    const ids = Array.from(mesh.indices.subarray(i, i + 3)), points = ids.map(p), index = triangles.length;
    const min = [0, 1, 2].map(k => Math.min(...points.map(p => p[k])));
    const max = [0, 1, 2].map(k => Math.max(...points.map(p => p[k])));
    triangles.push({ ids, points, min, max });
    for (let x = Math.floor(min[0] / cell); x <= Math.floor(max[0] / cell); x++) {
      for (let y = Math.floor(min[1] / cell); y <= Math.floor(max[1] / cell); y++) {
        for (let z = Math.floor(min[2] / cell); z <= Math.floor(max[2] / cell); z++) {
          const key = `${x},${y},${z}`, list = bins.get(key) || [];
          list.push(index); bins.set(key, list);
        }
      }
    }
  }
  const checked = new Set(), result = [];
  for (const list of bins.values()) for (let i = 0; i < list.length; i++) for (let j = i + 1; j < list.length; j++) {
    const first = list[i], second = list[j], key = first * triangles.length + second;
    if (checked.has(key)) continue;
    checked.add(key);
    const a = triangles[first], b = triangles[second];
    if (a.ids.some(id => b.ids.includes(id))) continue;
    if ([0, 1, 2].some(k => a.max[k] < b.min[k] || b.max[k] < a.min[k])) continue;
    let hit = false;
    for (let k = 0; k < 3 && !hit; k++) hit = intersects(a.points[k], a.points[(k + 1) % 3], b.points) || intersects(b.points[k], b.points[(k + 1) % 3], a.points);
    if (hit) result.push({ triangles: [first, second], center: a.points[0].map((v, k) => (v + a.points[1][k] + a.points[2][k]) / 3) });
  }
  return result;
}

test('rest surfaces have no non-adjacent penetrating triangles', () => {
  for (const { id } of BODY_PRESETS) {
    const mesh = id === 'regular' ? regular : generateHumanoid({ preset: id });
    const intersections = surfaceIntersections(mesh);
    assert.equal(intersections.length, 0, `${id}: ${JSON.stringify(intersections.slice(0, 12))}`);
  }
  for (const density of [1, 2]) {
    const intersections = surfaceIntersections(generateHumanoid({ density }));
    assert.equal(intersections.length, 0, `density ${density}: ${JSON.stringify(intersections.slice(0, 12))}`);
  }
});

test('body weights sanitize invalid entries, normalize safely and use an explicit fallback', () => {
  assert.deepEqual(normalizeBodyWeights(), { fat: 0, chubby: 0, muscular: 0, regular: 1, skinny: 0 });
  assert.deepEqual(normalizeBodyWeights({ fat: -4, chubby: NaN, muscular: Infinity, skinny: '4' }, 'chubby'), { fat: 0, chubby: 1, muscular: 0, regular: 0, skinny: 0 });
  assert.deepEqual(normalizeBodyWeights({ fat: 2, muscular: 6 }), { fat: .25, chubby: 0, muscular: .75, regular: 0, skinny: 0 });
  assert.deepEqual(normalizeBodyWeights({ fat: Number.MAX_VALUE, skinny: Number.MAX_VALUE }), { fat: .5, chubby: 0, muscular: 0, regular: 0, skinny: .5 });
  assert.equal(normalizeBodyWeights(null, 'unknown').regular, 1);
  assert.deepEqual(BODY_PRESETS.map(preset => preset.label), ['肥胖', '壮胖', '肌肉', '标准', '纤瘦']);
  assert.deepEqual(DENSITIES.map(density => density.label), ['低', '中', '高']);
});

test('one-hot body morphs equal their endpoint meshes and preserve seam identity', () => {
  for (const { id } of BODY_PRESETS) {
    const original = generateHumanoid({ preset: id, seam: true });
    const morph = generateHumanoid({ bodyWeights: { [id]: 7 }, seam: true });
    for (const key of ['positions', 'indices', 'normals', 'boneIndices', 'boneWeights', 'seamPairs']) assert.deepEqual(morph[key], original[key]);
    assert.deepEqual(morph.bones, original.bones);
    assert.equal(morph.metadata.bodyWeights[id], 1);
    assert.equal(morph.metadata.topologyVersion, 1);
  }
});

test('body morphs linearly blend every corresponding vertex and bone rest position', () => {
  const weights = { fat: 1, chubby: 2, muscular: 3, regular: 4, skinny: 5 };
  const mesh = generateHumanoid({ bodyWeights: weights });
  const endpoints = BODY_PRESETS.map(({ id }) => ({ mesh: generateHumanoid({ preset: id }), weight: mesh.metadata.bodyWeights[id] }));
  assert.deepEqual(mesh.indices, regular.indices);
  assert.deepEqual(mesh.boneWeights, regular.boneWeights);
  assert.deepEqual(mesh.boneIndices, regular.boneIndices);
  for (let i = 0; i < mesh.positions.length; i += 4) {
    assert.equal(mesh.positions[i + 3], 1);
    for (let k = 0; k < 3; k++) {
      const expected = Math.fround(endpoints.reduce((sum, endpoint) => sum + endpoint.mesh.positions[i + k] * endpoint.weight, 0));
      assert.equal(mesh.positions[i + k], expected);
    }
    assert.ok(Math.abs(Math.hypot(...mesh.normals.subarray(i, i + 3)) - 1) < 1e-6);
  }
  mesh.bones.forEach((bone, index) => bone.position.forEach((value, axis) => {
    assert.equal(value, endpoints.reduce((sum, endpoint) => sum + endpoint.mesh.bones[index].position[axis] * endpoint.weight, 0));
  }));
  assert.deepEqual(validateMesh(mesh).errors, []);
  assert.equal(validateMesh(mesh).volume, mesh.restVolume);
  const rest = skinCPU(mesh, evaluateRig(mesh).matrices);
  rest.forEach((value, index) => assert.ok(Math.abs(value - mesh.positions[index]) < 2e-7));
});

test('anatomical silhouettes separate belly mass from muscle and preserve a heel', () => {
  const measures = {};
  for (const { id } of BODY_PRESETS) {
    const mesh = generateHumanoid({ preset: id });
    const shoulder = mesh.bones.find(bone => bone.name === 'upperArm.L').position;
    const elbow = mesh.bones.find(bone => bone.name === 'forearm.L').position;
    const armX = (shoulder[0] + elbow[0]) / 2, armY = (shoulder[1] + elbow[1]) / 2;
    const shape = { belly: -Infinity, chest: -Infinity, arm: -Infinity, heel: Infinity };
    for (let i = 0; i < mesh.positions.length; i += 4) {
      const [x, y, z] = mesh.positions.subarray(i, i + 3);
      if (y > 1.02 && y < 1.15 && Math.abs(x) < .06) shape.belly = Math.max(shape.belly, z);
      if (y > 1.37 && y < 1.44 && Math.abs(x) > .04 && Math.abs(x) < .15) shape.chest = Math.max(shape.chest, z);
      if (Math.abs(x - armX) < .03 && Math.abs(y - armY) < .06) shape.arm = Math.max(shape.arm, z);
      if (y < .07) shape.heel = Math.min(shape.heel, z);
    }
    measures[id] = shape;
    assert.ok(shape.heel < -.018, `${id} retains a rounded heel behind the ankle`);
    assert.ok(shoulder[1] > 1.48);
    assert.ok(mesh.metadata.headSize[1] <= .12);
  }
  assert.ok(measures.fat.belly > measures.fat.chest + .08);
  assert.ok(measures.chubby.belly > measures.chubby.chest + .03);
  assert.ok(measures.muscular.chest > measures.muscular.belly + .03);
  assert.ok(measures.muscular.arm > measures.regular.arm * 1.5);
  assert.ok(measures.chubby.arm > measures.regular.arm * 1.3);
  // 收窄肩口后，旧采样窗口的上臂前缘比例由1.50降至约1.49；仍约束明显的体量差。
  assert.ok(measures.fat.arm > measures.regular.arm * 1.45);
  assert.ok(measures.skinny.arm < measures.regular.arm * .8);
  assert.ok(measures.skinny.belly < measures.regular.belly * .8);
});

test('fat soft tissue stays broad, rounded and pendulous without sharp Gaussian peaks', () => {
  const mesh = generateHumanoid({ preset: 'fat', density: 1 });
  const points = Array.from({ length: mesh.vertexCount }, (_, i) => Array.from(mesh.positions.subarray(i * 4, i * 4 + 3)));
  const region = (y0, y1, x0, x1) => points.filter(([x, y, z]) => y >= y0 && y < y1 && Math.abs(x) >= x0 && Math.abs(x) < x1 && z > 0);
  const front = (y0, y1, x0, x1) => Math.max(...region(y0, y1, x0, x1).map(p => p[2]));
  const chestPeak = region(1.31, 1.45, .035, .15).reduce((a, b) => b[2] > a[2] ? b : a);
  assert.ok(chestPeak[2] > .23 && chestPeak[2] < .27, '肥胖胸部应壮硕但不可形成向前尖锥');
  assert.ok(chestPeak[1] > 1.30 && chestPeak[1] < 1.38, '胸部体量应保持在下垂的下胸区域');
  const inner = front(1.33, 1.37, .025, .055);
  const middle = front(1.33, 1.37, .055, .085);
  const outer = front(1.33, 1.37, .085, .115);
  const chestCurvature = inner + outer - 2 * middle;
  assert.ok(inner / outer > .90, '胸廓横向应宽而连续，不可只在乳腺中心隆起');
  assert.ok(chestCurvature > -.012 && chestCurvature < .006, `胸部横向二阶差分应平缓: ${chestCurvature}`);

  const bellyPeak = region(.96, 1.15, 0, .06).reduce((a, b) => b[2] > a[2] ? b : a);
  assert.ok(bellyPeak[2] > .34 && bellyPeak[2] < .38, '腹部应保留圆润充盈的体量');
  assert.ok(bellyPeak[1] < 1.04, '腹部最大突出点应低垂而非上提');
  const lower = front(.98, 1.02, 0, .035);
  const center = front(1.02, 1.06, 0, .035);
  const upper = front(1.06, 1.10, 0, .035);
  const bellyCurvature = lower + upper - 2 * center;
  assert.ok(bellyCurvature > -.032 && bellyCurvature < .005, `腹部纵向二阶差分应圆滑且无尖锐褶皱: ${bellyCurvature}`);
});

test('lower head rings form a continuous jaw with chin, angle and submental recess', () => {
  for (const { id } of BODY_PRESETS) {
    const mesh = generateHumanoid({ preset: id, density: 1 });
    const points = Array.from({ length: mesh.vertexCount }, (_, i) => Array.from(mesh.positions.subarray(i * 4, i * 4 + 3)));
    const maximum = (filter, axis = 2) => Math.max(...points.filter(filter).map(p => p[axis]));
    const chin = maximum(([x, y, z]) => Math.abs(x) < .022 && y > 1.655 && y < 1.690 && z > 0);
    const submental = maximum(([x, y, z]) => Math.abs(x) < .022 && y > 1.630 && y < 1.648 && z > 0);
    const jawPad = maximum(([x, y, z]) => Math.abs(x) > .035 && Math.abs(x) < .065 && y > 1.655 && y < 1.700 && z > 0);
    const jawAngle = maximum(([x, y, z]) => Math.abs(x) > .055 && Math.abs(x) < .085 && y > 1.645 && y < 1.690 && z > -.02 && z < .065);
    assert.ok(chin > .112 && chin < .150, `${id} 颏尖应明确但不过度前突`);
    assert.ok(chin - submental > .038, `${id} 颏下必须形成可辨识的下缘凹`);
    assert.ok(jawPad > .105 && chin / jawPad < 1.25, `${id} 下巴与下颌体应宽缓连续而非尖下巴`);
    assert.ok(jawAngle > .048 && jawPad - jawAngle > .035, `${id} 下颌角应位于下颌体后下方`);
    const head = mesh.bones.findIndex(bone => bone.name === 'head');
    let lowerHeadVertices = 0;
    for (let i = 0; i < mesh.vertexCount; i++) {
      const y = mesh.positions[i * 4 + 1];
      if (y <= 1.641 || y >= 1.690) continue;
      for (let k = 0; k < 4; k++) if (mesh.boneIndices[i * 4 + k] === head && mesh.boneWeights[i * 4 + k] > .99) {
        lowerHeadVertices++;
        break;
      }
    }
    assert.ok(lowerHeadVertices > 100, `${id} row8/9 下颌表面必须随 head 局部构造变形`);
  }
});

test('narrower shoulders, distinct neck and chin, covered pelvis and thin arched soles retain anatomical proportions', () => {
  const order = ['skinny', 'regular', 'muscular', 'chubby', 'fat'];
  const oldShoulderBones = { skinny: .4042, regular: .46624, muscular: .56212, chubby: .52076, fat: .56776 };
  const oldShoulderSurfaces = { skinny: .584931, regular: .717903, muscular: .883745, chubby: .815833, fat: .898025 };
  let previousBoneWidth = 0, previousSurfaceWidth = 0;
  for (const preset of order) {
    const mesh = generateHumanoid({ preset, density: 1 });
    const points = Array.from({ length: mesh.vertexCount }, (_, i) => Array.from(mesh.positions.subarray(i * 4, i * 4 + 3)));
    const maximum = (filter, axis) => Math.max(...points.filter(filter).map(p => p[axis]));
    const minimum = (filter, axis) => Math.min(...points.filter(filter).map(p => p[axis]));
    const boneWidth = mesh.bones.find(bone => bone.name === 'upperArm.L').position[0] * 2;
    const surfaceWidth = maximum(([, y]) => y > 1.44 && y < 1.54, 0) * 2;
    assert.ok(boneWidth > previousBoneWidth && boneWidth < oldShoulderBones[preset] * .88, `${preset} 肩骨需逐渐变宽且比旧值至少窄12%`);
    assert.ok(surfaceWidth > previousSurfaceWidth + .002 && surfaceWidth < oldShoulderSurfaces[preset] * .93, `${preset} 肩表面需随体型变宽且比旧值至少窄7%`);
    assert.ok(surfaceWidth < .83, `${preset} 最宽端点也需明显小于旧最宽肩部`);
    previousBoneWidth = boneWidth; previousSurfaceWidth = surfaceWidth;

    const lowerNeck = maximum(([, y]) => y > 1.591 && y < 1.607, 0) * 2;
    const upperNeck = maximum(([, y]) => y > 1.623 && y < 1.638, 0) * 2;
    const chin = maximum(([x, y]) => Math.abs(x) < .022 && y > 1.646 && y < 1.682, 2);
    const throat = maximum(([x, y]) => Math.abs(x) < .022 && y > 1.6 && y < 1.633, 2);
    assert.ok(lowerNeck < .16 && Math.abs(lowerNeck - upperNeck) < .020, `${preset} 上下颈截面应形成独立颈柱而不是宽肩梯形`);
    assert.ok(chin > .098 && chin - throat > .022, `${preset} 下巴必须突出于颈前缘`);
    assert.deepEqual(mesh.metadata.headCenter, [0, 1.766, -.008]);
    assert.deepEqual(mesh.metadata.faceLandmarks, { eyeY: 1.774, mouthY: 1.695, noseY: 1.738, chinY: 1.646 });

    const pelvis = maximum(([x, y]) => Math.abs(x) < .025 && y > .87 && y < .925, 2);
    const pelvisSide = maximum(([x, y]) => Math.abs(x) > .05 && Math.abs(x) < .075 && y > .87 && y < .925, 2);
    assert.ok(pelvis - pelvisSide > .010 && pelvis - pelvisSide < .025, `${preset} 衣物覆盖区域应有克制的圆滑曲面`);
    if (preset === 'fat') {
      const belly = maximum(([x, y]) => Math.abs(x) < .06 && y > 1.02 && y < 1.15, 2);
      const chest = maximum(([x, y]) => Math.abs(x) > .04 && Math.abs(x) < .15 && y > 1.37 && y < 1.44, 2);
      assert.ok(belly > .32 && chest > .20 && belly - chest > .10, '肥胖端点的腹部和胸部须分别形成明显体积');
    }
    for (const side of [-1, 1]) {
      const ankleX = mesh.bones.find(bone => bone.name === `foot.${side > 0 ? 'L' : 'R'}`).position[0];
      const foot = ([x, y]) => x * side > 0 && y < .09;
      const footLength = maximum(foot, 2) - minimum(foot, 2);
      const footWidth = maximum(foot, 0) - minimum(foot, 0);
      assert.ok(footLength > .21 && footLength < .238 && footLength / footWidth < 2.25, `${preset} 足部不应呈细长拖鞋轮廓`);
      const heel = minimum(([x, y, z]) => x * side > 0 && y < .08 && z < .01, 1);
      const sole = minimum(([x, y, z]) => x * side > 0 && y < .07 && z > .12 && z < .17, 1);
      const top = maximum(([x, y, z]) => x * side > 0 && y < .10 && z > .12 && z < .17, 1);
      const medial = minimum(([x, y, z]) => (x - ankleX) * side > -.04 && (x - ankleX) * side < -.012 && y < .07 && z > .025 && z < .085, 1);
      const lateral = minimum(([x, y, z]) => (x - ankleX) * side > .012 && (x - ankleX) * side < .04 && y < .07 && z > .025 && z < .085, 1);
      assert.ok(sole > .010 && sole < .016 && Math.abs(heel - sole) < .005, `${preset} 足跟及前掌承重面应接近平坦`);
      assert.ok(top - sole > .025 && top - sole < .050, `${preset} 前掌应薄而不退化为平板`);
      assert.ok(medial > lateral + .004 && medial < lateral + .012, `${preset} 应保留轻微内侧足弓`);
    }
  }
});

test('seated shoulder weights distribute bending without pulling the neck column', () => {
  for (const density of [0, 1]) for (const { id } of BODY_PRESETS) {
    const mesh = generateHumanoid({ preset: id, density });
    const seated = skinCPU(mesh, evaluateRig(mesh, { clip: 'sit', time: 2 }).matrices);
    let shoulderEdges = 0, neckEdges = 0;
    for (let i = 0; i < mesh.indices.length; i += 3) for (let k = 0; k < 3; k++) {
      const a = mesh.indices[i + k] * 4, b = mesh.indices[i + (k + 1) % 3] * 4;
      const x = (mesh.positions[a] + mesh.positions[b]) / 2, y = (mesh.positions[a + 1] + mesh.positions[b + 1]) / 2;
      if (y < 1.35 || y > 1.68) continue;
      const restLength = Math.hypot(...[0, 1, 2].map(axis => mesh.positions[a + axis] - mesh.positions[b + axis]));
      const posedLength = Math.hypot(...[0, 1, 2].map(axis => seated[a + axis] - seated[b + axis]));
      if (Math.abs(x) > .10 && y < 1.57) {
        assert.ok(posedLength / restLength < 1.85, `${id}/${density} 坐姿肩口不可由单条窄环承担拉伸`);
        shoulderEdges++;
      }
      if (y > 1.57) {
        assert.ok(Math.abs(posedLength / restLength - 1) < 1e-4, `${id}/${density} 手臂动作不可牵拉颈柱`);
        neckEdges++;
      }
    }
    assert.ok(shoulderEdges > 100 && neckEdges > 100);
  }
});

test('cached morph endpoints cannot be corrupted by consumers editing a returned mesh', () => {
  const mutable = generateHumanoid();
  mutable.positions.fill(0); mutable.indices.fill(0); mutable.normals.fill(0);
  mutable.bones[0].position.fill(0); mutable.metadata.headSize.fill(0); mutable.metadata.digitCount.fingers = 0;
  const clean = generateHumanoid();
  assert.deepEqual(clean.positions, regular.positions);
  assert.deepEqual(clean.indices, regular.indices);
  assert.deepEqual(clean.bones, regular.bones);
  assert.deepEqual(clean.metadata.headSize, regular.metadata.headSize);
  assert.equal(clean.metadata.digitCount.fingers, 10);
});

test('representative mixed body shapes remain manifold and non-penetrating', () => {
  const cases = [
    { bodyWeights: { fat: .5, skinny: .5 } },
    { bodyWeights: { chubby: .55, muscular: .45 }, seam: true },
    { bodyWeights: { fat: 1, chubby: 1, muscular: 1, regular: 1, skinny: 1 }, density: 1 },
    { bodyWeights: { muscular: .65, regular: .35 }, density: 2 },
  ];
  for (const options of cases) {
    const mesh = generateHumanoid(options), report = validateMesh(mesh);
    assert.deepEqual(report.errors, []);
    const intersections = surfaceIntersections(mesh);
    assert.equal(intersections.length, 0, `${JSON.stringify(options)}: ${JSON.stringify(intersections.slice(0, 6))}`);
    for (let i = 0; i < mesh.seamPairs.length; i += 2) {
      const a = mesh.seamPairs[i] * 4, b = mesh.seamPairs[i + 1] * 4;
      assert.deepEqual(mesh.positions.slice(a, a + 4), mesh.positions.slice(b, b + 4));
    }
  }
});

test('root rotation pivots the complete posed hierarchy at the hips and exposes world axes', () => {
  const root = [.12, .3, -.2], pose = { hips: [17, 0, 8], 'upperArm.L': [20, 15, 0] };
  const base = evaluateRig(regular, { root, pose });
  const rotated = evaluateRig(regular, { root, pose, rootRotation: [0, 90, 0] });
  assert.ok(rotated.worldMatrices instanceof Float32Array);
  assert.equal(rotated.worldMatrices.length, regular.bones.length * 16);
  const pivot = base.joints[0];
  base.joints.forEach((joint, index) => {
    const expected = [pivot[0] + joint[2] - pivot[2], joint[1], pivot[2] - joint[0] + pivot[0]];
    expected.forEach((value, axis) => {
      assert.ok(Math.abs(rotated.joints[index][axis] - value) < 1e-12);
      assert.ok(Math.abs(rotated.worldMatrices[index * 16 + 12 + axis] - value) < 1e-7);
    });
    for (let column = 0; column < 3; column++) {
      const offset = index * 16 + column * 4;
      assert.ok(Math.abs(rotated.worldMatrices[offset] - base.worldMatrices[offset + 2]) < 1e-7);
      assert.ok(Math.abs(rotated.worldMatrices[offset + 1] - base.worldMatrices[offset + 1]) < 1e-7);
      assert.ok(Math.abs(rotated.worldMatrices[offset + 2] + base.worldMatrices[offset]) < 1e-7);
    }
  });
  const rest = skinCPU(regular, evaluateRig(regular, { rootRotation: [0, 90, 0] }).matrices);
  for (let i = 0; i < regular.vertexCount; i++) {
    assert.ok(Math.abs(rest[i * 4] - regular.positions[i * 4 + 2]) < 2e-7);
    assert.ok(Math.abs(rest[i * 4 + 2] + regular.positions[i * 4]) < 2e-7);
  }
});

test('joint translations use parent-local metres and move only that subtree', () => {
  const pose = { 'upperArm.L': [0, 0, 90] };
  const base = evaluateRig(regular, { pose });
  const moved = evaluateRig(regular, { pose, jointOffsets: { 'forearm.L': [.05, 0, 0] } });
  regular.bones.forEach((bone, index) => {
    let ancestor = index;
    while (ancestor >= 0 && regular.bones[ancestor].name !== 'forearm.L') ancestor = regular.bones[ancestor].parent;
    for (let axis = 0; axis < 3; axis++) {
      const expected = base.joints[index][axis] + (ancestor >= 0 && axis === 1 ? .05 : 0);
      assert.ok(Math.abs(moved.joints[index][axis] - expected) < 1e-12);
    }
  });
  const translated = evaluateRig(regular, { root: [.1, .2, .3], jointOffsets: { hips: [.02, .03, .04] } });
  regular.bones.forEach((bone, index) => bone.position.forEach((value, axis) => {
    assert.ok(Math.abs(translated.joints[index][axis] - value - [.12, .23, .34][axis]) < 1e-12);
  }));
});

test('invalid input is rejected and validation can report or explicitly throw', () => {
  assert.throws(() => generateHumanoid({ preset: 'unknown' }), RangeError);
  assert.throws(() => generateHumanoid({ density: 3 }), RangeError);
  assert.throws(() => evaluateRig(regular, { clip: 'unknown' }), RangeError);
  const broken = { ...regular, indices: regular.indices.slice(3) };
  const report = validateMesh(broken);
  assert.equal(report.valid, false);
  assert.ok(report.boundaryEdges > 0);
  assert.throws(() => validateMesh(broken, { throwOnError: true }));
});
