import test from 'node:test';
import assert from 'node:assert/strict';
import { generateHumanoid } from '../src/geometry.js';
import { evaluateRig, createPosePreset } from '../src/rig.js';
import { expandColliders } from '../src/colliders.js';
import { createRagdoll, stepRagdoll, evaluateRagdoll, validateRagdoll } from '../src/ragdoll.js';

const mesh = generateHumanoid();
const restRig = evaluateRig(mesh);
const capture = () => createRagdoll(mesh, restRig);
const distance = (a, b) => Math.hypot(...a.map((value, axis) => value - b[axis]));
const rotate = (q, v) => {
  const [x, y, z, w] = q, [vx, vy, vz] = v;
  const tx = 2 * (y * vz - z * vy), ty = 2 * (z * vx - x * vz), tz = 2 * (x * vy - y * vx);
  return [vx + w * tx + y * tz - z * ty, vy + w * ty + z * tx - x * tz, vz + w * tz + x * ty - y * tx];
};

function anchor(state, joint, which) {
  const body = state.bodies[joint[which]];
  return body.position.map((value, axis) => value + rotate(body.orientation, joint[which === 'a' ? 'localA' : 'localB'])[axis]);
}

function lowestPoint(body) {
  if (body.shape.type === 'sphere') return body.position[1] - body.shape.radius;
  if (body.shape.type === 'capsule') {
    const half = rotate(body.orientation, [0, body.shape.height / 2, 0]);
    return Math.min(body.position[1] - half[1], body.position[1] + half[1]) - body.shape.radius;
  }
  let lowest = Infinity;
  for (const x of [-1, 1]) for (const y of [-1, 1]) for (const z of [-1, 1]) {
    const local = [x * body.shape.size[0] / 2, y * body.shape.size[1] / 2, z * body.shape.size[2] / 2];
    lowest = Math.min(lowest, body.position[1] + rotate(body.orientation, local)[1]);
  }
  return lowest;
}

test('capture creates dynamic shapes from the current rig and preserves its skin matrices', () => {
  const state = capture();
  assert.equal(state.bodies.length, 15);
  assert.equal(state.bodies.filter(body => body.shape.type === 'capsule').length, 12);
  assert.equal(state.bodies.filter(body => body.shape.type === 'box').length, 2);
  assert.equal(state.bodies.filter(body => body.shape.type === 'sphere').length, 1);
  assert.ok(state.bodies.every(body => body.bones.length === 1 && body.mass > 0));
  assert.equal(state.joints.length, 14);
  assert.equal(state.colliders.length, state.bodies.length);
  const evaluated = evaluateRagdoll(mesh, state);
  assert.equal(evaluated.matrices.length, restRig.matrices.length);
  for (let i = 0; i < evaluated.matrices.length; i++) assert.ok(Math.abs(evaluated.matrices[i] - restRig.matrices[i]) < 2e-5, `matrix ${i}`);
  for (let i = 0; i < evaluated.joints.length; i++) assert.ok(distance(evaluated.joints[i], restRig.joints[i]) < 2e-6);
  assert.equal(validateRagdoll(state).valid, true);
});

test('posed capture uses the original bind inverse and does not jump on the first frame', () => {
  const posedMesh = generateHumanoid({ preset: 'skinny' });
  const pose = createPosePreset(posedMesh, 'sit');
  const rig = evaluateRig(posedMesh, { pose: pose.value, root: pose.root.position, rootRotation: pose.root.rotation });
  const state = createRagdoll(posedMesh, rig), evaluated = evaluateRagdoll(posedMesh, state);
  for (let i = 0; i < rig.matrices.length; i++) assert.ok(Math.abs(evaluated.matrices[i] - rig.matrices[i]) < 2e-5, `posed matrix ${i}`);
  const shoulder = state.bodies.find(body => body.name === 'upperArm.L');
  assert.ok(distance(anchor(state, state.joints.find(joint => joint.b === shoulder.index), 'b'), rig.joints[shoulder.boneIndex]) < 1e-8);
});

test('a fixed body keeps its center but remains free to rotate under angular velocity', () => {
  const state = capture(), hips = state.bodies.find(body => body.name === 'hips');
  const position = hips.position.slice(), orientation = hips.orientation.slice();
  hips.angularVelocity = [0, 0, 2];
  stepRagdoll(state, 1 / 30, { gravityEnabled: false, fixed: new Set(['hips']) });
  assert.ok(distance(position, hips.position) < 1e-12);
  assert.ok(distance(orientation, hips.orientation) > .004);
  assert.ok(Math.hypot(...hips.angularVelocity) > .1);
  const before = hips.position.slice();
  stepRagdoll(state, 1 / 60, { gravityEnabled: false, fixed: [hips.index] });
  assert.deepEqual(hips.position, before);
});

test('gravity produces a real free fall and can be disabled', () => {
  const falling = capture(), head = falling.bodies.find(body => body.name === 'head');
  const initialY = head.position[1];
  stepRagdoll(falling, .12, { colliders: [] });
  assert.ok(head.position[1] < initialY - .04);
  const floating = capture(), floatingHead = floating.bodies.find(body => body.name === 'head');
  const floatingY = floatingHead.position[1];
  stepRagdoll(floating, .12, { gravityEnabled: false, colliders: [] });
  assert.ok(Math.abs(floatingHead.position[1] - floatingY) < 1e-8);
});

test('settled bodies do not penetrate the ground and matrices stay finite', () => {
  const state = capture();
  for (let i = 0; i < 150; i++) stepRagdoll(state, 1 / 60, { colliders: [] });
  assert.equal(validateRagdoll(state).valid, true);
  for (const body of state.bodies) assert.ok(lowestPoint(body) > -5e-3, `${body.name}: ${lowestPoint(body)}`);
  const evaluated = evaluateRagdoll(mesh, state);
  assert.ok(evaluated.matrices.every(Number.isFinite));
  assert.ok(evaluated.worldMatrices.every(Number.isFinite));
  assert.ok(evaluated.joints.flat().every(Number.isFinite));
});

test('angular limits and damping settle without long-term energy growth', () => {
  const state = capture();
  for (let i = 0; i < 600; i++) stepRagdoll(state, 1 / 60, { colliders: [] });
  assert.ok(state.joints.every(joint => joint.angularLimit > 0 && joint.restRelative.length === 4));
  assert.ok(Math.max(...state.bodies.map(body => Math.hypot(...body.position))) < 3);
  assert.ok(Math.max(...state.bodies.map(body => Math.hypot(...body.linearVelocity))) < .05);
  assert.ok(Math.max(...state.bodies.map(body => Math.hypot(...body.angularVelocity))) < .05);
});

test('point-to-point joints retain their authored lengths during a fall', () => {
  const state = capture();
  for (const body of state.bodies) {
    body.angularVelocity = [Math.sin(body.index), .3 * Math.cos(body.index), .2];
  }
  for (let i = 0; i < 90; i++) stepRagdoll(state, 1 / 60, { colliders: [] });
  for (const joint of state.joints) assert.ok(distance(anchor(state, joint, 'a'), anchor(state, joint, 'b')) < 8e-3);
});

for (const kind of ['box', 'sphere', 'capsule']) {
  test(`a body collides with an expanded ${kind} scene collider`, () => {
    const full = capture();
    const head = full.bodies.find(body => body.name === 'head');
    const state = { ...full, bodies: [head], joints: [], fixed: new Set(), colliders: [] };
    const collider = expandColliders([{ id: kind, kind, position: [0, 0, 0], rotation: 0, scale: 1 }])[0];
    const top = kind === 'box' ? collider.position[1] + collider.size[1] / 2 : collider.position[1] + collider.radius + (kind === 'capsule' ? collider.height / 2 : 0);
    head.position = [0, top + head.shape.radius + .035, 0]; head.previousPosition = head.position.slice();
    head.linearVelocity = [0, 0, 0]; head.angularVelocity = [0, 0, 0];
    for (let i = 0; i < 24; i++) stepRagdoll(state, 1 / 120, { colliders: [collider] });
    assert.equal(validateRagdoll(state).valid, true);
    if (kind === 'box') {
      assert.ok(head.position[1] >= top + head.shape.radius - 4e-3);
    } else if (kind === 'sphere') {
      assert.ok(distance(head.position, collider.position) >= head.shape.radius + collider.radius - 4e-3);
    } else {
      const y = Math.max(collider.position[1] - collider.height / 2, Math.min(collider.position[1] + collider.height / 2, head.position[1]));
      assert.ok(distance(head.position, [collider.position[0], y, collider.position[2]]) >= head.shape.radius + collider.radius - 4e-3);
    }
  });
}

test('box contacts apply local-X pitch before world-Y yaw', () => {
  const full = capture(), head = full.bodies.find(body => body.name === 'head');
  const state = { ...full, bodies: [head], joints: [], fixed: new Set(), colliders: [] };
  const collider = { type: 'box', position: [0, .55, 0], size: [.7, .1, .6], rotation: .37, pitch: -12 * Math.PI / 180 };
  const cp = Math.cos(collider.pitch), sp = Math.sin(collider.pitch), cy = Math.cos(collider.rotation), sy = Math.sin(collider.rotation);
  const normal = [sy * sp, cp, cy * sp];
  head.position = collider.position.map((value, axis) => value + normal[axis] * head.shape.radius);
  head.previousPosition = head.position.slice(); head.linearVelocity = [0, 0, 0]; head.angularVelocity = [0, 0, 0];
  for (let i = 0; i < 8; i++) stepRagdoll(state, 1 / 120, { gravityEnabled: false, colliders: [collider] });
  const separation = head.position.reduce((sum, value, axis) => sum + (value - collider.position[axis]) * normal[axis], 0);
  assert.ok(separation >= collider.size[1] / 2 + head.shape.radius - 3e-3, `signed separation ${separation}`);
  assert.ok(Math.abs(head.position[2] - collider.position[2]) > .005, 'contact correction must follow the tilted normal');
});

test('validation reports NaN instead of allowing it into rendering', () => {
  const state = capture();
  state.bodies[0].position[1] = NaN;
  const report = validateRagdoll(state);
  assert.equal(report.valid, false);
  assert.ok(report.errors.length > 0);
  assert.throws(() => stepRagdoll(state, 1 / 60));
});
