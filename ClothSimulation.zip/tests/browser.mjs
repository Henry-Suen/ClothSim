import { chromium } from 'playwright-core';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { mkdir } from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';

const root=fileURLToPath(new URL('../',import.meta.url));
const artifacts=path.join(root,'tests','artifacts');
await mkdir(artifacts,{recursive:true});
const benchmark=process.argv.includes('--benchmark');
const channel=process.env.TEST_BROWSER || 'chrome';
const browser=await chromium.launch({channel,headless:true});
const context=await browser.newContext({viewport:benchmark?{width:1920,height:1080}:{width:1440,height:1000},deviceScaleFactor:1,offline:true});
const page=await context.newPage();
const errors=[],network=[];
page.on('pageerror',e=>errors.push(e.message));
page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
page.on('request',r=>{if(/^https?:/.test(r.url()))network.push(r.url());});
try{
  await page.goto(pathToFileURL(path.join(root,'cloth-studio.html')).href);
  await page.waitForFunction(()=>window.clothStudio?.ready || window.clothStudio?.errors.length,null,{timeout:120000});
  await page.evaluate(()=>{clothStudio.autoRagdoll=false;document.getElementById('autoRagdoll').checked=false;});
  assert.deepEqual(await page.evaluate(()=>clothStudio.phaseSettings),{releaseBinding:.02,releaseDuration:.3,inflateBinding:1,inflateDuration:3});
  assert.equal(await page.locator('#releaseBinding').inputValue(),'2');assert.equal(await page.locator('#releaseDuration').inputValue(),'0.3');
  if(benchmark){
    const preview=await page.evaluate(()=>new Promise(resolve=>{
      const s=window.clothStudio;s.playing=true;const started=performance.now(),first=s.time,spans=[];let last=started;
      const sample=now=>{spans.push(now-last);last=now;if(spans.length<180){requestAnimationFrame(sample);return;}
        s.playing=false;const elapsed=(now-started)/1000,sorted=spans.slice(30).sort((a,b)=>a-b);
        resolve({vertices:s.mesh.vertexCount,viewport:[innerWidth,innerHeight],renderFps:180/elapsed,lowPercentileFps:1000/sorted[Math.floor(sorted.length*.99)],simulatedSeconds:s.time-first,wallSeconds:elapsed});};requestAnimationFrame(sample);
    }));
    console.log('Realtime preview:',JSON.stringify(preview));
    await page.locator('#density').selectOption('1');
    await page.waitForFunction(()=>!window.clothStudio.busy && window.clothStudio.density===1,null,{timeout:120000});
  }
  const startup=await page.evaluate(()=>({ready:!!window.clothStudio.ready,errors:window.clothStudio.errors,adapter:window.clothStudio.gpu?.info}));
  console.log('Startup:',JSON.stringify(startup));
  assert.equal(startup.ready,true,`GPU startup failed: ${startup.errors.join('; ')}`);
  const defaults=await page.evaluate(()=>({clothing:clothStudio.appearance.clothing,material:clothStudio.materialName}));assert.deepEqual(defaults,{clothing:'tshirt',material:'rubber'});
  assert.equal(await page.locator('#clothing').inputValue(),'tshirt');
  assert.equal(network.length,0,'The offline HTML must not request network assets');
  await page.screenshot({path:path.join(artifacts,`${channel}-studio.png`)});
  if(!benchmark){
    await page.evaluate(()=>{clothStudio.appearance.beard=true;document.getElementById('beard').checked=true;clothStudio.draw();});
    await page.screenshot({path:path.join(artifacts,`${channel}-beard.png`)});
    await page.locator('[data-preset="fat"]').click();await page.waitForFunction(()=>!clothStudio.busy&&clothStudio.preset==='fat');
    for(const [name,camera]of Object.entries({
      'fat-side':{target:[0,1.20,.03],distance:2.05,yaw:.85,pitch:.08},
      'fat-chest':{target:[0,1.34,.04],distance:1.0,yaw:.5,pitch:.05},
    })){
      await page.evaluate(c=>{const s=clothStudio;s.cameraOverride=true;Object.assign(s.camera,c);s.draw();},camera);await page.screenshot({path:path.join(artifacts,`${channel}-${name}.png`)});
    }
    await page.locator('#toolPose').click();await page.locator('#selectRoot').click();assert.equal(await page.evaluate(()=>clothStudio.showRig),true);
    await page.locator('#playButton').click();
    assert.equal(await page.evaluate(()=>clothStudio.editor.tool),'camera');assert.equal(await page.evaluate(()=>clothStudio.showRig),false);assert.equal(await page.locator('#rigOverlay').getAttribute('aria-pressed'),'false');
    await page.evaluate(()=>clothStudio.playing=false);
    await page.evaluate(async()=>{const s=clothStudio;const data=s.sceneData();data.preset='regular';data.bodyWeights=Object.fromEntries(['fat','chubby','muscular','regular','skinny'].map(k=>[k,Number(k==='regular')]));await s.loadScene(data);s.frameSubject();});
    await page.getByRole('tab',{name:'烘焙',exact:true}).click();await page.locator('#duration').fill('12');await page.locator('#duration').dispatchEvent('change');await page.waitForFunction(()=>!clothStudio.busy);
    await page.locator('#bakeDuration').fill('1');await page.locator('#bakeDuration').dispatchEvent('change');assert.equal(await page.evaluate(()=>clothStudio.timeline.duration),12);
    const queued=await page.evaluate(()=>clothStudio.bake());assert.ok(queued.pending===true||queued.complete===true);
    await page.waitForFunction(()=>clothStudio.cache?.complete&&!clothStudio.busy,null,{timeout:120000});assert.equal(await page.evaluate(()=>clothStudio.cache.frames.length),31);assert.equal(await page.evaluate(()=>clothStudio.bakeDuration),1);
    assert.equal(await page.locator('#bakeRange').isVisible(),true);const range=await page.locator('#bakeRange').evaluate(el=>({width:parseFloat(el.style.width),partial:el.classList.contains('partial')}));assert.ok(Math.abs(range.width-100/12)<.01);assert.equal(range.partial,false);
    await page.evaluate(()=>{clothStudio.invalidate();clothStudio.refreshTimeline();});assert.equal(await page.locator('#bakeRange').isVisible(),false);
    await page.evaluate(async()=>{const s=clothStudio;s.timeline.duration=30;s.bakeDuration=30;const data=s.sceneData();data.preset='regular';data.bodyWeights=Object.fromEntries(['fat','chubby','muscular','regular','skinny'].map(k=>[k,Number(k==='regular')]));await s.loadScene(data);});
    await page.getByRole('tab',{name:'姿势',exact:true}).click();
  }
  if(!benchmark)for(const [name,camera]of Object.entries({
    'face-front':{target:[0,1.755,.015],distance:.62,yaw:.05,pitch:.02},
    'face-side':{target:[0,1.75,0],distance:.57,yaw:1.35,pitch:0},
    'feet':{target:[0,.10,.07],distance:.80,yaw:1.0,pitch:.10},
    'shoulders':{target:[0,1.51,0],distance:1.08,yaw:.1,pitch:.04},
  })){
    await page.evaluate(c=>{const s=clothStudio;s.cameraOverride=true;Object.assign(s.camera,c);s.draw();},camera);
    await page.screenshot({path:path.join(artifacts,`${channel}-${name}.png`)});
  }
  const initial=await page.evaluate(async()=>{
    const s=window.clothStudio;s.playing=false;
    const xyz=await s.solver.readPositions();
    return{vertices:s.mesh.vertexCount,triangles:s.mesh.triangleCount,finite:xyz.every(Number.isFinite),bounds:[Math.min(...xyz.filter((_,i)=>i%3===1)),Math.max(...xyz.filter((_,i)=>i%3===1))],diagnostics:s.solver.diagnostics?await s.solver.diagnostics():null};
  });
  console.log('Mesh:',JSON.stringify(initial));assert.equal(initial.finite,true);
  await page.locator('#beard').check();assert.equal(await page.locator('#bodyHair').count(),0);assert.equal(await page.locator('#clipType').count(),0);
  await page.getByRole('tab',{name:'姿势',exact:true}).click();
  await page.getByRole('tab',{name:'通用',exact:true}).click();
  await page.locator('#keyCamera').click();
  assert.equal(await page.locator('#cameraTrack .timeline-key').count(),1);
  await page.getByRole('tab',{name:'材质',exact:true}).click();
  if(!benchmark){
    assert.equal(await page.title(),'布料模拟');
    const original=await page.evaluate(()=>window.clothStudio.sceneData());
    await page.locator('#morphMuscular').evaluate(el=>{el.value='.7';el.dispatchEvent(new Event('input',{bubbles:true}));});await page.locator('#morphMuscular').dispatchEvent('change');
    await page.waitForFunction(()=>!window.clothStudio.busy&&window.clothStudio.bodyWeights.muscular>0);
    const morph=await page.evaluate(()=>({weights:window.clothStudio.bodyWeights,meshWeights:window.clothStudio.mesh.metadata.bodyWeights}));
    assert.ok(morph.weights.muscular>0&&morph.weights.regular>0);console.log('Body blend:',JSON.stringify(morph));
    await page.locator('#clothing').selectOption('jacket');await page.locator('#eyesClosed').check();
    await page.screenshot({path:path.join(artifacts,`${channel}-jacket.png`)});
    await page.locator('#clothing').selectOption('tshirt');
    await page.screenshot({path:path.join(artifacts,`${channel}-tshirt.png`)});
    await page.locator('#clothing').selectOption('boxers');
    const rect=await page.locator('#viewport').boundingBox();
    await page.mouse.move(rect.x+rect.width*.5,rect.y+rect.height*.4);await page.mouse.down();
    await page.mouse.move(rect.x+rect.width*.5+25,rect.y+rect.height*.4,{steps:4});await page.mouse.up();
    assert.equal(await page.evaluate(()=>window.clothStudio.timeline.grabs.length),0,'Camera mode must never pick cloth');
    await page.locator('#viewport').focus();
    const before=await page.evaluate(()=>[...window.clothStudio.camera.target]);
    await page.keyboard.down('w');
    await page.waitForFunction(old=>Math.hypot(...window.clothStudio.camera.target.map((v,i)=>v-old[i]))>.05,before);
    await page.keyboard.up('w');
    const cameraAfter=await page.evaluate(()=>[...window.clothStudio.camera.target]);assert.notDeepEqual(cameraAfter,before);
    await page.keyboard.down('e');await page.waitForFunction(y=>window.clothStudio.camera.target[1]>y+.02,cameraAfter[1]);await page.keyboard.up('e');
    await page.locator('#frameCamera').click();await page.locator('#toolPose').click();await page.locator('#selectRoot').click();await page.locator('#gizmoTranslate').click();
    await page.waitForFunction(()=>window.clothStudio.editor.handles.some(h=>h.kind==='translate'));
    const drag=await page.evaluate(()=>{const s=window.clothStudio,r=document.getElementById('viewport').getBoundingClientRect(),h=s.editor.handles.find(h=>h.axis===0);return{start:[r.left+h.tip[0],r.top+h.tip[1]],end:[r.left+h.tip[0]+40,r.top+h.tip[1]]};});
    await page.mouse.move(...drag.start);await page.mouse.down();await page.mouse.move(...drag.end,{steps:8});await page.mouse.up();
    const pose=await page.evaluate(()=>({root:window.clothStudio.authorRoot,keys:window.clothStudio.timeline.poseKeys}));
    assert.ok(Math.abs(pose.root.position[0])>.01,'Root gizmo must translate whole figure');assert.equal(pose.keys.length,0,'Static editing must not create unsolicited timeline keys');
    await page.locator('#keyPose').click();assert.equal(await page.evaluate(()=>window.clothStudio.timeline.poseKeys.length),1);
    await page.locator('#joint').selectOption('upperArm.L');await page.locator('#gizmoRotate').click();
    await page.waitForFunction(()=>window.clothStudio.editor.handles.some(h=>h.kind==='rotate'));
    const turn=await page.evaluate(()=>{const s=window.clothStudio,r=document.getElementById('viewport').getBoundingClientRect(),h=s.editor.handles.find(h=>h.axis===2);const p=h.points[8];return{start:[r.left+p[0],r.top+p[1]],end:[r.left+p[0]+25,r.top+p[1]-20]};});
    await page.mouse.move(...turn.start);await page.mouse.down();await page.mouse.move(...turn.end,{steps:8});await page.mouse.up();
    assert.ok(await page.evaluate(()=>Object.values(window.clothStudio.pose).some(v=>v.some(a=>Math.abs(a)>.1))),'Joint rotation handle must modify pose');
    await page.screenshot({path:path.join(artifacts,`${channel}-gizmo.png`)});
    const poseRoundtrip=await page.evaluate(async()=>{const s=window.clothStudio,data=s.sceneData();await s.loadScene(data);return JSON.stringify(s.sceneData().authorRoot)===JSON.stringify(data.authorRoot)&&JSON.stringify(s.sceneData().timeline.poseKeys)===JSON.stringify(data.timeline.poseKeys);});
    assert.equal(poseRoundtrip,true,'Scene round-trip must preserve authored root and pose transforms');
    const offscreen=await page.evaluate(()=>{const s=window.clothStudio;s.cameraOverride=true;s.camera.target=[0,1,-12];s.camera.yaw=0;s.camera.pitch=0;s.showRig=true;s.grab={target:[0,1,0]};s.draw();const hidden=document.getElementById('grabMarker').hidden;s.grab=null;return hidden;});
    assert.equal(offscreen,true,'Camera travel behind the subject must safely hide overlays');
    await page.evaluate(async data=>{await window.clothStudio.loadScene(data);},original);
    await page.evaluate(()=>{const s=window.clothStudio;s.timeline.cameraKeys=[{time:3,value:structuredClone(s.camera)},{time:6,value:structuredClone(s.camera)}];s.refreshTimeline();});
    await page.locator('#timelineSelect').click();
    const track=await page.locator('#cameraTrack').boundingBox();
    await page.mouse.move(track.x+track.width*.04,track.y+2);await page.mouse.down();await page.mouse.move(track.x+track.width*.24,track.y+track.height-2,{steps:8});await page.mouse.up();
    assert.equal(await page.evaluate(()=>window.clothStudio.editor.selection.size),2,'Marquee should select both camera keys');
    const key=await page.locator('#cameraTrack .timeline-key').first().boundingBox();
    await page.mouse.move(key.x+key.width/2,key.y+key.height/2);await page.mouse.down();await page.mouse.move(key.x+key.width/2+track.width*.1,key.y+key.height/2,{steps:8});await page.mouse.up();
    const retimed=await page.evaluate(()=>window.clothStudio.timeline.cameraKeys.map(k=>k.time));assert.ok(retimed[0]>5.8);assert.ok(Math.abs(retimed[1]-retimed[0]-3)<1e-6);
    await page.keyboard.press('Delete');assert.equal(await page.locator('#cameraTrack .timeline-key').count(),0);
    const downloadEvent=page.waitForEvent('download');await page.locator('#timelineSave').click();const download=await downloadEvent;
    const timelinePath=path.join(artifacts,`${channel}-timeline.json`);await download.saveAs(timelinePath);
    await page.evaluate(()=>{window.confirm=()=>{throw new Error('Native confirm must not be called');};document.getElementById('recordCamera').checked=true;});
    await page.locator('#timelineReset').click();await page.waitForFunction(()=>!window.clothStudio.busy);
    const cleared=await page.evaluate(()=>({sizes:['cameraKeys','poseKeys','clips','phases','grabs'].map(k=>clothStudio.timeline[k].length),record:document.getElementById('recordCamera').checked,time:clothStudio.time,cache:clothStudio.cache,selection:clothStudio.editor.selection.size}));
    assert.deepEqual(cleared,{sizes:[0,0,0,0,0],record:false,time:0,cache:null,selection:0});
    await page.locator('#timelineUndo').click();await page.waitForFunction(()=>!clothStudio.busy);assert.equal(await page.evaluate(()=>clothStudio.timeline.phases.length),1);
    await page.locator('#timelineReset').click();await page.waitForFunction(()=>!clothStudio.busy);
    await page.locator('#timelineFile').setInputFiles(timelinePath);await page.waitForFunction(()=>!window.clothStudio.busy&&window.clothStudio.timeline.phases.length===1);
    await page.evaluate(async data=>{await window.clothStudio.loadScene(data);window.clothStudio.editor.setTool('camera');},original);
    await page.locator('#toolPose').click();
    for(const id of ['stand','walk','sit','lie','prone']){
      await page.locator('#posePreset').selectOption(id);
      assert.equal(await page.locator('#applyPose').count(),0);
      assert.equal(await page.evaluate(()=>clothStudio.editor.poseDraft),false,'Preset selection must apply and commit immediately');
      const still=await page.evaluate(()=>{const s=clothStudio,a=Array.from(s.inputsAt(0).boneMatrices),b=Array.from(s.inputsAt(8).boneMatrices);s.inputsAt(s.time);return a.every((v,i)=>v===b[i]);});assert.ok(still,`${id} should not animate with time`);
      await page.screenshot({path:path.join(artifacts,`${channel}-pose-${id}.png`)});
    }
    await page.locator('#rootX').fill('.25');await page.locator('#rootX').dispatchEvent('change');
    await page.locator('#poseName').fill('自定义躺姿');await page.locator('#savePose').click();
    const saved=await page.evaluate(()=>structuredClone(clothStudio.customPoses.at(-1)));assert.equal(saved.name,'自定义躺姿');assert.equal(saved.root.position[0],.25);
    const poseDownloadEvent=page.waitForEvent('download');await page.locator('#exportPoses').click();const poseDownload=await poseDownloadEvent;
    const posePath=path.join(artifacts,`${channel}-poses.json`);await poseDownload.saveAs(posePath);
    await page.reload();await page.waitForFunction(()=>clothStudio.ready);assert.equal(await page.evaluate(id=>clothStudio.customPoses.some(p=>p.id===id),saved.id),true);
    await page.locator('#toolPose').click();await page.locator('#posePreset').selectOption(saved.id);
    assert.deepEqual(await page.evaluate(()=>clothStudio.authorRoot),saved.root);
    await page.locator('#deletePose').click();assert.equal(await page.evaluate(id=>clothStudio.customPoses.some(p=>p.id===id),saved.id),false);
    await page.locator('#poseFile').setInputFiles(posePath);await page.waitForFunction(id=>clothStudio.customPoses.some(p=>p.id===id),saved.id);
    await page.evaluate(async data=>{await clothStudio.loadScene(data);clothStudio.editor.setTool('camera');},original);
    console.log('PASS: morphs, modes, gizmos, clear/undo, static presets, custom pose persistence/import/export and legacy-free timeline');
  }
  const simulation=await page.evaluate(async()=>{
    const s=window.clothStudio;s.busy=true;s.playing=false;s.phaseSettings.releaseDuration=.5;s.phaseSettings.releaseBinding=0;
    s.timeline.phases=[{time:.1,type:'release',duration:.5},{time:4,type:'inflate',duration:2}];
    await s.reset();
    for(let i=0;i<180;i++)await s.stepFixed();
    await s.gpu.device.queue.onSubmittedWorkDone();
    const collapsed=await s.solver.readPositions();
    const stats=xyz=>{let sum=0,min=Infinity,max=-Infinity;for(let i=1;i<xyz.length;i+=3){sum+=xyz[i];min=Math.min(min,xyz[i]);max=Math.max(max,xyz[i]);}return{meanY:sum/(xyz.length/3),minY:min,maxY:max,finite:xyz.every(Number.isFinite)};};
    const a=stats(collapsed);s.draw();
    const diagCollapsed=s.solver.diagnostics?await s.solver.diagnostics():null;
    for(let i=0;i<360;i++)await s.stepFixed();
    await s.gpu.device.queue.onSubmittedWorkDone();
    const recovered=stats(await s.solver.readPositions());
    const diagRecovered=s.solver.diagnostics?await s.solver.diagnostics():null;
    s.busy=false;s.playing=false;s.draw();
    return{collapsed:a,recovered,diagCollapsed,diagRecovered,phase:s.lastPhase};
  });
  console.log('Forward simulation:',JSON.stringify(simulation));
  assert.equal(simulation.collapsed.finite,true);assert.equal(simulation.recovered.finite,true);
  assert.ok(simulation.collapsed.meanY<initial.bounds[1]*.5,'The released shell should fall and collapse');
  assert.ok(simulation.collapsed.minY>-.04,'Ground collision should prevent deep penetration');
  assert.ok(simulation.recovered.meanY>simulation.collapsed.meanY+.1,'Reinflation should recover a higher pose');
  await page.screenshot({path:path.join(artifacts,`${channel}-recovered.png`)});
  const picking=await page.evaluate(async()=>{
    const s=window.clothStudio;s.busy=true;s.playing=false;await s.reset();
    const hit=await s.solver.pick([0,1.4,3],[0,0,-1]);
    if(!hit){s.busy=false;return null;}
    s.timeline.phases=[{time:0,type:'release',duration:.2}];
    s.grab={id:'area-test',triangle:hit.triangle,bary:hit.bary,target:[hit.position[0],hit.position[1]+.3,hit.position[2]],strength:.8,radius:.18};
    for(let i=0;i<60;i++)await s.stepFixed();
    const data=await s.solver.readPositions();
    const diagnostic=await s.solver.diagnostics();
    s.grab=null;s.busy=false;return{hit:{triangle:hit.triangle,bary:hit.bary,distance:hit.distance},finite:data.every(Number.isFinite),affected:diagnostic.grabAffectedVertices,radius:diagnostic.grabRadius};
  });
  console.log('GPU pick/grab:',JSON.stringify(picking));assert.ok(picking);assert.equal(picking.finite,true);assert.ok(picking.affected>3,'Soft grab must affect a patch, not just a triangle');assert.ok(Math.abs(picking.radius-.18)<1e-5);
  const bake=await page.evaluate(async benchmark=>{
    const s=window.clothStudio;
    s.timeline.duration=benchmark?30:2;s.timeline.cameraKeys=[];
    s.timeline.phases=[{time:.1,type:'release',duration:.5},{time:benchmark?10:1.2,type:'inflate',duration:benchmark?4:.5}];
    return s.bake(false,{duration:benchmark?30:2});
  },benchmark);
  console.log('Bake:',JSON.stringify(bake));assert.equal(bake.complete,true);
  assert.equal(bake.frames,(benchmark?30:2)*30+1);
  await page.evaluate(async()=>{const s=window.clothStudio;await s.seek(.5);});
  const final=await page.evaluate(()=>({cached:window.clothStudio.cachedMode,time:window.clothStudio.time,errors:window.clothStudio.errors}));
  assert.equal(final.cached,true);assert.ok(Math.abs(final.time-.5)<.01);
  if(!benchmark){
    const ruler=await page.locator('#ruler').boundingBox();
    await page.mouse.move(ruler.x+ruler.width*.2,ruler.y+ruler.height/2);await page.mouse.down();await page.mouse.move(ruler.x+ruler.width*.7,ruler.y+ruler.height/2,{steps:10});await page.mouse.up();
    await page.waitForFunction(()=>!window.clothStudio.busy&&!window.clothStudio.editor.seeking);
    assert.ok(Math.abs(await page.evaluate(()=>window.clothStudio.time)-1.4)<.08,'Mouse scrub must update cached frame');
    await page.evaluate(async()=>{const s=window.clothStudio;s.invalidate();await s.reset();s.draw();});
    await page.locator('#toolGrab').click();
    const rect=await page.locator('#viewport').boundingBox();
    await page.mouse.move(rect.x+rect.width*.5,rect.y+rect.height*.38);
    await page.mouse.down();
    await page.waitForFunction(()=>!!window.clothStudio.grab,null,{timeout:20000}).catch(async e=>{console.log('Grab wait state',await page.evaluate(()=>({tool:clothStudio.editor.tool,busy:clothStudio.busy,playing:clothStudio.playing,pointer:clothStudio.pointer,errors:clothStudio.errors,status:document.getElementById('statusText').textContent})));throw e;});
    await page.mouse.move(rect.x+rect.width*.5+30,rect.y+rect.height*.25,{steps:12});
    await page.mouse.up();
    const mouse=await page.evaluate(()=>{const s=window.clothStudio;s.playing=false;return{grab:s.grab,events:s.timeline.grabs.length,samples:s.timeline.grabs.at(-1)?.samples.length};});
    console.log('Mouse interaction:',JSON.stringify(mouse));assert.equal(mouse.grab,null);assert.ok(mouse.events>0);
    const seam=await page.evaluate(async()=>{
      const s=window.clothStudio;s.seam=true;s.timeline.grabs=[];s.timeline.duration=12;
      s.timeline.phases=[{time:.1,type:'release',duration:.5},{time:2.5,type:'inflate',duration:2}];
      await s.rebuild();s.busy=true;
      for(let i=0;i<120;i++)await s.stepFixed();
      const opened=await s.solver.diagnostics();
      for(let i=0;i<420;i++)await s.stepFixed();
      const closed=await s.solver.diagnostics();s.busy=false;s.playing=false;s.draw();
      return{opened,closed,pairs:s.mesh.seamPairs.length/2};
    });
    console.log('Spine seam:',JSON.stringify(seam));assert.ok(seam.pairs>0);assert.equal(seam.opened.pressureEnabled,false);assert.ok(seam.closed.finite);assert.ok(seam.closed.maxSeamGap<.012,'Seam must actually reclose before full inflation');
    const restored=await page.evaluate(async()=>{const s=window.clothStudio;const data=s.sceneData();await s.loadScene(data);return{preset:s.preset,seam:s.seam,time:s.time,appearance:s.appearance};});
    assert.equal(restored.seam,true);assert.equal(restored.time,0);assert.equal(restored.appearance.beard,true);
    const aborted=await page.evaluate(async()=>{const s=window.clothStudio;s.timeline.duration=30;return s.bake(false,{deadlineMs:1});});
    assert.equal(aborted.complete,false);assert.ok(aborted.frames<aborted.total);
    const furniture=await page.evaluate(async()=>{
      const s=window.clothStudio;s.invalidate();s.spawnHeight=.7;s.timeline.phases=[{time:.1,type:'release',duration:.5}];
      s.objects=[{id:1,kind:'chair',position:[0,0,0],scale:1,rotation:15},{id:2,kind:'sofa',position:[-1.6,0,-.8],scale:1,rotation:0},{id:3,kind:'box',position:[.8,0,-.7],scale:1,rotation:30},{id:4,kind:'sphere',position:[-.8,0,.4],scale:1,rotation:0},{id:5,kind:'capsule',position:[.8,0,.4],scale:1,rotation:0}];
      s.busy=true;await s.reset();for(let i=0;i<300;i++)await s.stepFixed();
      const xyz=await s.solver.readPositions(),colliders=s.inputsAt(s.time).colliders;
      let penetration=0;
      for(let i=0;i<xyz.length;i+=3){
        const p=[xyz[i],xyz[i+1],xyz[i+2]];penetration=Math.max(penetration,-p[1]);
        for(const c of colliders){const a=c.rotation||0,co=Math.cos(a),si=Math.sin(a),r=p.map((v,j)=>v-c.position[j]);const v=[co*r[0]-si*r[2],r[1],si*r[0]+co*r[2]];let d;
          if(c.type==='box'){const q=v.map((v,j)=>Math.abs(v)-c.size[j]/2);d=Math.hypot(...q.map(v=>Math.max(0,v)))+Math.min(Math.max(...q),0);}
          else{if(c.type==='capsule')v[1]-=Math.max(-c.height/2,Math.min(c.height/2,v[1]));d=Math.hypot(...v)-c.radius;}
          penetration=Math.max(penetration,-d);
        }
      }
      s.busy=false;s.playing=false;s.draw();return{finite:xyz.every(Number.isFinite),maxPenetration:penetration,primitives:colliders.length};
    });
    console.log('Furniture contact:',JSON.stringify(furniture));assert.equal(furniture.finite,true);assert.ok(furniture.maxPenetration<.015);
    await page.screenshot({path:path.join(artifacts,`${channel}-furniture.png`)});
    await page.locator('#density').selectOption('2');
    await page.waitForFunction(()=>!window.clothStudio.busy && window.clothStudio.mesh.vertexCount>70000,null,{timeout:120000});
    const memoryGuard=await page.evaluate(async()=>{const s=window.clothStudio;s.bakeDensity=2;s.updateBakeSummary();s.timeline.duration=30;return{vertices:s.mesh.vertexCount,preview:s.previewDensity,bake:s.bakeDensity,result:await s.bake(false),message:document.getElementById('statusText').textContent};});
    console.log('High-density budget guard:',JSON.stringify(memoryGuard));assert.equal(memoryGuard.result,null);assert.match(memoryGuard.message,/512 MiB/);
  }
  const allErrors=await page.evaluate(()=>window.clothStudio.errors);
  assert.deepEqual(allErrors,[]);assert.deepEqual(errors,[]);assert.deepEqual(network,[]);
  if(!benchmark){
    const unsupported=await context.newPage();
    await unsupported.addInitScript(()=>Object.defineProperty(navigator,'gpu',{get:()=>undefined}));
    await unsupported.goto(pathToFileURL(path.join(root,'cloth-studio.html')).href);
    await unsupported.locator('#retryButton').waitFor({state:'visible'});
    assert.match(await unsupported.locator('#startupText').textContent(),/WebGPU 不可用/);
    await unsupported.close();
  }
  console.log('PASS: offline GPU simulation, recovery, picking, bake/scrub, and applicable mouse/seam/furniture/persistence/budget scenarios.');
}finally{await browser.close();}
