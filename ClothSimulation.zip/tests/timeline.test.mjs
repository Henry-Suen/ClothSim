import test from 'node:test';
import assert from 'node:assert/strict';
import { defaultTimeline, samplePhase, sampleCamera, samplePose, sampleClip, sampleGrab, insertKey, cacheBytes, validateTimeline, grabReference, remapGrab, timelineItems, retimeSelection, deleteSelection, samplePoseTransform, migrateLegacyClips, validatePoseLibrary } from '../src/timeline.js';
import { POSE_PRESETS, createPosePreset, evaluateRig, skinCPU } from '../src/rig.js';
import { generateHumanoid } from '../src/geometry.js';
import { createObject, expandColliders, rayColliderDistance } from '../src/colliders.js';

test('five static presets remain fixed across time and align their lowest point',()=>{
  assert.deepEqual(POSE_PRESETS.map(p=>p.id),['stand','walk','sit','lie','prone']);assert.equal(defaultTimeline().clips.length,0);
  const mesh=generateHumanoid({preset:'regular',density:0});
  for(const {id}of POSE_PRESETS){
    const frame=createPosePreset(mesh,id),inputs={pose:frame.value,root:frame.root.position,rootRotation:frame.root.rotation,jointOffsets:frame.offsets};
    const a=evaluateRig(mesh,{...inputs,time:0}),b=evaluateRig(mesh,{...inputs,time:17});assert.deepEqual(a.matrices,b.matrices);
    const xyz=skinCPU(mesh,a.matrices);let low=Infinity;for(let i=1;i<xyz.length;i+=4)low=Math.min(low,xyz[i]);assert.ok(Math.abs(low-.008)<1e-5,`${id} floor ${low}`);
    if(id==='lie'||id==='prone'){const hip=a.joints[0],head=a.joints[mesh.bones.findIndex(b=>b.name==='head')];assert.ok(Math.abs(head[1]-hip[1])<.2);assert.ok(Math.abs(head[2]-hip[2])>.5);}
  }
});
test('custom pose schema round-trips and rejects invalid names and transforms',()=>{
  const frame=createPosePreset(null,'walk'),pose={id:'user-test',name:'我的走姿',...frame};
  assert.equal(JSON.stringify(validatePoseLibrary(JSON.parse(JSON.stringify([pose])))),JSON.stringify([pose]));
  for(const patch of [{name:''},{name:'x'.repeat(61)},{id:'stand'},{root:undefined},{offsets:null},{root:{position:[NaN,0,0],rotation:[0,0,0]}},{offsets:{head:[1,0,0]}}])assert.throws(()=>validatePoseLibrary([{...pose,...patch}]));
  assert.throws(()=>validatePoseLibrary([pose,pose]));
});
test('legacy animation clips migrate into sampled complete pose keys without losing root motion',()=>{
  const mesh=generateHumanoid({density:0}),t=defaultTimeline();t.duration=4;t.clips=[{type:'sit',start:0,end:4,speed:1}];
  const root={position:[.1,0,.2],rotation:[0,12,0]},pose={head:[4,0,0]};
  assert.equal(migrateLegacyClips(t,pose,root,{}),true);assert.equal(t.clips.length,0);assert.doesNotThrow(()=>validateTimeline(t));
  for(const time of [0,.5,1,2,3.5,4]){
    const transform=samplePoseTransform(t.poseKeys,time,root,{}),sample=samplePose(t.poseKeys,time,pose);
    const a=evaluateRig(mesh,{clip:time<4?'sit':'stand',time,pose,root:root.position,rootRotation:root.rotation});
    const b=evaluateRig(mesh,{pose:sample,root:transform.root.position,rootRotation:transform.root.rotation});
    for(let i=0;i<a.matrices.length;i++)assert.ok(Math.abs(a.matrices[i]-b.matrices[i])<1e-5);
  }
  assert.equal(migrateLegacyClips(t),false);
});

test('default release never auto-inflates; explicit recovery follows target and duration', () => {
  const t=defaultTimeline();
  assert.equal(t.phases.length,1);
  assert.equal(samplePhase(t.phases,0).binding,1);
  assert.equal(samplePhase(t.phases,4).binding,0);
  assert.equal(samplePhase(t.phases,4).inflation,0);
  assert.equal(samplePhase(t.phases,4,true).seam,0);
  assert.equal(samplePhase(t.phases,25,true).binding,0);
  assert.equal(samplePhase(t.phases,25,true).inflation,0);
  t.phases.push({time:10,type:'inflate'});
  const settings={inflateDuration:3,inflateBinding:.8};
  assert.equal(samplePhase(t.phases,10,false,settings).binding,0);
  assert.ok(samplePhase(t.phases,11.5,false,settings).inflation>.4&&samplePhase(t.phases,11.5,false,settings).inflation<.6);
  assert.equal(samplePhase(t.phases,14,false,settings).binding,.8);
  assert.equal(samplePhase(t.phases,14,false,settings).inflation,1);
});
test('interrupting a phase preserves current binding instead of snapping',()=>{
  const events=[{time:0,type:'release',duration:2}];
  const settings={releaseDuration:2,inflateDuration:2};
  const before=samplePhase(events,1,false,settings).binding;
  events.push({time:1,type:'inflate',duration:2});
  assert.equal(samplePhase(events,1,false,settings).binding,before);
  const beforeRelease=samplePhase(events,1.5,false,settings).binding;
  events.push({time:1.5,type:'release',duration:1});
  assert.equal(samplePhase(events,1.5,false,settings).binding,beforeRelease);
});
test('grab material coordinates survive all density remappings',()=>{
  for(let density=0;density<3;density++)for(let triangle=0;triangle<100;triangle++){
    const original=grabReference(triangle,[.23,.31,.46],density);
    for(let target=0;target<3;target++){
      const mapped=remapGrab(original,target),restored=grabReference(mapped.triangle,mapped.bary,target);
      assert.equal(restored.quad,original.quad);
      assert.ok(Math.abs(restored.uv[0]-original.uv[0])<1e-12);
      assert.ok(Math.abs(restored.uv[1]-original.uv[1])<1e-12);
      assert.ok(mapped.bary.every(v=>v>=0 && v<=1));
    }
  }
});
test('keys sort, replace and interpolate shortest camera yaw',()=>{
  const camera={target:[0,1,0],yaw:3,pitch:0,distance:3,fov:38};
  const keys=[];
  insertKey(keys,{time:2,value:{...camera,yaw:-3}});
  insertKey(keys,{time:0,value:camera});
  assert.ok(Math.abs(sampleCamera(keys,1,camera).yaw-Math.PI)<1e-6);
  insertKey(keys,{time:2,value:{...camera,distance:4}});
  assert.equal(keys.length,2);
  assert.equal(sampleCamera(keys,3,camera).distance,4);
});
test('pose, clip, and grab evaluation is causal',()=>{
  assert.deepEqual(samplePose([{time:0,value:{head:[0,0,0]}},{time:2,value:{head:[20,0,0]}}],1).head,[10,0,0]);
  assert.equal(sampleClip([{type:'walk',start:2,end:4,speed:2}],3).time,1);
  assert.equal(sampleClip([{type:'walk',start:2,end:4,speed:2}],5).clip,'stand');
  const events=[{start:1,end:3,triangle:2,bary:[1,0,0],samples:[{time:1,value:[0,0,0]},{time:3,value:[2,2,2]}]}];
  assert.equal(sampleGrab(events,.5),null);
  assert.deepEqual(sampleGrab(events,2).target,[1,1,1]);
  assert.equal(sampleGrab(events,3),null);
});
test('cache accounts for endpoints and scene schema rejects invalid values',()=>{
  assert.equal(cacheBytes(1000,30,30),1000*901*12);
  assert.equal(validateTimeline(defaultTimeline()).fps,30);
  assert.throws(()=>validateTimeline({...defaultTimeline(),duration:Infinity}));
  assert.throws(()=>validateTimeline({...defaultTimeline(),fps:120}));
  assert.throws(()=>validateTimeline({...defaultTimeline(),phases:[{time:0,type:'bad',duration:1}]}));
});
test('timeline selection IDs survive replacement, serialization and duplicate imports',()=>{
  const t=defaultTimeline();t.cameraKeys=[{id:'k1',time:0,value:{}},{id:'k1',time:1,value:{}},{time:2,value:{}}];
  const first=timelineItems(t).map(e=>e.token);
  assert.equal(new Set(first).size,first.length);
  assert.deepEqual(timelineItems(structuredClone(t)).map(e=>e.token),first);
  const id=t.cameraKeys[0].id;insertKey(t.cameraKeys,{time:0,value:{distance:2}});assert.equal(t.cameraKeys[0].id,id);
});
test('group retime preserves spacing, clips and recorded grab samples at bounds',()=>{
  const t=defaultTimeline();t.clips=[];t.phases=[];
  t.cameraKeys=[{time:2,value:{}},{time:5,value:{}}];
  t.grabs=[{start:3,end:6,samples:[{time:3,value:[0,0,0]},{time:6,value:[1,0,0]}]}];
  const tokens=new Set(timelineItems(t).map(e=>e.token));
  assert.equal(retimeSelection(t,tokens,-10).delta,-2);
  assert.deepEqual(t.cameraKeys.map(k=>k.time),[0,3]);assert.deepEqual(t.grabs[0].samples.map(k=>k.time),[1,4]);
  assert.equal(retimeSelection(t,tokens,100).delta,26);
  assert.equal(t.grabs[0].end,30);assert.equal(t.cameraKeys[1].time-t.cameraKeys[0].time,3);
});
test('camera-only selection edits preserve physics; mixed deletion invalidates it',()=>{
  const t=defaultTimeline();t.cameraKeys=[{time:2,value:{}}];
  const entries=timelineItems(t),camera=new Set(entries.filter(e=>e.type==='camera').map(e=>e.token));
  assert.equal(retimeSelection(t,camera,.27).physics,false);assert.equal(t.cameraKeys[0].time,2+8/30);
  assert.deepEqual(deleteSelection(t,camera),{removed:1,physics:false});
  const all=new Set(timelineItems(t).map(e=>e.token));assert.equal(deleteSelection(t,all).physics,true);
  assert.equal(timelineItems(t).length,0);
});
test('pose transforms interpolate translation, root rotation and local offsets',()=>{
  const root={position:[0,0,0],rotation:[0,0,0]},a={time:0,value:{},root,offsets:{}},b={time:2,value:{},root:{position:[2,1,0],rotation:[0,0,90]},offsets:{head:[.2,0,0]}};
  const sample=samplePoseTransform([a,b],1,root,{});
  assert.deepEqual(sample.root.position,[1,.5,0]);assert.deepEqual(sample.root.rotation,[0,0,45]);assert.deepEqual(sample.offsets.head,[.1,0,0]);
  const fallback=samplePoseTransform([],0,root,{});fallback.root.position[0]=9;assert.equal(root.position[0],0);
});
test('new pose and soft-grab schema rejects malformed values',()=>{
  const t=defaultTimeline();t.poseKeys=[{time:0,value:{},root:{position:[0,0,0],rotation:[0,0,0]},offsets:{head:[.1,0,0]}}];
  assert.doesNotThrow(()=>validateTimeline(t));
  for(const patch of [{root:{position:[Infinity,0,0],rotation:[0,0,0]}},{offsets:{head:[.7,0,0]}},{time:-1}])assert.throws(()=>validateTimeline({...t,poseKeys:[{...t.poseKeys[0],...patch}]}));
  const grab={id:'soft',start:0,end:1,triangle:0,bary:[1,0,0],radius:.18,strength:.8,samples:[{time:0,value:[0,0,0]}]};
  t.grabs=[grab];assert.doesNotThrow(()=>validateTimeline(t));assert.equal(sampleGrab(t.grabs,.5).radius,.18);assert.equal(sampleGrab(t.grabs,.5).id,'soft');
  for(const patch of [{radius:NaN},{radius:1},{strength:2},{samples:[]}])assert.throws(()=>validateTimeline({...t,grabs:[{...grab,...patch}]}));
});
test('furniture uses shared collision transforms and occlusion ray',()=>{
  const o=createObject('chair',1), c=expandColliders([o]);
  assert.equal(c.length,6);
  assert.equal(c[0].size[0],.52);
  assert.ok(Number.isFinite(rayColliderDistance([0,1,3],[0,-.1,-1],c)));
  const sphere=expandColliders([{id:2,kind:'sphere',position:[0,0,0],scale:1,rotation:0}]);
  assert.ok(Math.abs(rayColliderDistance([0,.24,2],[0,0,-1],sphere)-1.76)<1e-6);
});
