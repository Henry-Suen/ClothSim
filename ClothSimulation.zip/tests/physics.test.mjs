import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const source=await readFile(new URL('../src/physics.wgsl',import.meta.url),'utf8');
const body=source.match(/fn volumeFinish\(\) \{([\s\S]*?)\n\}/)?.[1];
assert.ok(body,'volumeFinish shader body must exist');
const evaluate=new Function('params','getFloat','putFloat','max','clamp',body.replace(/\b(\d+)u\b/g,'$1'));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function solve({volume=.0360133333,restVolume=.0360133333,inflation=.002,pressure=1,lambda=0,seam=1,gap=0,denominator=.884723054}={}){
  const scratch=new Map([[2,lambda],[64,volume],[65,denominator],[66,gap]]);
  const params={scratch:{x:64,y:1},control:{x:1/300,z:inflation,w:seam},cloth:{x:.004,z:pressure,w:restVolume}};
  evaluate(params,index=>scratch.get(index)??0,(index,value)=>scratch.set(index,value),Math.max,clamp);
  return {delta:scratch.get(1),lambda:scratch.get(2),volume:scratch.get(0)};
}

test('actual pressure shader does not compress thin layers while deflating',()=>{
  const volume=.0360133333,denominator=.884723054,alpha=.018;
  const oldDelta=clamp((-(volume-volume*.002))/(denominator+alpha),-.05,.05);
  assert.ok(oldDelta<-.039,'The former bilateral equation must reproduce inward pressure');
  const ramp=Array.from({length:151},(_,i)=>{const u=i/150;return 1-u*u*(3-2*u);});
  for(const inflation of [1,.9,.5,.1,.002,.001,0,...ramp]){
    const state=solve({inflation,lambda:.025});
    assert.equal(state.delta,0,`Inflation ${inflation} must not pull the surface inward`);
    assert.equal(state.lambda,0,'Overfilled or inactive pressure must release its multiplier');
  }
});

test('actual pressure shader expands deficient volume but never retains tensile pressure',()=>{
  const expanded=solve({volume:.012,inflation:1});
  assert.ok(expanded.delta>0);assert.ok(expanded.lambda>0);
  const relaxing=solve({volume:.036,inflation:1,lambda:.05});
  assert.equal(relaxing.delta,0);assert.equal(relaxing.lambda,.05);
  const invalidPrior=solve({volume:.012,inflation:1,lambda:-.02});
  assert.ok(invalidPrior.delta>=0);assert.ok(invalidPrior.lambda>=0);
});

test('pressure deactivation and an open seam clear multiplier without moving vertices',()=>{
  for(const patch of [{pressure:0},{inflation:0},{seam:0},{gap:.02}]){
    const state=solve({volume:.012,inflation:1,lambda:.03,...patch});
    assert.equal(state.delta,0);assert.equal(state.lambda,0);assert.equal(state.volume,.012);
  }
});
