import test from 'node:test';
import assert from 'node:assert/strict';
import { createCamera, getCameraPosition, moveCamera, cameraRay, projectPoint } from '../src/renderer.js';

function close(actual, expected, tolerance = 1e-10) {
  assert.equal(actual.length, expected.length);
  actual.forEach((value, index) => assert.ok(Math.abs(value - expected[index]) < tolerance,
    `${value} should match ${expected[index]} at component ${index}`));
}

function cameraAtOrigin() {
  return { ...createCamera(), target: [0, 0, 0], yaw: 0, pitch: 0 };
}

test('free camera moves forward, right, and up without changing its orbit', () => {
  for (const [movement, expected] of [
    [{ forward: 1 }, [0, 0, -0.12]],
    [{ right: 1 }, [0.12, 0, 0]],
    [{ up: 1 }, [0, 0.12, 0]],
    [{ forward: -1 }, [0, 0, 0.12]],
    [{ right: -1 }, [-0.12, 0, 0]],
    [{ up: -1 }, [0, -0.12, 0]],
  ]) {
    const camera = cameraAtOrigin();
    const before = structuredClone(camera);
    const eye = getCameraPosition(camera);
    moveCamera(camera, movement, 0.1);
    close(camera.target, expected);
    close(getCameraPosition(camera), eye.map((value, index) => value + expected[index]));
    assert.equal(camera.distance, before.distance);
    assert.equal(camera.yaw, before.yaw);
    assert.equal(camera.pitch, before.pitch);
    assert.equal(camera.fov, before.fov);
  }
});

test('forward and right follow camera orientation while up stays world Y', () => {
  const camera = { ...cameraAtOrigin(), yaw: Math.PI / 2, pitch: Math.PI / 6 };
  moveCamera(camera, { forward: 1 }, 0.1, 2);
  close(camera.target, [-Math.sqrt(3) * 0.1, -0.1, 0]);
  camera.target = [0, 0, 0];
  moveCamera(camera, { right: 1 }, 0.1, 2);
  close(camera.target, [0, 0, -0.2]);
  camera.target = [0, 0, 0];
  moveCamera(camera, { up: 1 }, 0.1, 2);
  close(camera.target, [0, 0.2, 0]);
});

test('free camera clamps elapsed time and diagonal speed', () => {
  const camera = cameraAtOrigin();
  moveCamera(camera, { forward: 1, right: 1, up: 1 }, 10, 2);
  close(camera.target, [0.2 / Math.sqrt(3), 0.2 / Math.sqrt(3), -0.2 / Math.sqrt(3)]);
  assert.ok(Math.abs(Math.hypot(...camera.target) - 0.2) < 1e-10);
  const previous = [...camera.target];
  moveCamera(camera, { forward: 1 }, -1);
  moveCamera(camera, {}, 0.1);
  close(camera.target, previous);
  const pitched = { ...cameraAtOrigin(), pitch: -0.9 };
  moveCamera(pitched, { forward: 1, up: 1 }, 0.1, 2);
  assert.ok(Math.hypot(...pitched.target) <= 0.2 + 1e-10);
});

test('free camera preserves elapsed-time scaling and analog movement', () => {
  const camera = cameraAtOrigin();
  moveCamera(camera, { right: 0.5 }, 0.05, 2);
  close(camera.target, [0.05, 0, 0]);
  const oneStep = cameraAtOrigin();
  const twoSteps = cameraAtOrigin();
  moveCamera(oneStep, { forward: 1 }, 0.08);
  moveCamera(twoSteps, { forward: 1 }, 0.04);
  moveCamera(twoSteps, { forward: 1 }, 0.04);
  close(oneStep.target, twoSteps.target);
});

test('camera rays project back to their viewport pixels after movement', () => {
  const camera = createCamera();
  moveCamera(camera, { forward: 1, right: -1, up: 1 }, 0.07);
  for (const [width, height] of [[1280, 720], [600, 1000]]) {
    close(projectPoint(camera, camera.target, width, height), [width / 2, height / 2]);
    for (const [x, y] of [[width / 2, height / 2], [0, 0], [width, height], [width * 0.2, height * 0.75]]) {
      const ray = cameraRay(camera, x, y, width, height);
      assert.ok(Math.abs(Math.hypot(...ray.direction) - 1) < 1e-10);
      const point = ray.origin.map((value, index) => value + ray.direction[index] * 3);
      close(projectPoint(camera, point, width, height), [x, y], 1e-8);
    }
  }
});

test('projection rejects points at or behind the camera', () => {
  const camera = createCamera();
  const ray = cameraRay(camera, 320, 240, 640, 480);
  assert.equal(projectPoint(camera, ray.origin, 640, 480), null);
  assert.equal(projectPoint(camera, ray.origin.map((value, index) => value - ray.direction[index]), 640, 480), null);
});
