import { chromium } from 'playwright-core';
import { build } from 'esbuild';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';

const root = fileURLToPath(new URL('../', import.meta.url));
const source = (await readFile(new URL('../src/solver.js', import.meta.url), 'utf8')).replace(
  '    positions, normals, vertexCount: count,',
  `    positions, normals, vertexCount: count,
    testStage(name, count = 10) {
      const commands = begin('Test-only compute stage profile');
      for (let i = 0; i < count; i++) dispatch(commands.pass, name, groups(name === 'surfaceLeafBounds' ? Math.max(prepared.count, prepared.surfaceLeafCount) : name === 'surfaceBounds' ? prepared.surfaceNodeCount : triangleCount));
      end(commands);
    },
    async testStats() {
      const words = new Uint32Array(await readBuffer(scratchBuffer, 16, 48));
      const contacts = new Uint32Array(await readBuffer(scratchBuffer, surfaceContactOffset * 4, count * 16));
      let contributions = 0;
      for (let i = 3; i < contacts.length; i += 4) contributions += contacts[i];
      return { candidatePairs: words[11], vertexTriangleCalls: words[2], edgeEdgeCalls: words[3], coplanarCalls: words[0], contributions };
    },
    testLocalContact() {
      const commands = begin('Test-only local VT owner fallback');
      dispatch(commands.pass, 'surfaceLeafBounds', groups(Math.max(count, prepared.surfaceLeafCount)));
      dispatch(commands.pass, 'fixtureLocalContact', 1);
      dispatch(commands.pass, 'applySurfaceContacts');
      end(commands);
    },
    testSurface() {
      const commands = begin('Test-only prescribed linear sweep');
      const pass = commands.pass;
      for (let iteration = 0; iteration < PROFILES.preview.contacts; iteration++) {
        dispatch(pass, 'surfaceLeafBounds', groups(Math.max(count, prepared.surfaceLeafCount)));
        dispatch(pass, 'surfaceBounds', groups(prepared.surfaceNodeCount));
        dispatch(pass, 'surfaceContacts', groups(triangleCount));
        dispatch(pass, 'applySurfaceContacts');
      }
      end(commands);
    },`,
);
const baseline = process.argv.includes('--baseline');
const solverSource = (baseline ? source
  .replaceAll(/dispatch\((?:commands\.)?pass, '(surfaceLeafBounds|surfaceBounds|surfaceContacts|applySurfaceContacts)'[^;]*;/g, '') : source)
  .replace('const ENTRY_POINTS = [', "const ENTRY_POINTS = ['fixtureLocalContact',");
let shader = await readFile(new URL('../src/physics.wgsl', import.meta.url), 'utf8');
shader += '\n@compute @workgroup_size(1) fn fixtureLocalContact() { vertexTriangleContact(2u, 1u, triangle(1u)); }';
if(process.argv.includes('--human')){
  shader='var<private> fixtureStats: vec4<u32>;\n'+shader.replace('fn surfaceLeafBounds(@builtin(global_invocation_id) gid: vec3<u32>) {', 'fn surfaceLeafBounds(@builtin(global_invocation_id) gid: vec3<u32>) {\n  if(gid.x==0u){atomicStore(&scratch[4u],0u);atomicStore(&scratch[6u],0u);atomicStore(&scratch[7u],0u);atomicStore(&scratch[15u],0u);}')
    .replace('fn coplanarRoots(a: u32, b: u32, c: u32, d: u32) -> vec3<f32> {','fn coplanarRoots(a: u32, b: u32, c: u32, d: u32) -> vec3<f32> {\n  fixtureStats.x+=1u;')
    .replace('fn vertexTriangleContact(pointId: u32, faceId: u32, ids: vec3<u32>) {','fn vertexTriangleContact(pointId: u32, faceId: u32, ids: vec3<u32>) {\n  fixtureStats.y+=1u;')
    .replace('fn edgeEdgeContact(aId: u32, bId: u32, cId: u32, dId: u32, firstFace: u32, secondFace: u32) {','fn edgeEdgeContact(aId: u32, bId: u32, cId: u32, dId: u32, firstFace: u32, secondFace: u32) {\n  fixtureStats.z+=1u;')
    .replace('// 每个顶点/边由唯一的关联面发射，避免一环重复接触与原子竞争。','fixtureStats.w+=1u;\n        // 每个顶点/边由唯一的关联面发射，避免一环重复接触与原子竞争。')
    .replace('    node++;\n  }\n}', '    node++;\n  }\n  atomicAdd(&scratch[4u],fixtureStats.x);atomicAdd(&scratch[6u],fixtureStats.y);atomicAdd(&scratch[7u],fixtureStats.z);atomicAdd(&scratch[15u],fixtureStats.w);\n}');
}
const bundled = await build({
  stdin: { contents: solverSource.replace('export async function createSolver', 'async function createSolver') + '\nimport { generateHumanoid } from "./geometry.js"; globalThis.createTestMesh = generateHumanoid; globalThis.createTestSolver = createSolver;', resolveDir: `${root}/src`, loader: 'js' },
  bundle: true, write: false, format: 'iife', loader: { '.wgsl': 'text' },
  plugins: [{ name: 'fixture-shader', setup(build) { build.onLoad({ filter: /\.wgsl$/ }, () => ({ contents: shader, loader: 'text' })); } }],
});
const browser = await chromium.launch({ channel: process.env.TEST_BROWSER || 'chrome', headless: true });
try {
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.route('http://127.0.0.1/**', route => route.fulfill({ contentType: 'text/html', body: '<!doctype html><title>Surface contact fixture</title>' }));
  await page.goto('http://127.0.0.1/');
  await page.addScriptTag({ content: bundled.outputFiles[0].text });
  const results = await page.evaluate(async ({profile,human,frames}) => {
    const adapter = await navigator.gpu.requestAdapter();
    if (!adapter) throw new Error('WebGPU adapter unavailable');
    const device = await adapter.requestDevice();
    const gpuErrors = [];
    device.addEventListener('uncapturederror', event => gpuErrors.push(event.error.message));
    if(profile){
      const mesh=createTestMesh(),solver=await createTestSolver(device,mesh),stages={};
      await device.queue.onSubmittedWorkDone();
      for(const name of ['surfaceLeafBounds','surfaceBounds','surfaceContacts']){
        const start=performance.now();solver.testStage(name);await device.queue.onSubmittedWorkDone();stages[name]=(performance.now()-start)/10;
      }
      solver.reset();await device.queue.onSubmittedWorkDone();
      const start=performance.now();for(let i=0;i<5;i++)solver.step(1/60,{binding:1,inflation:1});await device.queue.onSubmittedWorkDone();
      const frameMs=(performance.now()-start)/5;
      solver.destroy();device.destroy();return{profile:{vertices:mesh.vertexCount,triangles:mesh.indices.length/3,stages,frameMs},gpuErrors,results:[],sweeps:[]};
    }
    const sub = (a,b) => a.map((x,k)=>x-b[k]);
    const dot = (a,b) => a.reduce((s,x,k)=>s+x*b[k],0);
    const cross = (a,b) => [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
    const segmentTriangle = (a,b,p,q,r) => {
      const direction=sub(b,a), edge1=sub(q,p), edge2=sub(r,p), h=cross(direction,edge2), determinant=dot(edge1,h);
      if(Math.abs(determinant)<1e-10)return false;
      const s=sub(a,p),u=dot(s,h)/determinant,v=dot(direction,cross(s,edge1))/determinant,t=dot(edge2,cross(s,edge1))/determinant;
      return u>1e-6&&v>1e-6&&u+v<1-1e-6&&t>1e-6&&t<1-1e-6;
    };
    const crossings = (xyz,indices,examples) => {
      const faces=[];
      for(let i=0;i<indices.length;i+=3){
        const ids=Array.from(indices.slice(i,i+3)),points=ids.map(v=>Array.from(xyz.slice(v*3,v*3+3)));
        faces.push({ids,points,low:[0,1,2].map(axis=>Math.min(...points.map(p=>p[axis]))),high:[0,1,2].map(axis=>Math.max(...points.map(p=>p[axis])))});
      }
      faces.sort((a,b)=>a.low[0]-b.low[0]);
      let count=0;
      for(let i=0;i<faces.length;i++)for(let j=i+1;j<faces.length&&faces[j].low[0]<=faces[i].high[0];j++){
        const a=faces[i],b=faces[j];
        if(a.high[1]<b.low[1]||b.high[1]<a.low[1]||a.high[2]<b.low[2]||b.high[2]<a.low[2]||a.ids.some(v=>b.ids.includes(v)))continue;
        if(a.points.some((p,k)=>segmentTriangle(p,a.points[(k+1)%3],...b.points))||b.points.some((p,k)=>segmentTriangle(p,b.points[(k+1)%3],...a.points))){
          count++;
          if(examples&&examples.length<4)examples.push({ids:[a.ids,b.ids],points:[a.points,b.points]});
        }
      }
      return count;
    };
    const volume = (xyz,indices) => {
      let sum=0;
      for(let i=0;i<indices.length;i+=3){const points=Array.from(indices.slice(i,i+3),id=>Array.from(xyz.slice(id*3,id*3+3)));sum+=dot(points[0],cross(points[1],points[2]))/6;}
      return sum;
    };
    const meshFrom = (points, faces) => ({ positions: new Float32Array(points.flatMap(p=>[...p,1])), indices:new Uint32Array(faces.flat()), vertexCount:points.length });
    const material = { stretch:1e-7,bend:1e-4,thickness:0.004,damping:0,friction:0.2 };
    if(human){
      const mesh=createTestMesh(),solver=await createTestSolver(device,mesh);
      solver.reset({offset:[0,0.12,0]});
      const initial=await solver.readPositions(),orientation=Math.sign(volume(initial,mesh.indices)),samples=[];
      let minVolume=Infinity,maxCrossings=crossings(initial,mesh.indices),negativeSamples=0;
      samples.push({frame:0,crossings:maxCrossings,volume:volume(initial,mesh.indices)*orientation});
      let batchStart=performance.now();
      for(let frame=1;frame<=frames;frame++){
        const u=Math.max(0,Math.min(1,(frame/60-.1)/.5)),inflation=1-u*u*(3-2*u);
        solver.step(1/60,{binding:inflation,inflation,seam:1,material:{...material,damping:1.5,friction:0.5,pressure:1},quality:'preview'});
        if(frame%15===0){
          await device.queue.onSubmittedWorkDone();
          const msPerFrame=(performance.now()-batchStart)/15;
          const xyz=await solver.readPositions(),v=volume(xyz,mesh.indices)*orientation;
          const examples=frame===frames?[]:undefined;
          const crossStart=performance.now(),crossCount=crossings(xyz,mesh.indices,examples),crossCpuMs=performance.now()-crossStart;
          maxCrossings=Math.max(maxCrossings,crossCount);minVolume=Math.min(minVolume,v);if(v<0)negativeSamples++;
          samples.push({frame,msPerFrame,crossings:crossCount,crossCpuMs,volume:v,examples,...await solver.testStats()});
          batchStart=performance.now();
        }
      }
      solver.destroy();device.destroy();return{human:{vertices:mesh.vertexCount,triangles:mesh.indices.length/3,maxCrossings,minVolume,negativeSamples,samples},gpuErrors,results:[],sweeps:[]};
    }
    const run = async (name,mesh,velocity,frames,overrides={}) => {
      const solver=await createTestSolver(device,mesh);
      if(velocity){const state=await solver.readState(),f=new Float32Array(state.data);for(let i=0;i<mesh.vertexCount;i++)f.set(velocity(i),mesh.vertexCount*4+i*40+8);solver.writeState(state);}
      const initial=await solver.readPositions();
      const initialVolume=volume(initial,mesh.indices);
      const closed=name.startsWith('closed-');
      let maxCrossings=0,negativeFrames=0,minVolume=Infinity,solveReadbackMs=0;
      const started=performance.now();
      let xyz=initial;
      for(let frame=0;frame<frames;frame++){
        const gpuStarted=performance.now();
        solver.step(1/60,{binding:0,inflation:0,seam:1,material:{...material,...overrides},quality:'preview'});
        xyz=await solver.readPositions();
        solveReadbackMs+=performance.now()-gpuStarted;
        maxCrossings=Math.max(maxCrossings,crossings(xyz,mesh.indices));
        const v=volume(xyz,mesh.indices)*Math.sign(initialVolume||1);
        minVolume=Math.min(minVolume,v);if(v<0)negativeFrames++;
      }
      const diagnostics=await solver.diagnostics();
      const result={name,frames,initialCrossings:crossings(initial,mesh.indices),maxCrossings,finalCrossings:crossings(xyz,mesh.indices),initialVolume:closed?initialVolume:null,minVolume:closed?minVolume:null,negativeFrames:closed?negativeFrames:null,solveReadbackMs,elapsedMs:performance.now()-started,finite:diagnostics.finite,hashOverflow:diagnostics.hashOverflow};
      solver.destroy();return result;
    };
    const runSweep=async(name,points)=>{
      const sweepMesh=meshFrom(points,[[0,1,2],[3,4,5]]);
      const sweptSolver=await createTestSolver(device,sweepMesh);
      const sweepState=await sweptSolver.readState(),sweepFloats=new Float32Array(sweepState.data);
      for(let i=3;i<6;i++)sweepFloats[i*4+2]-=0.12;
      sweptSolver.writeState(sweepState);sweptSolver.testSurface();
      const swept=await sweptSolver.readPositions();
      const a=Array.from(swept.slice(0,3)),b=Array.from(swept.slice(3,6)),c=Array.from(swept.slice(6,9));
      const normal=cross(sub(b,a),sub(c,a)),normalLength=Math.hypot(...normal);
      const sweptMinSide=Math.min(...[3,4,5].map(i=>dot(sub(Array.from(swept.slice(i*3,i*3+3)),a),normal)/normalLength));
      const result={name,sweptMinSide,finalCrossings:crossings(swept,sweepMesh.indices)};
      sweptSolver.destroy();return result;
    };
    const localMesh=meshFrom([[-.02,1,0],[.02,1,0],[0,1.004,0],[0,.98,0],[0,1.04,0],[.02,1.04,0]],[[0,1,2],[1,0,3],[2,4,5]]);
    const localSolver=await createTestSolver(device,localMesh);
    const localBefore=await localSolver.readPositions();localSolver.testLocalContact();
    const localAfter=await localSolver.readPositions();
    const localDelta=Math.max(...localAfter.map((v,i)=>Math.abs(v-localBefore[i])));
    localSolver.destroy();
    const sweeps=[
      await runSweep('prescribed-full-VT-tunneling',[[-0.5,0.5,0],[0.5,0.5,0],[0,1.5,0],[-0.1,0.8,0.03],[0.1,0.8,0.03],[0,1.1,0.03]]),
      await runSweep('prescribed-full-EE-tunneling',[[-1,0.9,0],[1,0.9,0],[1,1.1,0],[-0.1,0,0.03],[-0.1,2,0.03],[0.1,2,0.03]]),
    ];
    const results=[];
    results.push(await run('coarse-vertex-face',meshFrom([
      [-0.5,0.5,0],[0.5,0.5,0],[0,1.5,0],
      [0,0.9,0.012],[-0.07,1.05,0.09],[0.07,1.05,0.09],
    ],[[0,1,2],[3,4,5]]),i=>[0,0,i>=3?-2:0],4));
    results.push(await run('edge-edge',meshFrom([
      [-0.4,0.8,0],[0.4,0.8,0],[0,0.5,0],
      [0,0.3,0.015],[0,1.1,0.015],[0,0.7,0.25],
    ],[[0,1,2],[3,4,5]]),i=>[0,0,i>=3?-2:0],4));
    results.push(await run('closed-tetrahedron-inversion',meshFrom([
      [-0.4,1,-0.3],[0.4,1,-0.3],[0,1,0.4],[0,1.02,0],
    ],[[0,1,2],[0,3,1],[1,3,2],[2,3,0]]),i=>[0,i===3?-2:0,0],12,{stretch:1,bend:0.1}));
    const points=[],faces=[],rings=8,segments=12,radius=0.18;
    points.push([0,0.46,0]);
    for(let r=1;r<rings;r++){const theta=Math.PI*r/rings;for(let s=0;s<segments;s++){const phi=Math.PI*2*s/segments;points.push([radius*Math.sin(theta)*Math.cos(phi),0.28+radius*Math.cos(theta),radius*Math.sin(theta)*Math.sin(phi)]);}}
    const bottom=points.length;points.push([0,0.1,0]);
    for(let s=0;s<segments;s++)faces.push([0,1+(s+1)%segments,1+s]);
    for(let r=0;r<rings-2;r++)for(let s=0;s<segments;s++){const a=1+r*segments+s,b=1+r*segments+(s+1)%segments,c=a+segments,d=b+segments;faces.push([a,b,c],[b,d,c]);}
    for(let s=0;s<segments;s++)faces.push([bottom,1+(rings-2)*segments+s,1+(rings-2)*segments+(s+1)%segments]);
    results.push(await run('closed-shell-collapse',meshFrom(points,faces),()=>[0,-2,0],90,{stretch:1,bend:0.1}));
    await device.queue.onSubmittedWorkDone();device.destroy();
    return {results,sweeps,localDelta,gpuErrors};
  },{profile:process.argv.includes('--profile'),human:process.argv.includes('--human'),frames:Number(process.env.PHYSICS_FRAMES||180)});
  console.log(JSON.stringify({baseline,...results,errors},null,2));
  assert.deepEqual(errors,[]);assert.deepEqual(results.gpuErrors,[]);
  if(results.human&&!baseline){
    assert.equal(results.human.negativeSamples,0,'人体释放不能出现负有符号体积');
    assert.equal(results.human.maxCrossings,results.human.samples[0].crossings,'人体释放不能增加非相邻三角形交叉');
  }
  if(results.localDelta!==undefined)assert.ok(baseline?results.localDelta===0:results.localDelta>1e-5,'局部邻域不能因规范面包含源点而漏掉接触');
  for(const result of results.results){
    assert.equal(result.finite,true);assert.equal(result.hashOverflow,0);
    if(!baseline){assert.equal(result.maxCrossings,0,`${result.name}: triangle crossings`);if(result.name.startsWith('closed-'))assert.equal(result.negativeFrames,0,`${result.name}: negative volume`);}
  }
  for(const sweep of results.sweeps)assert.ok(baseline ? sweep.sweptMinSide < 0 : sweep.sweptMinSide > 0, `${sweep.name}: Full tunneling must be stopped by continuous contact, not endpoint overlap`);
  if(baseline&&!results.profile&&!results.human){assert.equal(results.results[0].maxCrossings,1);assert.equal(results.results[1].maxCrossings,1);assert.ok(results.results[2].negativeFrames>0);}
} finally { await browser.close(); }
