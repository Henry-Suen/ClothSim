# 布料模拟 — Offline GPU Cloth Studio

A self-contained, offline WebGPU humanoid-shell simulation prototype. Open **`cloth-studio.html` in Chrome or Edge** with graphics acceleration enabled. Only this HTML file is needed to run it; no CDN, downloads, account, installation, or runtime dependencies.

If your browser blocks local-file WebGPU, serve the same directory locally:

```powershell
python -m http.server 8000 --bind 127.0.0.1 --directory F:\Tools\ClothSimulation
```

Open `http://127.0.0.1:8000/cloth-studio.html`. This does not require internet access. Windows graphics settings can assign your browser to the NVIDIA GPU; `powerPreference` alone does not guarantee adapter selection.

## Using the studio

- The complete UI is Chinese. Choose one of the five body presets; the five **体型混合** weight sliders are hidden from the UI so users cannot adjust them, while blend weights stored in older scenes are still honored (vertices and bone rest positions blend continuously and normalize to a total of one). Nose, fingers, and toes are connected geometry, with shaped biceps, belly, calves, neck, skull and ankles. **面部着色** selects per-pixel analytic shading (clear eyes, mouth and beard at any mesh density) or the faster per-vertex bake, independently of the mesh precision.
- Appearance controls include scalp hair, closed eyes, a lower-face full beard, procedural ear details, simple chest markings and skin/eye/lip/hair colors. Body hair has been removed. **服装** offers plain boxers, T-shirt with shorts, and jacket with trousers; upper/lower garment colors are editable. These are opaque surface textures, not separate garments.
- **Play / Space** runs a 30-second sequence with release at 1 second and **no automatic inflation**. Release/recovery buttons sit beside transport controls. Target binding and transition time are editable: release defaults to 2% over 0.3 seconds, recovery to 100% over 3 seconds. Binding percentages use number inputs and, like the durations, apply to the running simulation immediately without resetting it (existing bake caches invalidate). Recovery is an explicit button/timeline event.
- Select **抓取** mode before left-dragging the shell. A radius-weighted surface patch follows the cursor rather than only three triangle vertices. **Shift + wheel** adjusts depth. Camera mode never grabs cloth. Right-drag orbits, middle-drag pans, wheel zooms; **WASD** moves the camera, **Q/E** moves down/up, **Shift** speeds up movement, and **F** frames the subject. Keyboard movement is disabled in text/number inputs.
- **姿势预设** provides static **站立 / 走姿 / 坐姿 / 躺姿 / 趴着**; choosing a preset applies it immediately without a separate Apply button. In **姿势** mode, drag joint axes/rings or edit numerical values; **根节点** transforms the whole character. Enter a name and click **保存为新姿势** to add a custom preset. Presets persist in the current browser, are included in scene files, and support **导出姿势库 / 导入姿势库** for portable backups. Joint translation changes bone length; this is FK editing, not IK.
- Editing a static pose does not automatically create timeline keys. Use **+ 姿势关键帧** when time-varying poses are wanted; once a pose track exists, further edits update its current key. Old animation clips are migrated to sampled pose keys when loading older files; the clip editor is removed.
- Drag the timeline ruler/playhead to scrub; while paused this only moves the playhead and skeleton (no forward physics, which is reserved for playback and baking, so keyframe editing stays responsive). **框选** or Shift-drag on empty tracks selects multiple items; Ctrl/Shift-click adds/removes items. Drag selected items to retime as a group and press **Delete/Backspace** to delete. **清空时间轴** immediately empties every track, disables camera recording, invalidates cache and returns time to zero while keeping the base pose/model/material. **撤销清空** restores the last cleared timeline. This avoids native confirmation dialogs that some embedded browsers suppress. **保存时间轴 / 载入时间轴** manage timeline files separately. Camera-only edits preserve the simulation cache.
- **布娃娃** uses fifteen CPU-driven rigid bodies: a head sphere, neck/torso/limb capsules and flat foot boxes; individual fingers/toes are not simulated. It drives bone matrices and existing skin weights. Bodies now collide with each other through cheap sphere proxies, contact generation is broadphase-culled and pooled, and the debug hulls render at low tessellation. The **布娃娃** and **释放并放气后自动开启布娃娃** toggles sit in the transport bar left of **重置模拟**. Pose editing is disabled while active; switching the ragdoll off stops rigid-body driving and freezes the skeleton exactly where the simulation left it without clearing existing pose keys, leaving the result as an unkeyed pose until **+ 姿势关键帧** records it (recovery/inflation does the same before continuing). Per-body locks fix center position but not rotation. Automatic ragdoll entry at release is enabled by default and can be disabled. Scene JSON preserves settings and locks, not instantaneous rigid-body velocities.
- The inspector's leftmost **通用** tab is contextual: rotating the camera shows FOV, a live camera readout, camera keying and recording, while the grab tool shows grab radius/strength. **重置模拟** resets physics and restores the pose currently selected in **姿势预设**, clearing pose keys. **网格精度** is annotated with the accuracy/performance trade-off. Rig overlays appear only while **姿势** mode is active.
- The viewport's **重力** toggle/value affects both shell and ragdoll. A grab started before the release event disables gravity, shows a viewport notice and turns the gravity button red until gravity is re-enabled; once a release has produced simulation results the grab leaves gravity untouched. The app stays in grab mode. Playing exits pose mode and hides rig overlays. Right-drag orbiting never switches the **通用** inspector page. Colliders use viewport pivot translation/rotation; chair/sofa backs have physical tilt. Interior and open-spine seam colors are editable; hiding the ground shows a pure-black background without disabling ground collision.
- Use **Bake** for higher solver accuracy and cached playback. The bake panel has its own **烘焙网格精度** setting (default 低, independent of the **网格精度** used for live preview): baking rebuilds the working mesh at that density and plays the cache at it, while **恢复实时模拟** rebuilds at the preview density. Scrub with the timeline. A 295-second submission deadline leaves time for readbacks; incomplete results are marked partial. Cancellation and a 512 MiB session-cache budget prevent unbounded work.
- **Save scene** exports settings, poses, timeline, and recorded grabs as JSON. The large baked mesh cache stays in memory and is not exported. Camera/appearance changes preserve it; physics edits invalidate it. To manipulate a baked frame, choose **Resume live simulation** (resimulates from a dynamic checkpoint).

## Resolution and quality

| Density | Vertices, closed shell | Triangles | 30 s / 30 FPS position cache |
| --- | ---: | ---: | ---: |
| Low | 4,860 | 9,716 | 50 MiB |
| Medium | 19,434 | 38,864 | 200 MiB |
| High | 77,730 | 155,456 | 801 MiB — exceeds cache budget; shorten the clip |

Opening the spine seam adds a few duplicate boundary vertices. Topology remains fixed during a simulation. Preview uses 5 substeps × 4 constraint iterations; bake uses 14 × 7, plus extra contact passes. The same GPU positions are used for rendering, without per-frame full-mesh preview readback.

**Boundaries:** artistic thin-shell physics, not an engineering material model. Self-contact now uses swept triangle BVH candidate pairs, two-way vertex–triangle and edge–edge contacts plus hashed vertex fallback; it is iterative and not intersection-free, especially for dense folds, near-ground contacts and coplanar sweeps. Ragdoll joints/collisions are lightweight CPU approximations, not a general-purpose rigid-body engine. Fully tangled folds are not guaranteed to recover. Boxers are fitted surface detail, not a second simulated garment. Posing is body-joint FK, not individual digit controls or full IK. Clip boundaries are not automatically crossfaded. One humanoid and five scene objects are supported. Higher-quality baking is not a promise of production-quality contact.

## Development and verification

Node.js 22+ is required only for development. Pinned development dependencies are in `package.json` / `package-lock.json`; runtime code/assets are original procedural code.

```powershell
npm ci
npm run build
npm test
npm run test:browser
npm run benchmark
```

`test:browser` uses installed headless Chrome with networking disabled; set `$env:TEST_BROWSER = 'msedge'` to test installed Edge. It checks GPU startup, body blending, clothing controls, mode isolation, keyboard camera movement, mouse joint/root gizmos, marquee/group retiming/deletion, timeline file round-trip, collapse/recovery, soft-area grabbing, spine seams, cached mouse scrubbing, scene round-trip, and partial-deadline handling. The revision passes 41 unit tests and both Chrome/Edge offline browser suites; an 18 cm grab affected 42 vertices at low density and 171 at medium density. `benchmark` measures 4,860-vertex live preview and a 19,434-vertex, 30-second/30-FPS bake at a 1920×1080 browser viewport.

Historical measurement before the face-level collision revision, on **RTX 4060 8 GB**, NVIDIA driver 596.49, hardware-accelerated headless Chrome at a 1920×1080 viewport: the 4,860-vertex preview averaged **60.07 FPS** (about 59.52 FPS at the low percentile); the revised 19,434-vertex, ground-only 30-second/30-FPS sequence baked all **901 frames in 126.27 seconds**, using 200.39 MiB of position cache. The benchmark includes drop/deflation and assisted recovery; no collision candidates were truncated. This is a timing and functional check, not certification of intersection-free cloth.

This machine is **not an RTX 3080**. RTX 3080 timing requires running the benchmark on that GPU. Calibration extrapolates a two-second sample; dense contact can cost more. The application reports actual completion rather than silently reducing quality to meet a time estimate.
