const EPSILON = 1e-10;
const IDENTITY_QUATERNION = [0, 0, 0, 1];

const add = (a, b) => a.map((value, axis) => value + b[axis]);
const sub = (a, b) => a.map((value, axis) => value - b[axis]);
const mul = (a, scalar) => a.map(value => value * scalar);
const dot = (a, b) => a.reduce((sum, value, axis) => sum + value * b[axis], 0);
const cross = (a, b) => [
  a[1] * b[2] - a[2] * b[1],
  a[2] * b[0] - a[0] * b[2],
  a[0] * b[1] - a[1] * b[0],
];
const length = a => Math.hypot(...a);
const normalize = (a, fallback = [0, 1, 0]) => {
  const magnitude = length(a);
  return magnitude > EPSILON ? mul(a, 1 / magnitude) : fallback.slice();
};
const clamp = (value, low, high) => Math.max(low, Math.min(high, value));

function quaternionNormalize(q) {
  const magnitude = Math.hypot(...q);
  if (!Number.isFinite(magnitude) || magnitude < EPSILON) throw new Error('Ragdoll orientation is not finite.');
  return q.map(value => value / magnitude);
}

function quaternionMultiply(a, b) {
  return [
    a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
    a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
    a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
    a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2],
  ];
}

const quaternionConjugate = q => [-q[0], -q[1], -q[2], q[3]];

function quaternionRotate(q, vector) {
  const [x, y, z, w] = q, [vx, vy, vz] = vector;
  const tx = 2 * (y * vz - z * vy), ty = 2 * (z * vx - x * vz), tz = 2 * (x * vy - y * vx);
  return [
    vx + w * tx + y * tz - z * ty,
    vy + w * ty + z * tx - x * tz,
    vz + w * tz + x * ty - y * tx,
  ];
}

function quaternionFromY(direction) {
  const y = normalize(direction);
  const d = clamp(y[1], -1, 1);
  if (d < -1 + 1e-8) return [1, 0, 0, 0];
  const axis = cross([0, 1, 0], y);
  return quaternionNormalize([...axis, 1 + d]);
}

function quaternionFromMatrix(m) {
  const trace = m[0] + m[5] + m[10];
  let q;
  if (trace > 0) {
    const s = Math.sqrt(trace + 1) * 2;
    q = [(m[6] - m[9]) / s, (m[8] - m[2]) / s, (m[1] - m[4]) / s, s / 4];
  } else if (m[0] > m[5] && m[0] > m[10]) {
    const s = Math.sqrt(1 + m[0] - m[5] - m[10]) * 2;
    q = [s / 4, (m[4] + m[1]) / s, (m[8] + m[2]) / s, (m[6] - m[9]) / s];
  } else if (m[5] > m[10]) {
    const s = Math.sqrt(1 + m[5] - m[0] - m[10]) * 2;
    q = [(m[4] + m[1]) / s, s / 4, (m[9] + m[6]) / s, (m[8] - m[2]) / s];
  } else {
    const s = Math.sqrt(1 + m[10] - m[0] - m[5]) * 2;
    q = [(m[8] + m[2]) / s, (m[9] + m[6]) / s, s / 4, (m[1] - m[4]) / s];
  }
  return quaternionNormalize(q);
}

function quaternionMatrix(q) {
  const [x, y, z, w] = q;
  const xx = x * x, yy = y * y, zz = z * z;
  const xy = x * y, xz = x * z, yz = y * z, wx = w * x, wy = w * y, wz = w * z;
  return [
    1 - 2 * (yy + zz), 2 * (xy + wz), 2 * (xz - wy), 0,
    2 * (xy - wz), 1 - 2 * (xx + zz), 2 * (yz + wx), 0,
    2 * (xz + wy), 2 * (yz - wx), 1 - 2 * (xx + yy), 0,
    0, 0, 0, 1,
  ];
}

function multiply(a, b) {
  const out = new Float64Array(16);
  for (let column = 0; column < 4; column++) for (let row = 0; row < 4; row++) {
    for (let k = 0; k < 4; k++) out[column * 4 + row] += a[k * 4 + row] * b[column * 4 + k];
  }
  return out;
}

function transformPoint(matrix, point) {
  return [0, 1, 2].map(row => matrix[row] * point[0] + matrix[4 + row] * point[1] + matrix[8 + row] * point[2] + matrix[12 + row]);
}

function inverseRigid(matrix) {
  const out = new Float64Array(16);
  for (let row = 0; row < 3; row++) for (let column = 0; column < 3; column++) out[column * 4 + row] = matrix[row * 4 + column];
  const translation = [matrix[12], matrix[13], matrix[14]];
  const inverseTranslation = mul(transformPoint(out, translation), -1);
  out[12] = inverseTranslation[0]; out[13] = inverseTranslation[1]; out[14] = inverseTranslation[2]; out[15] = 1;
  return out;
}

function rotateInverse(q, vector) {
  return quaternionRotate(quaternionConjugate(q), vector);
}

function closestPointOnSegment(point, a, b) {
  const direction = sub(b, a), denominator = dot(direction, direction);
  const t = denominator > EPSILON ? clamp(dot(sub(point, a), direction) / denominator, 0, 1) : 0;
  return add(a, mul(direction, t));
}

function closestSegments(a, b, c, d) {
  const u = sub(b, a), v = sub(d, c), w = sub(a, c);
  const aa = dot(u, u), bb = dot(u, v), cc = dot(v, v), dd = dot(u, w), ee = dot(v, w);
  const denominator = aa * cc - bb * bb;
  let s = denominator > EPSILON ? clamp((bb * ee - dd * cc) / denominator, 0, 1) : 0;
  let t = cc > EPSILON ? (bb * s + ee) / cc : 0;
  if (t < 0) { t = 0; s = aa > EPSILON ? clamp(-dd / aa, 0, 1) : 0; }
  else if (t > 1) { t = 1; s = aa > EPSILON ? clamp((bb - dd) / aa, 0, 1) : 0; }
  return [add(a, mul(u, s)), add(c, mul(v, t))];
}

function boxVertices(body) {
  const half = body.shape.size.map(value => value / 2), result = [];
  for (const x of [-1, 1]) for (const y of [-1, 1]) for (const z of [-1, 1]) {
    result.push(add(body.position, quaternionRotate(body.orientation, [x * half[0], y * half[1], z * half[2]])));
  }
  return result;
}

function capsuleEndpoints(body) {
  const direction = quaternionRotate(body.orientation, [0, body.shape.height / 2, 0]);
  return [sub(body.position, direction), add(body.position, direction)];
}

function contact(normal, point, depth) {
  return depth > 0 ? { normal: normalize(normal), point, depth } : null;
}

function sphereSphere(center, radius, collider) {
  const delta = sub(center, collider.position), distance = length(delta);
  const normal = distance > EPSILON ? mul(delta, 1 / distance) : [0, 1, 0];
  return contact(normal, sub(center, mul(normal, radius)), radius + collider.radius - distance);
}

function sphereCapsule(center, radius, collider) {
  const axis = [0, collider.height / 2, 0];
  const a = sub(collider.position, axis), b = add(collider.position, axis);
  const closest = closestPointOnSegment(center, a, b);
  return sphereSphere(center, radius, { position: closest, radius: collider.radius });
}

function colliderLocal(collider, point) {
  const cosine = Math.cos(collider.rotation || 0), sine = Math.sin(collider.rotation || 0);
  const pitchCosine = Math.cos(collider.pitch || 0), pitchSine = Math.sin(collider.pitch || 0);
  const delta = sub(point, collider.position);
  const yaw = [cosine * delta[0] - sine * delta[2], delta[1], sine * delta[0] + cosine * delta[2]];
  return [yaw[0], pitchCosine * yaw[1] + pitchSine * yaw[2], -pitchSine * yaw[1] + pitchCosine * yaw[2]];
}

function colliderDirection(collider, direction) {
  const cosine = Math.cos(collider.rotation || 0), sine = Math.sin(collider.rotation || 0);
  const pitchCosine = Math.cos(collider.pitch || 0), pitchSine = Math.sin(collider.pitch || 0);
  const pitched = [direction[0], pitchCosine * direction[1] - pitchSine * direction[2], pitchSine * direction[1] + pitchCosine * direction[2]];
  return [cosine * pitched[0] + sine * pitched[2], pitched[1], -sine * pitched[0] + cosine * pitched[2]];
}

function sphereBox(center, radius, collider) {
  const local = colliderLocal(collider, center), half = collider.size.map(value => value / 2);
  const closestLocal = local.map((value, axis) => clamp(value, -half[axis], half[axis]));
  const delta = sub(local, closestLocal), distance = length(delta);
  let normalLocal, depth, surfaceLocal = closestLocal;
  if (distance > EPSILON) {
    normalLocal = mul(delta, 1 / distance);
    depth = radius - distance;
  } else {
    let axis = 0, nearest = Infinity;
    for (let i = 0; i < 3; i++) {
      const faceDistance = half[i] - Math.abs(local[i]);
      if (faceDistance < nearest) { nearest = faceDistance; axis = i; }
    }
    normalLocal = [0, 0, 0]; normalLocal[axis] = local[axis] < 0 ? -1 : 1;
    surfaceLocal = local.slice(); surfaceLocal[axis] = normalLocal[axis] * half[axis];
    depth = radius + nearest;
  }
  if (depth <= 0) return null;
  const normal = colliderDirection(collider, normalLocal);
  const surface = add(collider.position, colliderDirection(collider, surfaceLocal));
  return contact(normal, sub(center, mul(normal, radius)), depth, surface);
}

function boxSphere(body, collider) {
  const local = rotateInverse(body.orientation, sub(collider.position, body.position));
  const half = body.shape.size.map(value => value / 2);
  const closestLocal = local.map((value, axis) => clamp(value, -half[axis], half[axis]));
  const closest = add(body.position, quaternionRotate(body.orientation, closestLocal));
  const delta = sub(closest, collider.position), distance = length(delta);
  if (distance > EPSILON) {
    const normal = mul(delta, 1 / distance);
    return contact(normal, closest, collider.radius - distance);
  }
  let axis = 0, nearest = Infinity;
  for (let i = 0; i < 3; i++) {
    const faceDistance = half[i] - Math.abs(local[i]);
    if (faceDistance < nearest) { nearest = faceDistance; axis = i; }
  }
  const normalLocal = [0, 0, 0]; normalLocal[axis] = local[axis] < 0 ? -1 : 1;
  const normal = quaternionRotate(body.orientation, normalLocal);
  const surfaceLocal = local.slice(); surfaceLocal[axis] = normalLocal[axis] * half[axis];
  return contact(normal, add(body.position, quaternionRotate(body.orientation, surfaceLocal)), collider.radius + nearest);
}

function pointCapsule(point, collider) {
  const axis = [0, collider.height / 2, 0];
  const closest = closestPointOnSegment(point, sub(collider.position, axis), add(collider.position, axis));
  const delta = sub(point, closest), distance = length(delta);
  const normal = distance > EPSILON ? mul(delta, 1 / distance) : [0, 1, 0];
  return contact(normal, point, collider.radius - distance);
}

const GROUND_NORMAL = [0, 1, 0];

/** Ground contacts are written straight into the pooled buffer; no per-iteration garbage. */
function writeGroundContacts(buffer, count, body) {
  const shape = body.shape;
  if (shape.type === 'sphere') {
    const depth = shape.radius - body.position[1];
    if (depth > 0) count = writeContact(buffer, count, body, null, GROUND_NORMAL, [body.position[0], body.position[1] - shape.radius, body.position[2]], depth);
    return count;
  }
  if (shape.type === 'capsule') {
    const [a, b] = capsuleEndpoints(body);
    for (const point of [a, b]) {
      const depth = shape.radius - point[1];
      if (depth > 0) count = writeContact(buffer, count, body, null, GROUND_NORMAL, [point[0], point[1] - shape.radius, point[2]], depth);
    }
    return count;
  }
  const half = shape.size.map(value => value / 2);
  for (const x of [-1, 1]) for (const y of [-1, 1]) for (const z of [-1, 1]) {
    const point = add(body.position, quaternionRotate(body.orientation, [x * half[0], y * half[1], z * half[2]]));
    if (point[1] < 0) count = writeContact(buffer, count, body, null, GROUND_NORMAL, point, -point[1]);
  }
  return count;
}

function sceneContacts(body, collider) {
  if (!collider || !Array.isArray(collider.position)) return [];
  const single = result => result ? [result] : [];
  if (body.shape.type === 'sphere') {
    const center = body.position, radius = body.shape.radius;
    if (collider.type === 'sphere') return single(sphereSphere(center, radius, collider));
    if (collider.type === 'capsule') return single(sphereCapsule(center, radius, collider));
    if (collider.type === 'box') return single(sphereBox(center, radius, collider));
  } else if (body.shape.type === 'capsule') {
    const [a, b] = capsuleEndpoints(body), radius = body.shape.radius;
    if (collider.type === 'sphere') {
      const center = closestPointOnSegment(collider.position, a, b);
      return single(sphereSphere(center, radius, collider));
    }
    if (collider.type === 'capsule') {
      const axis = [0, collider.height / 2, 0];
      const [p, q] = closestSegments(a, b, sub(collider.position, axis), add(collider.position, axis));
      const delta = sub(p, q), distance = length(delta), normal = distance > EPSILON ? mul(delta, 1 / distance) : [0, 1, 0];
      return single(contact(normal, sub(p, mul(normal, radius)), radius + collider.radius - distance));
    }
    if (collider.type === 'box') {
      let deepest = null;
      for (let i = 0; i <= 4; i++) {
        const result = sphereBox(add(a, mul(sub(b, a), i / 4)), radius, collider);
        if (result && (!deepest || result.depth > deepest.depth)) deepest = result;
      }
      return single(deepest);
    }
  } else if (body.shape.type === 'box') {
    if (collider.type === 'sphere') return single(boxSphere(body, collider));
    if (collider.type === 'capsule') {
      let deepest = null;
      for (const point of boxVertices(body)) {
        const result = pointCapsule(point, collider);
        if (result && (!deepest || result.depth > deepest.depth)) deepest = result;
      }
      return single(deepest);
    }
    if (collider.type === 'box') return boxVertices(body).map(point => sphereBox(point, 0, collider)).filter(Boolean);
  }
  return [];
}

function effectiveInverseMass(body, fixed) {
  return fixed.has(body.index) ? 0 : body.inverseMass;
}

function applyAngular(body, impulse) {
  const delta = quaternionMultiply([impulse[0] / 2, impulse[1] / 2, impulse[2] / 2, 0], body.orientation);
  body.orientation = quaternionNormalize(body.orientation.map((value, axis) => value + delta[axis]));
}

function inverseInertiaRotate(body, vector) {
  return quaternionRotate(body.orientation, rotateInverse(body.orientation, vector).map((value, axis) => value * body.inverseInertia[axis]));
}

function constraintMass(body, arm, direction, inverseMass) {
  const angularArm = cross(arm, direction);
  return inverseMass + dot(angularArm, inverseInertiaRotate(body, angularArm));
}

function solveJoint(joint, bodies, fixed) {
  const a = bodies[joint.a], b = bodies[joint.b];
  const armA = quaternionRotate(a.orientation, joint.localA), armB = quaternionRotate(b.orientation, joint.localB);
  const pointA = add(a.position, armA), pointB = add(b.position, armB), error = sub(pointA, pointB);
  const inverseMassA = effectiveInverseMass(a, fixed), inverseMassB = effectiveInverseMass(b, fixed);
  for (let axis = 0; axis < 3; axis++) {
    const direction = [0, 0, 0]; direction[axis] = 1;
    const massA = constraintMass(a, armA, direction, inverseMassA), massB = constraintMass(b, armB, direction, inverseMassB);
    const denominator = massA + massB;
    if (denominator < EPSILON) continue;
    const impulse = mul(direction, -error[axis] / denominator);
    a.position = add(a.position, mul(impulse, inverseMassA));
    b.position = sub(b.position, mul(impulse, inverseMassB));
    applyAngular(a, inverseInertiaRotate(a, cross(armA, impulse)));
    applyAngular(b, mul(inverseInertiaRotate(b, cross(armB, impulse)), -1));
  }
}

function solveJointAngle(joint, bodies) {
  const a = bodies[joint.a], b = bodies[joint.b];
  const relative = quaternionMultiply(quaternionConjugate(a.orientation), b.orientation);
  const error = quaternionMultiply(relative, quaternionConjugate(joint.restRelative));
  const sign = error[3] < 0 ? -1 : 1;
  const vector = error.slice(0, 3).map(value => value * sign), magnitude = length(vector);
  if (magnitude < EPSILON) return;
  const angle = 2 * Math.atan2(magnitude, Math.abs(error[3]));
  const excess = angle - joint.angularLimit;
  if (excess <= 0) return;
  const axis = quaternionRotate(a.orientation, mul(vector, 1 / magnitude));
  const inertiaA = dot(axis, inverseInertiaRotate(a, axis)), inertiaB = dot(axis, inverseInertiaRotate(b, axis));
  const total = inertiaA + inertiaB;
  if (total < EPSILON) return;
  const correction = excess * .7 / total;
  applyAngular(a, mul(axis, correction * inertiaA));
  applyAngular(b, mul(axis, -correction * inertiaB));
}

function solveContactPosition(body, hit, inverseMass, compliance = 1) {
  const arm = sub(hit.point, body.position);
  const denominator = constraintMass(body, arm, hit.normal, inverseMass);
  if (denominator < EPSILON) return;
  const impulse = mul(hit.normal, Math.max(0, hit.depth - 0.00005) * compliance / denominator);
  body.position = add(body.position, mul(impulse, inverseMass));
  applyAngular(body, inverseInertiaRotate(body, cross(arm, impulse)));
}

function applyImpulse(body, point, impulse, inverseMass) {
  body.linearVelocity = add(body.linearVelocity, mul(impulse, inverseMass));
  body.angularVelocity = add(body.angularVelocity, inverseInertiaRotate(body, cross(sub(point, body.position), impulse)));
}

function solveContactVelocity(body, hit, inverseMass, friction) {
  const arm = sub(hit.point, body.position);
  const velocity = add(body.linearVelocity, cross(body.angularVelocity, arm));
  const normalSpeed = dot(velocity, hit.normal);
  if (normalSpeed >= 0) return;
  const denominator = constraintMass(body, arm, hit.normal, inverseMass);
  if (denominator < EPSILON) return;
  const normalImpulse = -normalSpeed / denominator;
  applyImpulse(body, hit.point, mul(hit.normal, normalImpulse), inverseMass);
  const after = add(body.linearVelocity, cross(body.angularVelocity, arm));
  const tangent = sub(after, mul(hit.normal, dot(after, hit.normal))), speed = length(tangent);
  if (speed < EPSILON || friction <= 0) return;
  const direction = mul(tangent, 1 / speed), tangentMass = constraintMass(body, arm, direction, inverseMass);
  if (tangentMass < EPSILON) return;
  const amount = Math.min(speed / tangentMass, friction * normalImpulse);
  applyImpulse(body, hit.point, mul(direction, -amount), inverseMass);
}

function bodyVolume(shape) {
  if (shape.type === 'sphere') return 4 * Math.PI * shape.radius ** 3 / 3;
  if (shape.type === 'capsule') return Math.PI * shape.radius ** 2 * shape.height + 4 * Math.PI * shape.radius ** 3 / 3;
  return shape.size[0] * shape.size[1] * shape.size[2];
}

function localInertia(shape, mass) {
  if (shape.type === 'sphere') {
    const value = .4 * mass * shape.radius ** 2;
    return [value, value, value];
  }
  if (shape.type === 'capsule') {
    const along = .5 * mass * shape.radius ** 2;
    const across = mass * (3 * shape.radius ** 2 + shape.height ** 2) / 12;
    return [across, along, across];
  }
  const [x, y, z] = shape.size;
  return [mass * (y * y + z * z) / 12, mass * (x * x + z * z) / 12, mass * (x * x + y * y) / 12];
}

const RAD2DEG = 180 / Math.PI;

/** Euler XYZ in degrees for a rotation quaternion; matches rig.transform (Rz * Ry * Rx). */
function quaternionEuler(q) {
  const [x, y, z, w] = q;
  return [
    Math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y)) * RAD2DEG,
    Math.asin(clamp(2 * (w * y - x * z), -1, 1)) * RAD2DEG,
    Math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z)) * RAD2DEG,
  ];
}

function boundRadius(shape) {
  if (shape.type === 'sphere') return shape.radius;
  if (shape.type === 'capsule') return shape.radius + shape.height / 2;
  return length(shape.size) / 2;
}

/**
 * Self-collision only needs a rough proxy: capsules become two or three spheres,
 * spheres stay spheres and boxes become one fat sphere. No smooth surfaces required.
 */
function selfSpheres(shape) {
  if (shape.type === 'sphere') return [{ offset: [0, 0, 0], radius: shape.radius }];
  if (shape.type === 'capsule') {
    const half = shape.height / 2, rings = half > shape.radius * 2.5 ? 3 : 2, spheres = [];
    for (let i = 0; i < rings; i++) spheres.push({ offset: [0, 2 * half * i / (rings - 1) - half, 0], radius: shape.radius });
    return spheres;
  }
  return [{ offset: [0, 0, 0], radius: Math.max(...shape.size) * .42 }];
}

function deepestSelfHit(a, b) {
  let best = null;
  for (const sphereA of a.selfSpheres) {
    const centerA = add(a.position, quaternionRotate(a.orientation, sphereA.offset));
    for (const sphereB of b.selfSpheres) {
      const centerB = add(b.position, quaternionRotate(b.orientation, sphereB.offset));
      const delta = sub(centerA, centerB), distance = length(delta), depth = sphereA.radius + sphereB.radius - distance;
      if (depth <= 0 || (best && best.depth >= depth)) continue;
      const normal = distance > EPSILON ? mul(delta, 1 / distance) : [0, 1, 0];
      best = { depth, normal, point: sub(centerA, mul(normal, sphereA.radius)) };
    }
  }
  return best;
}

const jointsConnect = (joints, a, b) => joints.some(joint => (joint.a === a && joint.b === b) || (joint.a === b && joint.b === a));

function pairKey(a, b) {
  return a < b ? `${a}:${b}` : `${b}:${a}`;
}

function colliderBoundRadius(collider) {
  if (collider.type === 'sphere') return collider.radius ?? .25;
  if (collider.type === 'capsule') return (collider.radius ?? .2) + (collider.height ?? .8) / 2;
  const size = collider.size || [.5, .5, .5];
  return length(size) / 2;
}

function contactBuffer(state) {
  return state.contacts ?? (state.contacts = []);
}

function writeContact(buffer, count, a, b, normal, point, depth, compliance = 1) {
  let entry = buffer[count];
  if (!entry) entry = buffer[count] = { a: null, b: null, normal: [0, 0, 0], point: [0, 0, 0], depth: 0, compliance: 1 };
  entry.a = a; entry.b = b; entry.depth = depth; entry.compliance = compliance;
  for (let axis = 0; axis < 3; axis++) { entry.normal[axis] = normal[axis]; entry.point[axis] = point[axis]; }
  return count + 1;
}

/** Self-collision candidates are gathered once per substep; overlaps are re-tested every iteration. */
function selfCandidatePairs(state) {
  const bodies = state.bodies, pairs = state.pairBuffer ?? (state.pairBuffer = []);
  pairs.length = 0;
  for (let i = 0; i < bodies.length; i++) {
    const a = bodies[i];
    for (let j = i + 1; j < bodies.length; j++) {
      const b = bodies[j];
      if (a.bound + b.bound < length(sub(a.position, b.position))) continue;
      if (state.skipPairs?.has(pairKey(a.index, b.index))) continue;
      if (jointsConnect(state.joints, a.index, b.index)) continue;
      pairs.push(a, b);
    }
  }
  return pairs;
}

/**
 * Rebuild the contact list for one solver iteration. The expensive scene-collider math is gated by a
 * bounding-sphere broadphase, and pooled entries keep the loop allocation free.
 */
function collectContacts(state, colliders, pairs) {
  const buffer = contactBuffer(state), bodies = state.bodies;
  let count = 0;
  for (const body of bodies) count = writeGroundContacts(buffer, count, body);
  if (colliders.length) {
    for (const body of bodies) {
      for (const collider of colliders) {
        if (!collider || !Array.isArray(collider.position)) continue;
        const delta = sub(body.position, collider.position);
        if (length(delta) > body.bound + colliderBoundRadius(collider) + .01) continue;
        for (const hit of sceneContacts(body, collider)) count = writeContact(buffer, count, body, null, hit.normal, hit.point, hit.depth, .9);
      }
    }
  }
  if (!state.selfCollisionsOff) for (let index = 0; index < pairs.length; index += 2) {
    const hit = deepestSelfHit(pairs[index], pairs[index + 1]);
    if (hit) count = writeContact(buffer, count, pairs[index], pairs[index + 1], hit.normal, hit.point, hit.depth);
  }
  state.contactCount = count;
  return buffer;
}

function solvePairPosition(a, b, normal, point, depth, inverseMassA, inverseMassB) {
  const armA = sub(point, a.position), armB = sub(point, b.position);
  const denominator = constraintMass(a, armA, normal, inverseMassA) + constraintMass(b, armB, normal, inverseMassB);
  if (denominator < EPSILON) return;
  const impulse = mul(normal, Math.max(0, depth - .00005) * .95 / denominator);
  a.position = add(a.position, mul(impulse, inverseMassA));
  b.position = sub(b.position, mul(impulse, inverseMassB));
  applyAngular(a, inverseInertiaRotate(a, cross(armA, impulse)));
  applyAngular(b, mul(inverseInertiaRotate(b, cross(armB, impulse)), -1));
}

function solvePairVelocity(a, b, normal, point, inverseMassA, inverseMassB) {
  const armA = sub(point, a.position), armB = sub(point, b.position);
  const relative = sub(add(a.linearVelocity, cross(a.angularVelocity, armA)), add(b.linearVelocity, cross(b.angularVelocity, armB)));
  const speed = dot(relative, normal);
  if (speed >= 0) return;
  const denominator = constraintMass(a, armA, normal, inverseMassA) + constraintMass(b, armB, normal, inverseMassB);
  if (denominator < EPSILON) return;
  const impulse = mul(normal, -speed / denominator);
  applyImpulse(a, point, impulse, inverseMassA);
  applyImpulse(b, point, mul(impulse, -1), inverseMassB);
}

function skinVertices(mesh, matrices) {
  if (!mesh.positions || !mesh.boneIndices || !mesh.boneWeights) return null;
  const positions = new Float64Array(mesh.vertexCount * 3);
  for (let vertex = 0; vertex < mesh.vertexCount; vertex++) {
    const source = vertex * 4, target = vertex * 3;
    for (let influence = 0; influence < 4; influence++) {
      const weight = mesh.boneWeights[source + influence];
      if (!weight) continue;
      const offset = mesh.boneIndices[source + influence] * 16;
      const point = [mesh.positions[source], mesh.positions[source + 1], mesh.positions[source + 2]];
      const transformed = transformPoint(matrices.subarray(offset, offset + 16), point);
      for (let axis = 0; axis < 3; axis++) positions[target + axis] += weight * transformed[axis];
    }
  }
  return positions;
}

function fittedRadius(mesh, skin, names, a, b, fallback) {
  if (!skin) return fallback;
  const selected = new Set(names.map(name => mesh.bones.findIndex(bone => bone.name === name)).filter(index => index >= 0));
  const axis = sub(b, a), denominator = dot(axis, axis);
  let maximum = 0;
  for (let vertex = 0; vertex < mesh.vertexCount; vertex++) {
    let weight = 0;
    for (let influence = 0; influence < 4; influence++) if (selected.has(mesh.boneIndices[vertex * 4 + influence])) weight += mesh.boneWeights[vertex * 4 + influence];
    if (weight < .45) continue;
    const point = Array.from(skin.subarray(vertex * 3, vertex * 3 + 3));
    const relative = sub(point, a), t = denominator > EPSILON ? clamp(dot(relative, axis) / denominator, 0, 1) : 0;
    maximum = Math.max(maximum, length(sub(relative, mul(axis, t))));
  }
  return maximum > EPSILON ? clamp(maximum, fallback * .6, fallback * 1.8) : fallback;
}

function fittedBox(mesh, boneIndex, names, worldMatrices, skinMatrices, fallback, flatten = true) {
  if (!mesh.positions || !mesh.boneIndices || !mesh.boneWeights) return fallback;
  const selected = new Set(names.map(name => mesh.bones.findIndex(bone => bone.name === name)).filter(index => index >= 0));
  const minimum = [Infinity, Infinity, Infinity], maximum = [-Infinity, -Infinity, -Infinity];
  let lowestY=Infinity;
  for (let vertex = 0; vertex < mesh.vertexCount; vertex++) {
    let weight = 0;
    for (let influence = 0; influence < 4; influence++) if (selected.has(mesh.boneIndices[vertex * 4 + influence])) weight += mesh.boneWeights[vertex * 4 + influence];
    if (weight < .45) continue;
    if (flatten) {
      const before = transformPoint(skinMatrices.subarray(boneIndex * 16, boneIndex * 16 + 16), [mesh.positions[vertex * 4], mesh.positions[vertex * 4 + 1], mesh.positions[vertex * 4 + 2]]);
      if (before[1] < lowestY) lowestY = before[1];
    }
    for (let axis = 0; axis < 3; axis++) {
      const value = mesh.positions[vertex * 4 + axis];
      minimum[axis] = Math.min(minimum[axis], value); maximum[axis] = Math.max(maximum[axis], value);
    }
  }
  if (!minimum.every(Number.isFinite)) return fallback;
  const worldMatrix = worldMatrices.subarray(boneIndex * 16, boneIndex * 16 + 16);
  const skinMatrix = skinMatrices.subarray(boneIndex * 16, boneIndex * 16 + 16);
  const size = maximum.map((value, axis) => Math.max(.005, value - minimum[axis]));
  if (flatten) size[1] = Math.min(size[1], size[0] * .7, size[2] * .45);
  const centerLocal = minimum.map((value, axis) => (value + maximum[axis]) / 2);
  centerLocal[1] = minimum[1] + size[1] / 2;
  let center=transformPoint(skinMatrix, centerLocal);
  if(flatten)center[1]=lowestY+size[1]/2;
  return { center, orientation: quaternionFromMatrix(worldMatrix), size };
}

function fittedSphere(mesh, boneIndex, name, worldMatrices, skinMatrices, fallbackCenter, fallbackRadius) {
  const box = fittedBox(mesh, boneIndex, [name], worldMatrices, skinMatrices, { center: fallbackCenter, orientation: IDENTITY_QUATERNION, size: [fallbackRadius * 2, fallbackRadius * 2, fallbackRadius * 2] }, false);
  return { center: box.center, orientation: box.orientation, radius: Math.max(...box.size) / 2 };
}

function normalizeFixed(value, bodies) {
  if (value == null) return new Set();
  const result = new Set();
  for (const item of value) {
    if (Number.isInteger(item) && bodies[item]) result.add(item);
    else if (typeof item === 'string') {
      const index = bodies.findIndex(body => body.name === item || body.bones.includes(item));
      if (index >= 0) result.add(index);
    } else if (item && Number.isInteger(item.index)) result.add(item.index);
  }
  return result;
}

/**
 * Capture a posed humanoid as fifteen rigid bodies. Capsules use local Y as their axis.
 * Unsimulated hand/finger/toe bones retain their authored transform relative to a simulated parent.
 */
export function createRagdoll(mesh, rig, options = {}) {
  if (!mesh?.bones?.length || !rig?.joints || !rig?.worldMatrices) throw new TypeError('createRagdoll requires mesh bones and an evaluated rig.');
  const boneIndex = name => mesh.bones.findIndex(bone => bone.name === name);
  const required = ['hips', 'spine', 'chest', 'neck', 'head'];
  for (const suffix of ['L', 'R']) required.push(`upperArm.${suffix}`, `forearm.${suffix}`, `thigh.${suffix}`, `shin.${suffix}`, `foot.${suffix}`);
  for (const name of required) if (boneIndex(name) < 0) throw new Error(`Ragdoll requires bone ${name}.`);
  const joint = name => Array.from(rig.joints[boneIndex(name)]);
  const worldMatrices = rig.worldMatrices, skinMatrices = rig.matrices;
  if (!skinMatrices) throw new TypeError('createRagdoll requires evaluated skin matrices.');
  const skin = skinVertices(mesh, skinMatrices);
  const shoulderWidth = length(sub(joint('upperArm.L'), joint('upperArm.R')));
  const hipWidth = length(sub(joint('thigh.L'), joint('thigh.R')));
  const armLength = length(sub(joint('upperArm.L'), joint('forearm.L')));
  const legLength = length(sub(joint('thigh.L'), joint('shin.L')));
  const specs = [];
  const capsule = (name, start, end, radius, groups = [name]) => {
    const a = joint(start), b = joint(end), axis = sub(b, a), height = length(axis);
    const center = mul(add(a, b), .5);
    const fitted = fittedRadius(mesh, skin, groups, a, b, radius) * .5;
    specs.push({ name, bone: name, shape: { type: 'capsule', radius: fitted, height: Math.max(height, .005) }, position: center, orientation: quaternionFromY(axis), anchor: a });
  };
  capsule('hips', 'hips', 'spine', Math.max(.025, hipWidth * .65));
  capsule('spine', 'spine', 'chest', Math.max(.025, shoulderWidth * .32));
  capsule('chest', 'chest', 'neck', Math.max(.025, shoulderWidth * .42));
  capsule('neck', 'neck', 'head', Math.max(.012, shoulderWidth * .075));
  const headIndex = boneIndex('head'), headJoint = joint('head');
  const headDirection = normalize(sub(headJoint, joint('neck')));
  const headFallback = Math.max(.035, length(sub(headJoint, joint('neck'))) * 1.35);
  const head = fittedSphere(mesh, headIndex, 'head', worldMatrices, skinMatrices, add(headJoint, mul(headDirection, headFallback * .45)), headFallback);
  specs.push({ name: 'head', bone: 'head', shape: { type: 'sphere', radius: head.radius }, position: head.center, orientation: head.orientation });
  for (const suffix of ['L', 'R']) {
    const upper = `upperArm.${suffix}`, forearm = `forearm.${suffix}`, thigh = `thigh.${suffix}`, shin = `shin.${suffix}`, foot = `foot.${suffix}`;
    capsule(upper, upper, forearm, Math.max(.012, armLength * .18));
    capsule(forearm, forearm, `hand.${suffix}`, Math.max(.010, armLength * .145));
    capsule(thigh, thigh, shin, Math.max(.018, Math.min(legLength * .21, hipWidth * .8)));
    capsule(shin, shin, foot, Math.max(.012, legLength * .145));
    const footIndex = boneIndex(foot), ankle = joint(foot);
    const toes = Array.from({ length: 5 }, (_, i) => `toe${i + 1}.${suffix}`).filter(name => boneIndex(name) >= 0);
    const toeCenter = toes.length ? toes.map(joint).reduce((sum, point) => add(sum, point), [0, 0, 0]).map(value => value / toes.length) : add(ankle, [0, 0, legLength * .25]);
    const footLength = Math.max(.04, length(sub(toeCenter, ankle)) * 1.35);
    const fallback = {
      center: add(ankle, [0, -legLength * .07, footLength * .2]), orientation: quaternionFromMatrix(worldMatrices.subarray(footIndex * 16, footIndex * 16 + 16)),
      size: [Math.max(.025, hipWidth * .58), Math.max(.018, legLength * .12), footLength],
    };
    const box = fittedBox(mesh, footIndex, [foot, ...toes], worldMatrices, skinMatrices, fallback);
    specs.push({ name: foot, bone: foot, shape: { type: 'box', size: box.size }, position: box.center, orientation: box.orientation, anchor: ankle, footBottom:box.center[1]-box.size[1]/2, footAnchorOffset:ankle[1]-(box.center[1]-box.size[1]/2) });
  }

  const bodies = specs.map((spec, index) => ({
    index, name: spec.name, bones: [spec.bone], boneIndex: boneIndex(spec.bone), shape: spec.shape,
    position: spec.position.slice(), previousPosition: spec.position.slice(),
    orientation: quaternionNormalize(spec.orientation), previousOrientation: quaternionNormalize(spec.orientation),
    referencePosition: spec.position.slice(), referenceOrientation: quaternionNormalize(spec.orientation), footAnchorOffset:spec.footAnchorOffset,
    linearVelocity: [0, 0, 0], angularVelocity: [0, 0, 0], mass: 1, inverseMass: 1,
    inertia: [1, 1, 1], inverseInertia: [1, 1, 1],
  }));
  for (const body of bodies) { body.bound = boundRadius(body.shape); body.selfSpheres = selfSpheres(body.shape); }
  const totalVolume = bodies.reduce((sum, body) => sum + bodyVolume(body.shape), 0);
  const density = (options.mass ?? 70) / Math.max(totalVolume, EPSILON);
  for (const body of bodies) {
    body.mass = bodyVolume(body.shape) * density;
    body.inverseMass = 1 / body.mass;
    body.inertia = localInertia(body.shape, body.mass);
    body.inverseInertia = body.inertia.map(value => 1 / Math.max(value, EPSILON));
  }
  const byName = Object.fromEntries(bodies.map(body => [body.name, body.index]));
  const joints = [];
  const connect = (aName, bName, pointName, limitDegrees) => {
    const a = bodies[byName[aName]], b = bodies[byName[bName]], point = joint(pointName);
    joints.push({
      a: a.index, b: b.index,
      localA: rotateInverse(a.orientation, sub(point, a.position)), localB: rotateInverse(b.orientation, sub(point, b.position)),
      restRelative: quaternionMultiply(quaternionConjugate(a.orientation), b.orientation), angularLimit: limitDegrees * Math.PI / 180,
    });
  };
  connect('hips', 'spine', 'spine', 32); connect('spine', 'chest', 'chest', 32); connect('chest', 'neck', 'neck', 40); connect('neck', 'head', 'head', 45);
  for (const suffix of ['L', 'R']) {
    connect('chest', `upperArm.${suffix}`, `upperArm.${suffix}`, 85);
    connect(`upperArm.${suffix}`, `forearm.${suffix}`, `forearm.${suffix}`, 115);
    connect('hips', `thigh.${suffix}`, `thigh.${suffix}`, 75);
    connect(`thigh.${suffix}`, `shin.${suffix}`, `shin.${suffix}`, 110);
    connect(`shin.${suffix}`, `foot.${suffix}`, `foot.${suffix}`, 50);
  }
  const captureMatrices = new Float64Array(mesh.bones.length * 16), bindMatrices = new Float64Array(mesh.bones.length * 16);
  captureMatrices.set(worldMatrices);
  mesh.bones.forEach((bone, index) => {
    const parentPosition = bone.parent >= 0 ? mesh.bones[bone.parent].position : [0, 0, 0];
    const local = new Float64Array(16); local[0] = local[5] = local[10] = local[15] = 1;
    for (let axis = 0; axis < 3; axis++) local[12 + axis] = bone.position[axis] - parentPosition[axis];
    const world = bone.parent >= 0 ? multiply(bindMatrices.subarray(bone.parent * 16, bone.parent * 16 + 16), local) : local;
    bindMatrices.set(world, index * 16);
  });
  const captureInverses = Array.from({ length: mesh.bones.length }, (_, index) => inverseRigid(captureMatrices.subarray(index * 16, index * 16 + 16)));
  const bindInverses = Array.from({ length: mesh.bones.length }, (_, index) => inverseRigid(bindMatrices.subarray(index * 16, index * 16 + 16)));
  const localMatrices = mesh.bones.map((bone, index) => bone.parent >= 0 ? multiply(captureInverses[bone.parent], captureMatrices.subarray(index * 16, index * 16 + 16)) : captureMatrices.subarray(index * 16, index * 16 + 16).slice());
  const skipPairs = new Set();
  for (let i = 0; i < bodies.length; i++) for (let j = i + 1; j < bodies.length; j++) {
    const hit = deepestSelfHit(bodies[i], bodies[j]);
    if (hit && hit.depth > .002) skipPairs.add(pairKey(bodies[i].index, bodies[j].index));
  }
  const state = {
    bodies, joints, colliders: [], fixed: normalizeFixed(options.fixed, bodies), skipPairs, contacts: [], contactCount: 0,
    linearDamping: options.linearDamping ?? .8, angularDamping: options.angularDamping ?? 2.4,
    friction: options.friction ?? .7, iterations: clamp(Math.round(options.iterations ?? 10), 2, 12),
    captureMatrices, bindMatrices, bindInverses, localMatrices,
    bodyByBone: Object.fromEntries(bodies.map(body => [body.boneIndex, body.index])),
    time: 0,
  };
  syncColliders(state);
  const report = validateRagdoll(state);
  if (!report.valid) throw new Error(`Invalid ragdoll capture: ${report.errors.join('; ')}`);
  return state;
}

function syncColliders(state) {
  const list = state.colliders ?? (state.colliders = []), bodies = state.bodies;
  if (list.length !== bodies.length) list.length = bodies.length;
  for (let index = 0; index < bodies.length; index++) {
    const body = bodies[index];
    let item = list[index];
    if (!item) item = list[index] = { position: [0, 0, 0], orientation: [0, 0, 0, 1] };
    item.body = body.index; item.name = body.name; item.type = body.shape.type;
    for (let axis = 0; axis < 3; axis++) { item.position[axis] = body.position[axis]; item.orientation[axis] = body.orientation[axis]; }
    item.orientation[3] = body.orientation[3];
    if (body.shape.type === 'box') {
      if (!item.size) item.size = body.shape.size.slice();
      for (let axis = 0; axis < 3; axis++) item.size[axis] = body.shape.size[axis];
      delete item.radius; delete item.height;
    } else {
      item.radius = body.shape.radius;
      if (body.shape.type === 'capsule') item.height = body.shape.height;
      else delete item.height;
      delete item.size;
    }
  }
}

/** Advance rigid centers and orientations. fixed contains body indices or bone names and locks translation only. */
export function stepRagdoll(state, dt, { gravity = -9.81, gravityEnabled = true, colliders = [], fixed, substeps = 4 } = {}) {
  if (!Number.isFinite(dt) || dt < 0) throw new RangeError('Ragdoll dt must be finite and non-negative.');
  const initialReport = validateRagdoll(state);
  if (!initialReport.valid) throw new Error(`Invalid ragdoll state: ${initialReport.errors.join('; ')}`);
  if (fixed !== undefined) state.fixed = normalizeFixed(fixed, state.bodies);
  else state.fixed = normalizeFixed(state.fixed, state.bodies);
  if (dt === 0) { syncColliders(state); return state; }
  const count = clamp(Math.round(substeps), 4, 8), h = dt / count;
  const linearDecay = Math.exp(-state.linearDamping * h), angularDecay = Math.exp(-state.angularDamping * h);
  for (let step = 0; step < count; step++) {
    for (const body of state.bodies) {
      body.previousPosition = body.position.slice(); body.previousOrientation = body.orientation.slice();
      body.angularVelocity = mul(body.angularVelocity, angularDecay);
      if (state.fixed.has(body.index)) body.linearVelocity = [0, 0, 0];
      else {
        if (gravityEnabled) body.linearVelocity[1] += gravity * h;
        body.linearVelocity = mul(body.linearVelocity, linearDecay);
        body.position = add(body.position, mul(body.linearVelocity, h));
      }
      const angular = quaternionMultiply([body.angularVelocity[0] * h / 2, body.angularVelocity[1] * h / 2, body.angularVelocity[2] * h / 2, 0], body.orientation);
      body.orientation = quaternionNormalize(body.orientation.map((value, axis) => value + angular[axis]));
    }
    const pairs = selfCandidatePairs(state);
    for (let iteration = 0; iteration < state.iterations; iteration++) {
      for (const joint of state.joints) { solveJointAngle(joint, state.bodies); solveJoint(joint, state.bodies, state.fixed); }
      const pool = collectContacts(state, colliders, pairs), total = state.contactCount;
      for (let index = 0; index < total; index++) {
        const hit = pool[index];
        if (hit.b) solvePairPosition(hit.a, hit.b, hit.normal, hit.point, hit.depth, effectiveInverseMass(hit.a, state.fixed), effectiveInverseMass(hit.b, state.fixed));
        else solveContactPosition(hit.a, hit, effectiveInverseMass(hit.a, state.fixed), hit.compliance);
      }
    }
    for (const body of state.bodies) {
      if (state.fixed.has(body.index)) body.linearVelocity = [0, 0, 0];
      else body.linearVelocity = mul(sub(body.position, body.previousPosition), 1 / h);
      const delta = quaternionMultiply(body.orientation, quaternionConjugate(body.previousOrientation));
      const sign = delta[3] < 0 ? -1 : 1;
      body.angularVelocity = delta.slice(0, 3).map(value => value * 2 * sign / h);
    }
    const pool = collectContacts(state, colliders, pairs), total = state.contactCount;
    for (let iteration = 0; iteration < 2; iteration++) for (let index = 0; index < total; index++) {
      const hit = pool[index];
      if (hit.b) solvePairVelocity(hit.a, hit.b, hit.normal, hit.point, effectiveInverseMass(hit.a, state.fixed), effectiveInverseMass(hit.b, state.fixed));
      else solveContactVelocity(hit.a, hit, effectiveInverseMass(hit.a, state.fixed), state.friction);
    }
    for (const body of state.bodies) {
      if (length(body.linearVelocity) < .006 && length(body.angularVelocity) < .025) {
        body.linearVelocity = [0, 0, 0]; body.angularVelocity = [0, 0, 0];
      }
    }
  }
  state.time += dt;
  syncColliders(state);
  const report = validateRagdoll(state);
  if (!report.valid) throw new Error(`Ragdoll integration failed: ${report.errors.join('; ')}`);
  return state;
}

/** Return the same matrix convention as evaluateRig: worldMatrices and world * inverse(bind). */
export function evaluateRagdoll(mesh, state) {
  if (!mesh?.bones || !state?.bodies) throw new TypeError('evaluateRagdoll requires a mesh and ragdoll state.');
  const matrices = new Float32Array(mesh.bones.length * 16), worldMatrices = new Float32Array(matrices.length), joints = [];
  const worlds = new Array(mesh.bones.length);
  const compute = index => {
    if (worlds[index]) return worlds[index];
    const bind = state.captureMatrices.subarray(index * 16, index * 16 + 16);
    const bodyIndex = state.bodyByBone[index];
    let world;
    if (bodyIndex !== undefined) {
      const body = state.bodies[bodyIndex];
      const rotation = quaternionMultiply(body.orientation, quaternionConjugate(body.referenceOrientation));
      const delta = quaternionMatrix(rotation), translation = sub(body.position, quaternionRotate(rotation, body.referencePosition));
      delta[12] = translation[0]; delta[13] = translation[1]; delta[14] = translation[2];
      world = multiply(delta, bind);
      if(body.footAnchorOffset!=null){
        const bottom=body.position[1]+quaternionRotate(rotation,[0,-body.shape.size[1]/2,0])[1];
        const ankle=bind[13]+(bottom+body.footAnchorOffset-bind[13]);
        const difference=ankle-world[13];delta[13]+=difference;world=multiply(delta,bind);
      }
    } else {
      const parent = mesh.bones[index].parent;
      world = parent >= 0 ? multiply(compute(parent), state.localMatrices[index]) : bind.slice();
    }
    worlds[index] = world;
    return world;
  };
  mesh.bones.forEach((bone, index) => {
    const world = compute(index);
    worldMatrices.set(world, index * 16);
    joints.push([world[12], world[13], world[14]]);
    matrices.set(multiply(world, state.bindInverses[index]), index * 16);
  });
  return { matrices, joints, worldMatrices };
}

/**
 * Convert the rigid-body result into rig pose data so evaluateRig reproduces the same skeleton
 * in place. The root bone owns the world transform; every other bone stores a local rotation and
 * offset, so joints stay exactly where the ragdoll left them instead of snapping or re-rotating.
 */
export function captureRagdollFrame(mesh, state) {
  if (!mesh?.bones?.length || !state?.bodies?.length) return null;
  const worlds = evaluateRagdoll(mesh, state).worldMatrices;
  const pose = {}, offsets = {};
  const rootIndex = Math.max(0, mesh.bones.findIndex(bone => bone.parent < 0));
  const rootBone = mesh.bones[rootIndex], root = worlds.subarray(rootIndex * 16, rootIndex * 16 + 16);
  const authorRoot = {
    position: [0, 1, 2].map(axis => root[12 + axis] - rootBone.position[axis]),
    rotation: quaternionEuler(quaternionFromMatrix(root)),
  };
  pose[rootBone.name] = [0, 0, 0];
  offsets[rootBone.name] = [0, 0, 0];
  for (let index = 0; index < mesh.bones.length; index++) {
    if (index === rootIndex) continue;
    const bone = mesh.bones[index], parent = bone.parent;
    if (parent < 0) continue;
    const parentWorld = worlds.subarray(parent * 16, parent * 16 + 16);
    const local = multiply(inverseRigid(parentWorld), worlds.subarray(index * 16, index * 16 + 16));
    pose[bone.name] = quaternionEuler(quaternionFromMatrix(local));
    const parentBone = mesh.bones[parent];
    offsets[bone.name] = [0, 1, 2].map(axis => clamp(local[12 + axis] - (bone.position[axis] - parentBone.position[axis]), -.5, .5));
  }
  return { pose, offsets, authorRoot };
}

/** Check all mutable simulation values; pass {throwOnError:true} to throw instead of returning a report. */
export function validateRagdoll(state, { throwOnError = false } = {}) {
  const errors = [];
  if (!state || !Array.isArray(state.bodies)) errors.push('Ragdoll bodies are missing.');
  else {
    for (const body of state.bodies) {
      for (const key of ['position', 'orientation', 'linearVelocity', 'angularVelocity', 'referencePosition', 'referenceOrientation']) {
        if (!Array.isArray(body[key]) || body[key].some(value => !Number.isFinite(value))) errors.push(`Body ${body.name ?? body.index} has invalid ${key}.`);
      }
      if (!body.shape || !Number.isFinite(bodyVolume(body.shape))) errors.push(`Body ${body.name ?? body.index} has an invalid shape.`);
      if (!(body.mass > 0) || !Number.isFinite(body.mass)) errors.push(`Body ${body.name ?? body.index} has invalid mass.`);
      if (body.orientation?.length === 4 && Math.abs(Math.hypot(...body.orientation) - 1) > 1e-5) errors.push(`Body ${body.name ?? body.index} orientation is not normalized.`);
    }
    for (const joint of state.joints || []) {
      if (!state.bodies[joint.a] || !state.bodies[joint.b] || joint.localA?.some(value => !Number.isFinite(value)) || joint.localB?.some(value => !Number.isFinite(value))) errors.push('Ragdoll contains an invalid joint.');
    }
  }
  const report = { valid: errors.length === 0, errors };
  if (throwOnError && errors.length) throw new Error(errors.join('\n'));
  return report;
}
