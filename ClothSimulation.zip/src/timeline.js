import { legacyPoseFrame } from './rig.js';

export const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
export const smooth = x => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };
const clone = value => structuredClone(value);

export function insertKey(keys, key) {
  const index = keys.findIndex(k => Math.abs(k.time - key.time) < 1 / 120);
  if (index >= 0) keys[index] = { ...clone(key), id: keys[index].id ?? key.id }; else keys.push(clone(key));
  keys.sort((a, b) => a.time - b.time);
  return keys;
}

export function surroundingKeys(keys, time) {
  if (!keys.length) return null;
  if (time <= keys[0].time) return [keys[0], keys[0], 0];
  for (let i = 1; i < keys.length; i++) if (keys[i].time >= time) {
    const a = keys[i - 1], b = keys[i];
    return [a, b, smooth((time - a.time) / Math.max(1e-6, b.time - a.time))];
  }
  return [keys.at(-1), keys.at(-1), 0];
}

export function sampleCamera(keys, time, fallback) {
  const pair = surroundingKeys(keys, time);
  if (!pair) return clone(fallback);
  const [ka, kb, u] = pair, a = ka.value, b = kb.value;
  const result = clone(a);
  for (const k of ['pitch', 'distance', 'fov']) result[k] = a[k] + (b[k] - a[k]) * u;
  const delta = Math.atan2(Math.sin(b.yaw - a.yaw), Math.cos(b.yaw - a.yaw));
  result.yaw = a.yaw + delta * u;
  result.target = a.target.map((v, i) => v + (b.target[i] - v) * u);
  return result;
}

function blendEuler(a,b,t) {
  const quaternion=e=>{
    const h=e.map(v=>v*Math.PI/360),[sx,sy,sz]=h.map(Math.sin),[cx,cy,cz]=h.map(Math.cos);
    return [sx*cy*cz-cx*sy*sz,cx*sy*cz+sx*cy*sz,cx*cy*sz-sx*sy*cz,cx*cy*cz+sx*sy*sz];
  };
  const qa=quaternion(a),qb=quaternion(b);
  let dot=qa.reduce((s,v,i)=>s+v*qb[i],0);
  if(dot<0){for(let i=0;i<4;i++)qb[i]*=-1;dot=-dot;}
  let u=1-t,v=t;
  if(dot<.9995){const angle=Math.acos(clamp(dot,-1,1)),s=Math.sin(angle);u=Math.sin((1-t)*angle)/s;v=Math.sin(t*angle)/s;}
  const q=qa.map((x,i)=>x*u+qb[i]*v),length=Math.hypot(...q),[x,y,z,w]=q.map(v=>v/length);
  return [Math.atan2(2*(w*x+y*z),1-2*(x*x+y*y)),Math.asin(clamp(2*(w*y-z*x),-1,1)),Math.atan2(2*(w*z+x*y),1-2*(y*y+z*z))].map(v=>Math.round(v*180/Math.PI*1e10)/1e10);
}

export function samplePose(keys, time, fallback = {}) {
  const pair = surroundingKeys(keys, time);
  if (!pair) return clone(fallback);
  const [a, b, u] = pair, result = {};
  for (const name of new Set([...Object.keys(a.value), ...Object.keys(b.value)])) {
    const x = a.value[name] || [0, 0, 0], y = b.value[name] || [0, 0, 0];
    result[name] = blendEuler(x,y,u);
  }
  return result;
}

export function sampleClip(clips, time, fallback = 'stand') {
  const clip = [...clips].reverse().find(c => time >= c.start && time < c.end);
  return clip ? { clip: clip.type, time: time - clip.start, speed: clip.speed || 1 } : { clip: fallback, time, speed: 1 };
}

export function samplePhase(events, time, hasSeam = false, settings = {}) {
  const releaseDuration=Math.max(.05,settings.releaseDuration??1),inflateDuration=Math.max(.05,settings.inflateDuration??3);
  const initial = { binding: 1, inflation: 1, seam: 1, phase: 'Posed', event: null };
  let event = null, from = initial;
  const evaluate = (e, at, start) => {
    if (!e) return initial;
    const elapsed = Math.max(0, at - e.time);
    const duration = Math.max(.05, e.type==='release'?releaseDuration:inflateDuration);
    if (e.type === 'release') {
      const u = smooth(elapsed / duration);
      return { binding: start.binding + ((settings.releaseBinding??e.target??0)-start.binding) * u, inflation: start.inflation * (1-u), seam: hasSeam ? start.seam * (1-u) : 1, phase: u === 1 ? 'Deflated' : 'Releasing', event: e };
    }
    const close = hasSeam && start.seam < .999 ? 1.4 : 0;
    const fill = smooth((elapsed-close)/duration), bind = smooth((elapsed-close)/duration);
    const target=settings.inflateBinding??e.target??1;
    return { binding: start.binding + (target-start.binding)*bind, inflation: start.inflation+(1-start.inflation)*fill,
      seam: start.seam+(1-start.seam)*smooth(elapsed/Math.max(close,.001)), phase: elapsed<close?'Closing seam':bind<1?'Inflating · assisted':'Recovered', event:e };
  };
  for (const e of events) {
    if (e.time > time) break;
    from = evaluate(event,e.time,from);
    event = e;
  }
  return evaluate(event,time,from);
}

export function grabReference(triangle, bary, density) {
  let quad = Math.floor(triangle/2);
  let u = triangle%2 === 0 ? bary[1]+bary[2] : bary[1];
  let v = triangle%2 === 0 ? bary[2] : bary[1]+bary[2];
  for (let level=0; level<density; level++) {
    const corner=quad%4;quad=Math.floor(quad/4);
    [u,v] = corner===0?[u*.5,v*.5]:corner===1?[1-v*.5,u*.5]:corner===2?[1-u*.5,1-v*.5]:[v*.5,1-u*.5];
  }
  return {quad,uv:[u,v]};
}

export function remapGrab(reference,density) {
  let quad=reference.quad,[u,v]=reference.uv;
  for(let level=0;level<density;level++) {
    const corner=v<=.5?(u<=.5?0:1):(u>.5?2:3);
    quad=quad*4+corner;
    [u,v]=corner===0?[2*u,2*v]:corner===1?[2*v,2*(1-u)]:corner===2?[2*(1-u),2*(1-v)]:[2*(1-v),2*u];
  }
  return u>=v?{triangle:quad*2,bary:[1-u,u-v,v]}:{triangle:quad*2+1,bary:[1-v,u,v-u]};
}

export function sampleGrab(events, time) {
  const event = [...events].reverse().find(e => time >= e.start && time < e.end);
  if (!event || !event.samples.length) return null;
  const pair = surroundingKeys(event.samples, time);
  const [a, b, u] = pair;
  return { id:event.id ?? `${event.start}:${event.triangle}`, triangle: event.triangle, bary: [...event.bary], target: a.value.map((v, i) => v + (b.value[i] - v) * u), strength: event.strength ?? .8, radius: event.radius ?? .12 };
}

export function defaultTimeline() {
  return { duration: 30, fps: 30, cameraKeys: [], poseKeys: [],
    clips: [],
    phases: [{ time: 1, type: 'release', duration: 1 }], grabs: [] };
}

export function cacheBytes(vertices, duration, fps) { return vertices * (Math.round(duration * fps) + 1) * 12; }

let sequence = 1;
export const TRACK_FIELDS = {camera:'cameraKeys',pose:'poseKeys',clip:'clips',phase:'phases',grab:'grabs'};
export function timelineItems(timeline) {
  const result=[],used=new Set(),reserved=new Set(Object.entries(TRACK_FIELDS).flatMap(([type,field])=>timeline[field].map(item=>`${type}:${item.id}`)));
  for(const [type,field] of Object.entries(TRACK_FIELDS))for(const item of timeline[field]){
    if(item.id==null || used.has(`${type}:${item.id}`)){do{item.id=`k${sequence++}`;}while(reserved.has(`${type}:${item.id}`)||used.has(`${type}:${item.id}`));}
    used.add(`${type}:${item.id}`);result.push({type,item,token:`${type}:${item.id}`});
  }
  return result;
}
export function retimeSelection(timeline,tokens,delta) {
  const selected=timelineItems(timeline).filter(e=>tokens.has(e.token));
  if(!selected.length)return {changed:false,physics:false,delta:0};
  const start=Math.min(...selected.map(({item})=>item.time??item.start));
  const end=Math.max(...selected.map(({item})=>item.time??item.end));
  delta=clamp(Math.round(delta*timeline.fps)/timeline.fps,-start,Math.max(0,timeline.duration-end));
  if(Math.abs(delta)<1e-8)return {changed:false,physics:false,delta:0};
  for(const {item} of selected){
    if(item.time!=null)item.time+=delta;
    else{item.start+=delta;item.end+=delta;if(item.samples)for(const key of item.samples)key.time+=delta;}
  }
  for(const field of ['cameraKeys','poseKeys','phases'])timeline[field].sort((a,b)=>a.time-b.time);
  return {changed:true,physics:selected.some(e=>e.type!=='camera'),delta};
}
export function deleteSelection(timeline,tokens) {
  let removed=0,physics=false;
  for(const [type,field]of Object.entries(TRACK_FIELDS))timeline[field]=timeline[field].filter(item=>{
    if(!tokens.has(`${type}:${item.id}`))return true;
    removed++;if(type!=='camera')physics=true;return false;
  });
  return{removed,physics};
}
export function samplePoseTransform(keys,time,root={position:[0,0,0],rotation:[0,0,0]},offsets={}) {
  const pair=surroundingKeys(keys,time);
  if(!pair)return {root:clone(root),offsets:clone(offsets)};
  const [a,b,t]=pair,ra=a.root??root,rb=b.root??root,oa=a.offsets??offsets,ob=b.offsets??offsets;
  const mixed={};
  for(const name of new Set([...Object.keys(oa),...Object.keys(ob)]))mixed[name]=(oa[name]??[0,0,0]).map((v,i)=>v+((ob[name]??[0,0,0])[i]-v)*t);
  return {root:{position:ra.position.map((v,i)=>v+(rb.position[i]-v)*t),rotation:blendEuler(ra.rotation,rb.rotation,t)},offsets:mixed};
}

export function migrateLegacyClips(timeline, pose = {}, root = {position:[0,0,0],rotation:[0,0,0]}, offsets = {}) {
  if(!timeline.clips?.length)return false;
  if(timeline.clips.every(c=>c.type==='stand')){timeline.clips=[];return true;}
  const keys=clone(timeline.poseKeys),times=new Set(keys.map(k=>k.time));
  for(let i=0;i<=Math.round(timeline.duration*30);i++)times.add(Math.min(timeline.duration,i/30));
  for(const c of timeline.clips)for(const t of [c.start,c.end])if(t<=timeline.duration){times.add(t);times.add(Math.max(0,t-.0001));}
  timeline.poseKeys=[...times].sort((a,b)=>a-b).map(time=>{
    const clip=sampleClip(timeline.clips,time),frame=legacyPoseFrame(clip.clip,clip.time,clip.speed),value=samplePose(keys,time,pose),transform=samplePoseTransform(keys,time,root,offsets);
    for(const name of new Set([...Object.keys(value),...Object.keys(frame.value)]))value[name]=[0,1,2].map(i=>(value[name]?.[i]??0)+(frame.value[name]?.[i]??0));
    transform.root.position=transform.root.position.map((v,i)=>v+frame.root.position[i]);
    return {time,value,root:transform.root,offsets:transform.offsets};
  });
  timeline.clips=[];return true;
}

export function validatePoseLibrary(library) {
  if(!Array.isArray(library)||library.length>100)throw new Error('自定义姿势最多保存 100 个。');
  const ids=new Set();
  for(const pose of library){
    if(!pose||typeof pose.id!=='string'||!/^user-[a-zA-Z0-9-]{1,80}$/.test(pose.id)||ids.has(pose.id)||typeof pose.name!=='string'||!pose.name.trim()||pose.name.length>60)throw new Error('姿势名称或标识无效。');
    if(pose.root==null||pose.offsets==null)throw new Error('姿势缺少根节点或关节位移数据。');
    validateTimeline({...defaultTimeline(),poseKeys:[{time:0,value:pose.value,root:pose.root,offsets:pose.offsets}]});ids.add(pose.id);
  }
  return library;
}

export function validateTimeline(timeline) {
  const vec=(v,limit=1e4)=>Array.isArray(v)&&v.length===3&&v.every(n=>Number.isFinite(n)&&Math.abs(n)<=limit);
  const map=(v,limit)=>v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length<=128&&!Object.keys(v).some(k=>['__proto__','constructor','prototype'].includes(k))&&Object.values(v).every(x=>vec(x,limit));
  const time=t=>Number.isFinite(t)&&t>=0&&t<=120;
  if (!timeline || !Number.isFinite(timeline.duration) || timeline.duration < 1 || timeline.duration > 120) throw new Error('场景时长须为 1–120 秒。');
  if (![24, 30, 60].includes(timeline.fps)) throw new Error('帧率须为 24、30 或 60。');
  for (const field of Object.values(TRACK_FIELDS)) {
    if (!Array.isArray(timeline[field]) || timeline[field].length > 10000 || timeline[field].some(x=>!x||typeof x!=='object')) throw new Error('时间轴轨道无效。');
    for(const item of timeline[field])if(item.id!=null && !(typeof item.id==='string'&&item.id.length<=100 || Number.isSafeInteger(item.id)))throw new Error('关键帧标识无效。');
  }
  for (const phase of timeline.phases) if (!['release', 'inflate'].includes(phase.type) || !time(phase.time) || !Number.isFinite(phase.duration) || phase.duration <= 0 || phase.duration>120) throw new Error('模拟阶段无效。');
  for (const clip of timeline.clips) if (!['stand', 'walk', 'sit'].includes(clip.type) || !time(clip.start) || !time(clip.end) || clip.end <= clip.start || !Number.isFinite(clip.speed) || clip.speed <= 0 || clip.speed > 4) throw new Error('动作片段无效。');
  for (const key of timeline.cameraKeys) {
    const c = key.value;
    if (!time(key.time) || !c || !vec(c.target) || !['yaw', 'pitch', 'distance', 'fov'].every(k => Number.isFinite(c[k])) || c.distance < .1 || c.distance > 100 || c.fov < 10 || c.fov > 120) throw new Error('相机关键帧无效。');
  }
  for (const key of timeline.poseKeys) {
    if (!time(key.time) || !map(key.value,360)) throw new Error('姿势关键帧无效。');
    if(key.root!=null && (!vec(key.root.position,5)||!vec(key.root.rotation,360)))throw new Error('根节点变换无效。');
    if(key.offsets!=null && !map(key.offsets,.5))throw new Error('关节位移无效。');
  }
  for (const e of timeline.grabs) {
    if(e.reference && (!Number.isSafeInteger(e.reference.quad) || e.reference.quad<0 || !Array.isArray(e.reference.uv) || e.reference.uv.length!==2 || !e.reference.uv.every(v=>Number.isFinite(v)&&v>=0&&v<=1))) throw new Error('抓取表面坐标无效。');
    if (!Number.isInteger(e.triangle) || e.triangle < 0 || !time(e.start) || !time(e.end) || e.end < e.start || !vec(e.bary,1) || e.bary.some(v=>v<0) || Math.abs(e.bary.reduce((a,b)=>a+b,0)-1) > .001 || !Array.isArray(e.samples) || !e.samples.length || e.samples.length > 20000 || !e.samples.every(s => s&&time(s.time)&&vec(s.value))) throw new Error('抓取轨道无效。');
    if(e.radius!=null&&(!Number.isFinite(e.radius)||e.radius<.01||e.radius>.5) || e.strength!=null&&(!Number.isFinite(e.strength)||e.strength<0||e.strength>1))throw new Error('抓取半径或力度无效。');
    e.samples.sort((a,b)=>a.time-b.time);
  }
  timeline.phases.sort((a,b) => a.time-b.time);
  timeline.cameraKeys.sort((a,b) => a.time-b.time);
  timeline.poseKeys.sort((a,b) => a.time-b.time);
  timelineItems(timeline);
  return timeline;
}
