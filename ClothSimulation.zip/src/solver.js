import shaderSource from './physics.wgsl';

const GROUP_SIZE = 128;
const VERTEX_BYTES = 160;
const CONSTRAINT_BYTES = 96;
const MAX_COLLIDERS = 32;
const PROFILES = Object.freeze({
  preview: Object.freeze({ substeps: 5, iterations: 4, contacts: 1 }),
  bake: Object.freeze({ substeps: 14, iterations: 7, contacts: 2 }),
});
const ENTRY_POINTS = [
  'skin', 'reset', 'captureGrab', 'predict', 'solveConstraints', 'gatherConstraints',
  'volumePartial', 'volumeFinish', 'applyVolume', 'hashClear', 'hashBuild',
  'contacts', 'applyContacts', 'surfaceLeafBounds', 'surfaceBounds', 'surfaceContacts', 'applySurfaceContacts',
  'attachments', 'finish', 'updateNormals',
  'pickPartial', 'pickFinish', 'diagnosticSummary',
];
const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
const groups = count => Math.max(1, Math.ceil(count / GROUP_SIZE));
const subtract = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const normalized = a => { const length = Math.hypot(...a) || 1; return a.map(x => x / length); };

function preprocess(mesh) {
  const count = mesh.vertexCount ?? mesh.positions.length / 4;
  if (!Number.isInteger(count) || count < 3 || mesh.positions.length !== count * 4) {
    throw new Error('布料位置数据必须为每个顶点提供四个浮点数。');
  }
  if (!mesh.indices?.length || mesh.indices.length % 3) throw new Error('布料网格需要完整的三角形索引。');
  const points = Array.from({ length: count }, (_, i) => Array.from(mesh.positions.subarray(i * 4, i * 4 + 3)));
  const areas = new Float32Array(count);
  const faces = Array.from({ length: count }, () => []);
  const adjacency = Array.from({ length: count }, () => []);
  const surfaceNeighbors = Array.from({ length: count }, () => []);
  const edges = new Map();
  const links = [];
  let signedVolume = 0;
  let boundaryEdges = 0;
  let nonManifoldEdges = 0;
  const addLink = (ids, rest, kind, spare = 0) => {
    const index = links.length;
    links.push({ ids, rest, kind, spare });
    for (let k = 0; k < (kind === 1 ? 4 : 2); k++) adjacency[ids[k]].push((index << 2) | k);
  };
  for (let t = 0; t < mesh.indices.length / 3; t++) {
    const ids = Array.from(mesh.indices.subarray(t * 3, t * 3 + 3));
    if (ids.some(index => index >= count)) throw new Error('布料三角形索引超出顶点缓冲区范围。');
    const [a, b, c] = ids.map(index => points[index]);
    const area = Math.hypot(...cross(subtract(b, a), subtract(c, a))) / 2;
    signedVolume += dot(a, cross(b, c)) / 6;
    for (const i of ids) { areas[i] += area / 3; faces[i].push(t); }
    for (let k = 0; k < 3; k++) {
      const aId = ids[k], bId = ids[(k + 1) % 3], opposite = ids[(k + 2) % 3];
      const key = `${Math.min(aId, bId)},${Math.max(aId, bId)}`;
      const edge = edges.get(key);
      if (edge) edge.opposites.push(opposite);
      else edges.set(key, { a: aId, b: bId, opposites: [opposite] });
    }
  }
  for (const edge of edges.values()) {
    const { a, b, opposites } = edge;
    const vector = subtract(points[b], points[a]);
    const length = Math.hypot(...vector);
    surfaceNeighbors[a].push([b, length]);
    surfaceNeighbors[b].push([a, length]);
    addLink([a, b, 0, 0], length, 0);
    if (opposites.length === 2) {
      const [c, d] = opposites;
      const n1 = normalized(cross(vector, subtract(points[c], points[a])));
      const n2 = normalized(cross(subtract(points[d], points[a]), vector));
      const angle = Math.atan2(dot(cross(n1, n2), normalized(vector)), clamp(dot(n1, n2), -1, 1));
      addLink([a, b, c, d], angle, 1, length * length);
    } else if (opposites.length === 1) boundaryEdges++;
    else nonManifoldEdges++;
  }
  const seamPairs = mesh.seamPairs ?? new Uint32Array();
  const seamNeighbors = Array.from({ length: count }, () => []);
  if (seamPairs.length % 2) throw new Error('每个缝合点对必须包含两个顶点索引。');
  for (let k = 0; k < seamPairs.length; k += 2) {
    const a = seamPairs[k], b = seamPairs[k + 1];
    if (a >= count || b >= count) throw new Error('缝合顶点索引超出顶点缓冲区范围。');
    if (a !== b) {
      addLink([a, b, 0, 0], 0, 2);
      seamNeighbors[a].push(b);
      seamNeighbors[b].push(a);
    }
  }
  const data = [];
  const ranges = adjacency.map(list => { const start = data.length; data.push(...list); return [start, list.length, 0, 0]; });
  const triangleOffset = data.length;
  for (const index of mesh.indices) data.push(index);
  for (let i = 0; i < count; i++) {
    ranges[i][2] = data.length;
    ranges[i][3] = faces[i].length;
    data.push(...faces[i]);
  }
  // 静态面拓扑树；每轮在 GPU 上重拟合包括上一子步位置的扫掠包围盒。
  const triangleOrder = Array.from({ length: mesh.indices.length / 3 }, (_, i) => i);
  const centroids = triangleOrder.map(t => [0, 1, 2].map(axis =>
    (points[mesh.indices[t * 3]][axis] + points[mesh.indices[t * 3 + 1]][axis] + points[mesh.indices[t * 3 + 2]][axis]) / 3));
  const surfaceNodes = [], surfaceLeaves = [];
  const buildSurfaceTree = (start, end) => {
    const index = surfaceNodes.length;
    const node = [start, end - start, 0, end - start <= 4 ? 1 : 0, surfaceLeaves.length, 0];
    surfaceNodes.push(node);
    if (!node[3]) {
      const low = [Infinity, Infinity, Infinity], high = [-Infinity, -Infinity, -Infinity];
      for (let k = start; k < end; k++) for (let axis = 0; axis < 3; axis++) {
        low[axis] = Math.min(low[axis], centroids[triangleOrder[k]][axis]);
        high[axis] = Math.max(high[axis], centroids[triangleOrder[k]][axis]);
      }
      const axis = [0, 1, 2].sort((a, b) => (high[b] - low[b]) - (high[a] - low[a]))[0];
      const sorted = triangleOrder.slice(start, end).sort((a, b) => centroids[a][axis] - centroids[b][axis]);
      for (let k = 0; k < sorted.length; k++) triangleOrder[start + k] = sorted[k];
      const middle = (start + end) >> 1;
      buildSurfaceTree(start, middle);
      buildSurfaceTree(middle, end);
    } else surfaceLeaves.push(index);
    node[2] = surfaceNodes.length;
    node[5] = surfaceLeaves.length - node[4];
    return index;
  };
  buildSurfaceTree(0, triangleOrder.length);
  const surfaceNodeOffset = data.length;
  for (const node of surfaceNodes) data.push(...node);
  const surfaceOrderOffset = data.length;
  for (const t of triangleOrder) data.push(t);
  const surfaceLeafOffset = data.length;
  data.push(surfaceLeaves.length);
  for (const leaf of surfaceLeaves) data.push(leaf);
  const surfaceFeatureOffset = data.length;
  for (let t = 0; t < triangleOrder.length; t++) {
    let mask = 0;
    const vertexOwners = [], edgeOwners = [];
    for (let k = 0; k < 3; k++) {
      const a = mesh.indices[t * 3 + k], b = mesh.indices[t * 3 + (k + 1) % 3];
      const vertexOwner = faces[a][0];
      const edgeOwner = faces[a].find(face => mesh.indices.subarray(face * 3, face * 3 + 3).includes(b));
      if (vertexOwner === t) mask |= 1 << k;
      if (edgeOwner === t) mask |= 1 << (k + 3);
      vertexOwners.push(vertexOwner);
      edgeOwners.push(edgeOwner);
    }
    data.push(mask, ...vertexOwners, ...edgeOwners);
  }
  const surfaceSeamOffset = data.length;
  for (let i = 0; i < count; i++) data.push(0, 0);
  for (let i = 0; i < count; i++) {
    data[surfaceSeamOffset + i * 2] = data.length;
    data[surfaceSeamOffset + i * 2 + 1] = seamNeighbors[i].length;
    data.push(...seamNeighbors[i]);
  }
  const vertexData = new ArrayBuffer(count * VERTEX_BYTES);
  const vf = new Float32Array(vertexData), vu = new Uint32Array(vertexData);
  let boneCount = 1;
  for (let i = 0; i < count; i++) {
    const base = i * VERTEX_BYTES / 4;
    vf.set([...points[i], Math.max(areas[i], 1e-7)], base);
    vf.set([...points[i], 1], base + 4);
    vf.set([...points[i], 1], base + 12);
    if (mesh.boneIndices) {
      const ids = mesh.boneIndices.subarray(i * 4, i * 4 + 4);
      vu.set(ids, base + 16);
      for (const id of ids) boneCount = Math.max(boneCount, id + 1);
    }
    if (mesh.boneWeights) vf.set(mesh.boneWeights.subarray(i * 4, i * 4 + 4), base + 20);
    else vf[base + 20] = 1;
    const weight = vf[base + 20] + vf[base + 21] + vf[base + 22] + vf[base + 23];
    if (weight > 0) for (let k = 0; k < 4; k++) vf[base + 20 + k] /= weight;
    else vf[base + 20] = 1;
    vu.set(ranges[i], base + 24);
    if (mesh.normals) vf.set(mesh.normals.subarray(i * 4, i * 4 + 3), base + 36);
    else vf[base + 37] = 1;
  }
  const constraintData = new ArrayBuffer(Math.max(CONSTRAINT_BYTES, links.length * CONSTRAINT_BYTES));
  const cf = new Float32Array(constraintData), cu = new Uint32Array(constraintData);
  links.forEach((link, i) => {
    const base = i * CONSTRAINT_BYTES / 4;
    cu.set(link.ids, base);
    cf[base + 4] = link.rest;
    cu[base + 5] = link.kind;
    cf[base + 7] = link.spare;
  });
  return {
    count, constraintCount: links.length, triangleCount: mesh.indices.length / 3,
    vertexData, constraintData, topology: new Uint32Array(data), triangleOffset, boneCount,
    points, surfaceNeighbors, surfaceNodeOffset, surfaceOrderOffset, surfaceNodeCount: surfaceNodes.length, surfaceFeatureOffset, surfaceSeamOffset, surfaceLeafOffset, surfaceLeafCount: surfaceLeaves.length,
    restVolume: Math.abs(mesh.restVolume || signedVolume), orientation: Math.sign(signedVolume) || 1,
    boundaryEdges, nonManifoldEdges, seamCount: seamPairs.length / 2,
  };
}

function createGrabPatch(prepared, triangle, bary, radius) {
  const ids = prepared.topology.subarray(prepared.triangleOffset + triangle * 3, prepared.triangleOffset + triangle * 3 + 3);
  const center = [0, 0, 0];
  for (let k = 0; k < 3; k++) for (let axis = 0; axis < 3; axis++) center[axis] += prepared.points[ids[k]][axis] * bary[k];
  const distances = new Float64Array(prepared.count).fill(Infinity);
  const heap = [];
  const enqueue = (vertex, distance) => {
    if (distance >= radius || distance >= distances[vertex]) return;
    distances[vertex] = distance;
    const entry = [vertex, distance];
    let index = heap.length;
    heap.push(entry);
    while (index > 0) {
      const parent = (index - 1) >> 1;
      if (heap[parent][1] <= distance) break;
      heap[index] = heap[parent];
      index = parent;
    }
    heap[index] = entry;
  };
  for (const id of ids) enqueue(id, Math.hypot(...subtract(prepared.points[id], center)));
  while (heap.length) {
    const [vertex, distance] = heap[0];
    const last = heap.pop();
    if (heap.length) {
      let index = 0;
      while (index * 2 + 1 < heap.length) {
        let child = index * 2 + 1;
        if (child + 1 < heap.length && heap[child + 1][1] < heap[child][1]) child++;
        if (heap[child][1] >= last[1]) break;
        heap[index] = heap[child];
        index = child;
      }
      heap[index] = last;
    }
    if (distance !== distances[vertex]) continue;
    for (const [neighbor, length] of prepared.surfaceNeighbors[vertex]) enqueue(neighbor, distance + length);
  }
  const data = new Float32Array(prepared.count * 4);
  let count = 0;
  for (let i = 0; i < prepared.count; i++) {
    if (distances[i] >= radius) continue;
    const falloff = 1 - distances[i] / radius;
    data[i * 4 + 3] = falloff * falloff * (3 - 2 * falloff);
    count++;
  }
  // A brush smaller than one triangle still needs a representable material anchor.
  if (!count) for (let k = 0; k < 3; k++) {
    data[ids[k] * 4 + 3] = bary[k];
    if (bary[k] > 0) count++;
  }
  return { data, count };
}

export async function createSolver(device, mesh) {
  const prepared = preprocess(mesh);
  const { count, constraintCount, triangleCount } = prepared;
  if (device.limits.maxStorageBuffersPerShaderStage < 8) throw new Error('布料模拟需要八个计算存储缓冲区。');
  const ownedBuffers = [];
  const buffer = (label, byteLength, usage, initial) => {
    const created = device.createBuffer({ label, size: Math.max(16, Math.ceil(byteLength / 4) * 4), usage });
    ownedBuffers.push(created);
    if (initial) device.queue.writeBuffer(created, 0, initial);
    return created;
  };
  const storageUsage = GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST;
  const positions = buffer('Cloth positions', count * 16, storageUsage | GPUBufferUsage.VERTEX, mesh.positions);
  const normals = buffer('Cloth normals', count * 16, storageUsage | GPUBufferUsage.VERTEX, mesh.normals || new Float32Array(count * 4));
  const vertexState = buffer('Cloth particle state', prepared.vertexData.byteLength, storageUsage, prepared.vertexData);
  const constraintState = buffer('Cloth XPBD constraints', prepared.constraintData.byteLength, storageUsage, prepared.constraintData);
  const topology = buffer('Cloth adjacency', prepared.topology.byteLength, storageUsage, prepared.topology);
  const boneCapacity = Math.max(128, prepared.boneCount);
  const sceneData = new Float32Array((boneCapacity * 4 + MAX_COLLIDERS * 3) * 4);
  for (let i = 0; i < boneCapacity; i++) sceneData.set([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1], i * 16);
  const sceneBuffer = buffer('Cloth input transforms', sceneData.byteLength, storageUsage, sceneData);
  let hashBuckets = 1;
  while (hashBuckets < count * 2) hashBuckets *= 2;
  const volumeOffset = 16;
  const pickingOffset = volumeOffset + groups(count) * 3;
  const hashHeadOffset = pickingOffset + groups(triangleCount) * 4;
  const hashCountOffset = hashHeadOffset + hashBuckets;
  const hashDataOffset = hashCountOffset + hashBuckets;
  const surfaceBoundsOffset = hashDataOffset + count;
  const surfaceContactOffset = surfaceBoundsOffset + prepared.surfaceNodeCount * 6;
  const scratchWords = surfaceContactOffset + count * 4;
  const scratchBuffer = buffer('Cloth spatial hash and reductions', scratchWords * 4, storageUsage);
  const grabBuffer = buffer('Cloth soft-grab reference patch', count * 16, storageUsage);
  const parameterData = new ArrayBuffer(256);
  const pf = new Float32Array(parameterData), pu = new Uint32Array(parameterData);
  pu.set([count, constraintCount, triangleCount, hashBuckets - 1], 0);
  pu.set([hashCountOffset, prepared.triangleOffset, pickingOffset, hashDataOffset], 4);
  pu.set([volumeOffset, groups(count), count, hashHeadOffset], 8);
  pf.set([1 / 300, 1, 1, 1], 12);
  pf.set([1e-7, 1e-4, 0.8, 0.45], 16);
  pf.set([0.004, 0.25, 1, prepared.restVolume], 20);
  pu.set([boneCapacity, 0, boneCapacity * 4, 0xffffffff], 24);
  pf[35] = -9.81;
  pf[48] = prepared.orientation;
  pf[49] = prepared.seamCount > 0 ? 1 : 0;
  pu.set([prepared.surfaceNodeOffset, prepared.surfaceNodeCount, prepared.surfaceOrderOffset, surfaceBoundsOffset], 52);
  pu.set([surfaceContactOffset, prepared.surfaceFeatureOffset, prepared.surfaceSeamOffset, prepared.surfaceLeafOffset], 56);
  const uniformBuffer = buffer('Cloth parameters', 256, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST, parameterData);
  device.pushErrorScope('validation');
  const module = device.createShaderModule({ label: 'GPU XPBD cloth', code: shaderSource });
  const compilation = await module.getCompilationInfo();
  const errors = compilation.messages.filter(message => message.type === 'error');
  if (errors.length) {
    await device.popErrorScope();
    ownedBuffers.forEach(item => item.destroy());
    throw new Error(`布料 WGSL 编译失败：\n${errors.map(error => `${error.lineNum}:${error.linePos} ${error.message}`).join('\n')}`);
  }
  const bindings = [uniformBuffer, positions, normals, vertexState, constraintState, topology, sceneBuffer, scratchBuffer, grabBuffer];
  const bindGroupLayout = device.createBindGroupLayout({
    label: 'Cloth compute bindings',
    entries: bindings.map((_, binding) => ({
      binding, visibility: GPUShaderStage.COMPUTE,
      buffer: { type: binding === 0 ? 'uniform' : binding === 5 || binding === 6 ? 'read-only-storage' : 'storage' },
    })),
  });
  const layout = device.createPipelineLayout({ bindGroupLayouts: [bindGroupLayout] });
  let pipelines;
  try {
    pipelines = Object.fromEntries(await Promise.all(ENTRY_POINTS.map(async entryPoint => [entryPoint,
      await device.createComputePipelineAsync({ label: `Cloth ${entryPoint}`, layout, compute: { module, entryPoint } }),
    ])));
  } catch (error) {
    await device.popErrorScope();
    ownedBuffers.forEach(item => item.destroy());
    throw new Error(`布料计算管线创建失败： ${error.message}`);
  }
  const bindGroup = device.createBindGroup({
    label: 'Cloth state', layout: bindGroupLayout,
    entries: bindings.map((item, binding) => ({ binding, resource: { buffer: item } })),
  });
  const pipelineError = await device.popErrorScope();
  if (pipelineError) {
    ownedBuffers.forEach(item => item.destroy());
    throw new Error(`布料计算管线验证失败： ${pipelineError.message}`);
  }
  let destroyed = false;
  let lastQuality = 'preview';
  let frames = 0;
  let activeGrab = null;
  const clearGrab = () => {
    activeGrab = null;
    pu[27] = 0xffffffff;
    pf[31] = 0;
  };
  const updateGrab = grab => {
    const finiteVector = value => value?.length === 3 && Array.from(value).every(Number.isFinite);
    if (!grab || !Number.isInteger(grab.triangle) || grab.triangle < 0 || grab.triangle >= triangleCount
      || !finiteVector(grab.target) || !finiteVector(grab.bary) || Array.from(grab.bary).some(value => value < -1e-5)
      || !Number.isFinite(grab.radius ?? 0.12) || !Number.isFinite(grab.strength ?? 1)) {
      clearGrab();
      return false;
    }
    const bary = Array.from(grab.bary, value => Math.max(0, value));
    const total = bary[0] + bary[1] + bary[2];
    if (total <= 1e-8) { clearGrab(); return false; }
    for (let i = 0; i < 3; i++) bary[i] /= total;
    const radius = grab.radius === 0 ? 0 : clamp(grab.radius ?? 0.12, 0.02, 0.3);
    const id = grab.id ?? null;
    const changed = !activeGrab || activeGrab.id !== id || activeGrab.triangle !== grab.triangle
      || activeGrab.radius !== radius || activeGrab.bary.some((value, i) => value !== bary[i]);
    pu[27] = grab.triangle;
    pf.set([...grab.target, clamp(grab.strength ?? 1, 0, 1)], 28);
    pf.set([...bary, radius], 32);
    if (changed) {
      let patchCount = bary.filter(value => value > 0).length;
      if (radius > 0) {
        const patch = createGrabPatch(prepared, grab.triangle, bary, radius);
        device.queue.writeBuffer(grabBuffer, 0, patch.data);
        patchCount = patch.count;
      }
      activeGrab = { id, triangle: grab.triangle, bary, radius, count: patchCount };
    }
    return changed && radius > 0;
  };
  const ensureAlive = () => { if (destroyed) throw new Error('布料求解器已释放，无法继续使用。'); };
  const uploadUniform = () => device.queue.writeBuffer(uniformBuffer, 0, parameterData);
  const dispatch = (pass, name, workgroups = groups(count)) => {
    pass.setPipeline(pipelines[name]);
    pass.dispatchWorkgroups(workgroups);
  };
  const begin = label => {
    const encoder = device.createCommandEncoder({ label });
    const pass = encoder.beginComputePass({ label });
    pass.setBindGroup(0, bindGroup);
    return { encoder, pass };
  };
  const end = ({ encoder, pass }) => { pass.end(); device.queue.submit([encoder.finish()]); };
  const volume = pass => {
    dispatch(pass, 'volumePartial');
    dispatch(pass, 'volumeFinish', 1);
  };
  const computeNormals = () => {
    const commands = begin('Refresh cached cloth surface');
    dispatch(commands.pass, 'updateNormals');
    end(commands);
  };
  const uploadBones = matrices => {
    if (!matrices) return;
    if (matrices.length % 16 || matrices.length > boneCapacity * 16) throw new Error(`骨骼矩阵数据必须包含完整矩阵（最多 ${boneCapacity} 个）。`);
    sceneData.set(matrices, 0);
  };
  const readBuffer = async (source, offset, size) => {
    ensureAlive();
    const staging = device.createBuffer({ label: 'Cloth requested readback', size, usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ });
    const encoder = device.createCommandEncoder();
    encoder.copyBufferToBuffer(source, offset, staging, 0, size);
    device.queue.submit([encoder.finish()]);
    try {
      await staging.mapAsync(GPUMapMode.READ);
      const result = staging.getMappedRange().slice(0);
      staging.unmap();
      return result;
    } finally { staging.destroy(); }
  };
  const readPositions = async () => {
    const packed = new Float32Array(await readBuffer(positions, 0, count * 16));
    const xyz = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) xyz.set(packed.subarray(i * 4, i * 4 + 3), i * 3);
    return xyz;
  };
  const writePositions = xyz => {
    ensureAlive();
    if (xyz.length !== count * 3) throw new Error('缓存的布料位置数据与顶点数量不一致。');
    const packed = new Float32Array(count * 4);
    for (let i = 0; i < count; i++) {
      packed.set(xyz.subarray(i * 3, i * 3 + 3), i * 4);
      packed[i * 4 + 3] = 1;
    }
    device.queue.writeBuffer(positions, 0, packed);
    clearGrab();
    uploadUniform();
    computeNormals();
  };

  const solver = {
    positions, normals, vertexCount: count,
    get grabPatchCount() { return activeGrab?.count ?? 0; },
    profiles: PROFILES,
    selfCollisionMethod: 'Swept triangle BVH; two-way vertex-triangle and edge-edge contacts with cubic coplanarity CCD; spatial-hash vertex fallback',
    selfCollisionLimitations: 'Iterative, not intersection-free: residual dense-fold contacts, degenerate/coplanar sweeps and subsequent collider projections can still penetrate; no global volume floor',
    step(dt, inputs = {}) {
      ensureAlive();
      if (!Number.isFinite(dt) || dt <= 0) return;
      const quality = inputs.quality === 'bake' ? 'bake' : 'preview';
      const profile = PROFILES[quality];
      lastQuality = quality;
      const material = inputs.material || {};
      pf.set([
        clamp(dt, 1 / 1000, 1 / 20) / profile.substeps,
        clamp(inputs.binding ?? 1, 0, 1), clamp(inputs.inflation ?? 1, 0, 1), clamp(inputs.seam ?? 1, 0, 1),
      ], 12);
      pf.set([
        clamp(material.stretch ?? 1e-7, 0, 1), clamp(material.bend ?? 1e-4, 0, 10),
        clamp(material.damping ?? 0.8, 0, 10), clamp(material.friction ?? 0.45, 0, 1),
      ], 16);
      pf.set([
        clamp(material.thickness ?? 0.004, 0.0005, 0.05), clamp(material.mass ?? 0.25, 0.01, 20),
        clamp(material.pressure ?? 1, 0, 10), prepared.restVolume,
      ], 20);
      pf[35] = inputs.gravityEnabled === false ? 0 : clamp(inputs.gravity ?? -9.81,-50,20);
      uploadBones(inputs.boneMatrices);
      const colliders = inputs.colliders || [];
      if (colliders.length > MAX_COLLIDERS) throw new Error(`布料模拟最多支持 ${MAX_COLLIDERS} 个碰撞体。`);
      pu[25] = colliders.length;
      for (let i = 0; i < colliders.length; i++) {
        const collider = colliders[i];
        const size = collider.size || [0.2, 0.2, 0.2];
        const radius = collider.radius ?? Math.max(size[0], size[2]) / 2;
        const height = collider.height ?? Math.max(0, size[1] - 2 * radius);
        const type = collider.type === 'sphere' ? 1 : collider.type === 'capsule' ? 2 : 0;
        const rotation = collider.rotation || 0;
        sceneData.set([
          ...(collider.position || [0, 0, 0]), type,
          size[0] / 2, size[1] / 2, size[2] / 2, radius,
          Math.cos(rotation), Math.sin(rotation), Math.max(0, height / 2), collider.pitch||0,
        ], boneCapacity * 16 + i * 12);
      }
      const captureGrab = updateGrab(inputs.grab);
      device.queue.writeBuffer(sceneBuffer, 0, sceneData);
      uploadUniform();
      const commands = begin(`Cloth ${quality} frame`);
      const pass = commands.pass;
      dispatch(pass, 'skin');
      if (captureGrab) dispatch(pass, 'captureGrab');
      for (let step = 0; step < profile.substeps; step++) {
        dispatch(pass, 'predict', groups(Math.max(count, constraintCount)));
        for (let iteration = 0; iteration < profile.iterations; iteration++) {
          dispatch(pass, 'solveConstraints', groups(constraintCount));
          dispatch(pass, 'gatherConstraints');
          if (iteration === profile.iterations - 1 || iteration === Math.floor(profile.iterations / 2)) {
            volume(pass);
            dispatch(pass, 'applyVolume');
          }
        }
        dispatch(pass, 'attachments');
        dispatch(pass, 'applyContacts');
        for (let iteration = 0; iteration < profile.contacts; iteration++) {
          dispatch(pass, 'surfaceLeafBounds', groups(Math.max(count, prepared.surfaceLeafCount)));
          dispatch(pass, 'surfaceBounds', groups(prepared.surfaceNodeCount));
          dispatch(pass, 'surfaceContacts', groups(triangleCount));
          dispatch(pass, 'applySurfaceContacts');
          dispatch(pass, 'hashClear', groups(hashBuckets));
          dispatch(pass, 'hashBuild');
          dispatch(pass, 'contacts');
          dispatch(pass, 'applyContacts');
        }
        dispatch(pass, 'finish');
      }
      dispatch(pass, 'updateNormals');
      end(commands);
      frames++;
    },
    reset({ boneMatrices, offset = [0, 0, 0] } = {}) {
      ensureAlive();
      clearGrab();
      uploadBones(boneMatrices);
      device.queue.writeBuffer(sceneBuffer, 0, sceneData);
      pf.set([...offset, boneMatrices ? 1 : 0], 36);
      uploadUniform();
      const commands = begin('Reset cloth state');
      dispatch(commands.pass, 'reset', groups(Math.max(count, constraintCount)));
      dispatch(commands.pass, 'updateNormals');
      end(commands);
      frames = 0;
    },
    readPositions,
    writePositions,
    async readState() {
      ensureAlive();
      const encoder = device.createCommandEncoder({ label: 'Snapshot GPU cloth state' });
      const vertexBytes = count * VERTEX_BYTES;
      const stateBytes = count * 16 + vertexBytes;
      const totalBytes = stateBytes + count * 16;
      const staging = device.createBuffer({ label: 'Cloth checkpoint readback', size: totalBytes, usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST });
      encoder.copyBufferToBuffer(positions, 0, staging, 0, count * 16);
      encoder.copyBufferToBuffer(vertexState, 0, staging, count * 16, vertexBytes);
      encoder.copyBufferToBuffer(grabBuffer, 0, staging, stateBytes, count * 16);
      device.queue.submit([encoder.finish()]);
      const savedParameters = parameterData.slice(0);
      const savedScene = sceneData.slice();
      const savedFrames = frames;
      const savedGrab = activeGrab ? { ...activeGrab, bary: [...activeGrab.bary] } : null;
      try {
        await staging.mapAsync(GPUMapMode.READ);
        const data = staging.getMappedRange().slice(0);
        staging.unmap();
        return {
          vertexCount: count, data: data.slice(0, stateBytes), parameters: savedParameters, scene: savedScene, frames: savedFrames,
          grabData: data.slice(stateBytes), grab: savedGrab,
        };
      } finally { staging.destroy(); }
    },
    writeState(state) {
      ensureAlive();
      if (state.vertexCount !== count || state.data?.byteLength !== count * (16 + VERTEX_BYTES)) throw new Error('布料检查点与当前网格不匹配。');
      device.queue.writeBuffer(positions, 0, state.data, 0, count * 16);
      device.queue.writeBuffer(vertexState, 0, state.data, count * 16, count * VERTEX_BYTES);
      if (state.parameters?.byteLength === parameterData.byteLength) new Uint8Array(parameterData).set(new Uint8Array(state.parameters));
      if (state.scene?.length === sceneData.length) sceneData.set(state.scene);
      if (state.grab && state.grabData?.byteLength === count * 16) {
        device.queue.writeBuffer(grabBuffer, 0, state.grabData);
        activeGrab = { ...state.grab, bary: [...state.grab.bary] };
      } else clearGrab();
      frames = state.frames || 0;
      device.queue.writeBuffer(sceneBuffer, 0, sceneData);
      uploadUniform();
      const commands = begin('Restore GPU cloth checkpoint');
      volume(commands.pass);
      dispatch(commands.pass, 'updateNormals');
      end(commands);
    },
    async pick(origin, direction) {
      ensureAlive();
      const length = Math.hypot(...direction);
      if (!length || origin.length !== 3 || direction.length !== 3) return null;
      const ray = direction.map(value => value / length);
      pf.set([...origin, 0], 40);
      pf.set([...ray, 0], 44);
      uploadUniform();
      const commands = begin('Pick current GPU cloth surface');
      dispatch(commands.pass, 'pickPartial', groups(triangleCount));
      dispatch(commands.pass, 'pickFinish', 1);
      end(commands);
      const result = await readBuffer(scratchBuffer, 16, 16);
      const f = new Float32Array(result), u = new Uint32Array(result);
      if (u[1] === 0xffffffff || f[0] >= 1e29) return null;
      return {
        triangle: u[1], bary: [1 - f[2] - f[3], f[2], f[3]], distance: f[0],
        position: origin.map((value, i) => value + ray[i] * f[0]),
      };
    },
    async diagnostics({ clearOverflow = false } = {}) {
      ensureAlive();
      const commands = begin('Measure GPU cloth diagnostics');
      volume(commands.pass);
      dispatch(commands.pass, 'diagnosticSummary', 1);
      end(commands);
      const readback = readBuffer(scratchBuffer, 0, 60);
      if (clearOverflow) {
        device.queue.writeBuffer(scratchBuffer, 12, new Uint32Array([0]));
        device.queue.writeBuffer(scratchBuffer, 56, new Uint32Array([0]));
      }
      const raw = await readback;
      const f = new Float32Array(raw), u = new Uint32Array(raw);
      return {
        volume: f[0], restVolume: prepared.restVolume, volumeRatio: f[0] / Math.max(prepared.restVolume, 1e-10),
        minY: f[8], maxSpeed: f[9], finite: u[10] === count, seamGap: f[11], maxSeamGap: f[12], poseRms: f[13],
        pressureEnabled: pf[15] > 0.999 && pf[14] > 0.001 && pf[22] > 0.001 && f[12] < pf[20] * 2,
        hashOverflow: u[3], hashCapacity: count, hashBuckets, hashMaxBucketOccupancy: u[14],
        hashOverflowMeaning: 'Unprocessed candidates from an invalid linked list; zero means every candidate was traversed',
        hashStorage: 'Atomic linked lists with one entry per particle; no per-bucket truncation',
        hashScratchBytes: surfaceBoundsOffset * 4,
        surfaceScratchBytes: (scratchWords - surfaceBoundsOffset) * 4, surfaceBvhNodes: prepared.surfaceNodeCount,
        velocityLimit: Math.min(10, Math.max(2 * pf[20], 0.001) / pf[12]),
        selfCollision: solver.selfCollisionMethod, selfCollisionLimitations: solver.selfCollisionLimitations, quality: lastQuality,
        vertexCount: count, triangleCount, constraintCount, frames,
        grabAffectedVertices: solver.grabPatchCount, grabRadius: activeGrab?.radius ?? 0,
        seamCount: prepared.seamCount, boundaryEdges: prepared.boundaryEdges,
        nonManifoldEdges: prepared.nonManifoldEdges,
      };
    },
    destroy() {
      if (destroyed) return;
      destroyed = true;
      ownedBuffers.forEach(item => item.destroy());
    },
  };
  solver.reset();
  return solver;
}
