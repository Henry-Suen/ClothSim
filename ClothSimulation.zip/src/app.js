import { initializeGPU } from './gpu.js';
import { generateHumanoid, BODY_PRESETS, DENSITIES, validateMesh, normalizeBodyWeights } from './geometry.js';
import { StudioEditor, jointLabel } from './editor.js';
import { evaluateRig, createPosePreset, skinCPU } from './rig.js';
import { createSolver } from './solver.js';
import { createRenderer, createCamera, orbitCamera, panCamera, zoomCamera, cameraRay, projectPoint } from './renderer.js';
import { clamp, insertKey, sampleCamera, samplePose, samplePoseTransform, migrateLegacyClips, validatePoseLibrary, samplePhase, sampleGrab, defaultTimeline, cacheBytes, validateTimeline, grabReference, remapGrab } from './timeline.js';
import { createRagdoll, stepRagdoll, evaluateRagdoll, captureRagdollFrame } from './ragdoll.js';
import { createObject, expandColliders, rayColliderDistance, COLLIDER_KINDS } from './colliders.js';

const $ = id => document.getElementById(id);
const copy = x => structuredClone(x);
const nextPaint = () => new Promise(resolve => requestAnimationFrame(resolve));
const CACHE_LIMIT = 512 * 1024 * 1024;
const MATERIALS = {
  cloth: { name: '棉布薄壳', description: '柔软褶皱，低拉伸。', stretch: 1e-7, bend: 1e-4, damping: 1.5, friction: .5, thickness: .004, mass: .25, pressure: 1 },
  rubber: { name: '柔软橡胶', description: '富有弹性的表面，柔和恢复。', stretch: 2e-5, bend: 2e-5, damping: 2.5, friction: .75, thickness: .005, mass: .6, pressure: .9 },
  balloon: { name: '气球薄膜', description: '轻薄表面，由内部压力驱动。', stretch: 8e-6, bend: 8e-4, damping: 1, friction: .35, thickness: .002, mass: .12, pressure: 1.2 },
};
const PHASE_LABELS = { Posed:'保持姿势', Deflated:'已放气', Releasing:'正在释放', 'Closing seam':'正在闭合接缝', 'Inflating · assisted':'充气中 · 骨架辅助', Recovered:'已恢复' };
const COLLIDER_LABELS = { chair:'椅子', sofa:'沙发', box:'方块', sphere:'球体', capsule:'胶囊体' };
const MATERIAL_LABELS = { stretch:'拉伸柔度', bend:'弯曲柔度', damping:'阻尼', friction:'摩擦系数', thickness:'碰撞厚度', mass:'面密度', pressure:'充气强度' };

class Studio {
  constructor() {
    this.mesh = null; this.solver = null; this.renderer = null;
    this.preset = 'regular'; this.bodyWeights = normalizeBodyWeights(null, this.preset); this.density = 0; this.previewDensity = 0; this.bakeDensity = 0; this.bakeCountCache = null; this.seam = false; this.spawnHeight = .12;
    this.authorRoot = { position:[0,0,0], rotation:[0,0,0] }; this.jointOffsets = {};
    this.materialName = 'rubber'; this.material = { ...MATERIALS.rubber };
    this.appearance = { skin: '#c79a7d', eyes: '#506d65', lips: '#9f6060', boxers: '#315f64', beard: false, hair: false, roughness: .7, pattern: 'plain', scalpHair:true, hairColor:'#30241e', eyesClosed:true, clothing:'tshirt', topColor:'#547d86', bottomColor:'#315f64', interior:'#571d25', seam:'#92989c', faceShading:'pixel' };
    this.showGround=true;this.sceneName='未命名场景';this.gravityEnabled=true;this.gravity=-9.81;
    this.phaseSettings={releaseBinding:.02,releaseDuration:.3,inflateBinding:1,inflateDuration:3};
    this.ragdollEnabled=false;this.autoRagdoll=true;this.ragdoll=null;this.ragdollLocks=new Set();this.lastAutoRagdoll=null;this.generalMode='camera';this.sceneColliders=null;
    this.camera = createCamera(); this.homeCamera = copy(this.camera); this.cameraOverride = false;
    this.pose = createPosePreset(null,'stand').value; this.initialPosePending=true; this.customPoses=[];
    this.timeline = defaultTimeline(); this.bakeDuration=this.timeline.duration; this.objects = []; this.objectId = 1; this.selectedObject = null;
    this.time = 0; this.playing = false; this.busy = false; this.baking = false; this.cancel = false;
    this.cache = null; this.cachedMode = false; this.checkpoints = []; this.checkpointPending = false;
    this.root = [0,this.spawnHeight,0]; this.lastRecovery = null; this.lastPhase = null;
    this.grab = null; this.grabRecord = null; this.pointer = null; this.pickToken = 0;
    this.wireframe = false; this.showRig = false; this.rig = null; this.selectedKey = null;
    this.errors = []; this.fps = 0; this.frameCount = 0; this.framesRendered = 0; this.lastRecord = -1;
    this.last = performance.now(); this.accumulator = 0; this.liveRevision = 0;
    this.installUI();
    this.editor = new StudioEditor(this);
  }

  status(message, error = false) {
    $('statusText').textContent = message;
    $('statusText').style.color = error ? '#e4a28d' : '';
  }

  async initialize() {
    const gpu = await initializeGPU(message => this.fatal(message));
    this.gpu = gpu;
    const descriptor = gpu.info.description || [gpu.info.vendor, gpu.info.architecture].filter(Boolean).join(' ');
    $('gpuLabel').textContent = descriptor.toUpperCase() || 'WebGPU 已连接';
    $('gpuLabel').title = JSON.stringify(gpu.info);
    this.renderer = await createRenderer(gpu.device, $('viewport'), gpu.format);
    await this.rebuild();
    this.ready = true;
    this.status('已就绪。播放序列，或释放薄壳后使用抓取工具提起。');
    this.last = performance.now();
    requestAnimationFrame(t => this.animate(t));
  }

  fatal(message) {
    this.failed=true;
    this.errors.push(String(message));
    console.error(message);
    this.playing = false;
    this.cancel = true;
    this.status(String(message), true);
    $('startup').hidden = false;
    $('startupTitle').textContent = 'GPU 需要检查';
    $('startupText').textContent = String(message);
    $('retryButton').hidden = false;
    document.querySelector('.loading-orbit').style.animation = 'none';
  }

  async rebuild(density = this.previewDensity, message = '网格拓扑已重建，物理缓存已清除。') {
    this.busy = true; this.playing = false; this.releaseGrab();
    this.density = density;
    $('startup').hidden = false; $('startupTitle').textContent = '正在构建人体模型';
    $('startupText').textContent = '正在生成连通拓扑、骨架权重与 GPU 约束。';
    await nextPaint();
    const mesh = generateHumanoid({ preset: this.preset, bodyWeights: this.bodyWeights, density, seam: this.seam });
    const validation = validateMesh(mesh);
    if (validation.valid === false) throw new Error(`人体网格拓扑无效：${(validation.errors || []).join('；')}`);
    const solver = await createSolver(this.gpu.device, mesh);
    const previous = this.solver;
    for (const event of this.timeline.grabs) {
      event.reference ||= grabReference(event.triangle,event.bary,this.mesh?.metadata.density ?? this.density);
      const mapped = remapGrab(event.reference,this.density);
      if(mapped.triangle>=mesh.triangleCount)throw new Error('无法将已记录的抓取映射到当前网格。');
      event.triangle=mapped.triangle;event.bary=mapped.bary;
    }
    this.mesh = mesh; this.solver = solver;
    if(this.initialPosePending){const frame=createPosePreset(mesh,'stand');this.pose=frame.value;this.authorRoot=frame.root;this.initialPosePending=false;}
    this.renderer.setMesh(mesh, solver);
    previous?.destroy();
    $('vertexCount').textContent = mesh.vertexCount.toLocaleString();
    $('triangleCount').textContent = `${mesh.triangleCount.toLocaleString()} 个三角形`;
    $('bodyLabel').textContent = Object.values(this.bodyWeights).filter(v=>v>.001).length>1?'混合体型':BODY_PRESETS.find(x => this.bodyWeights[x.id]>.999)?.label??'混合体型';
    $('joint').replaceChildren(...mesh.bones.map(b => new Option(jointLabel(b.name), b.name)));
    $('density').value=this.previewDensity;
    this.editor?.syncTransformInputs();this.syncPoseInputs();
    this.invalidate(message);
    await this.reset(false);
    this.busy = false;
    $('startup').hidden = true;
    this.updateBakeSummary(); this.draw();this.startPendingBake();
  }

  phaseAt(time){return samplePhase(this.timeline.phases,time,this.seam,this.phaseSettings);}

  /** True once a release event has been reached: the cloth already has simulation results. */
  releasedAt(time){
    return this.timeline.phases.some(event=>event.type==='release'&&event.time<=time+1e-6);
  }

  /** Scene colliders are rebuilt only when the scene changes, not on every substep. */
  colliderList(){
    if(!this.sceneColliders)this.sceneColliders=expandColliders(this.objects);
    return this.sceneColliders;
  }

  inputsAt(time, quality = 'preview') {
    const phase = samplePhase(this.timeline.phases, time, this.seam,this.phaseSettings);
    const pose = samplePose(this.timeline.poseKeys, time, this.pose);
    const transform = samplePoseTransform(this.timeline.poseKeys,time,this.authorRoot,this.jointOffsets);
    this.rig = evaluateRig(this.mesh, { pose, root: this.root.map((v,i)=>v+transform.root.position[i]), rootRotation:transform.root.rotation, jointOffsets:transform.offsets });
    this.lastPhase = phase;
    return { boneMatrices: this.rig.matrices, binding: phase.binding, inflation: phase.inflation,
      seam: phase.seam, material: this.material, colliders: this.colliderList(), quality, gravityEnabled:this.gravityEnabled, gravity:this.gravity,
      grab: this.grab || sampleGrab(this.timeline.grabs, time) };
  }

  async prepareRecovery(time) {
    const phase = samplePhase(this.timeline.phases,time,this.seam,this.phaseSettings);
    if (phase.event?.type !== 'inflate' || this.lastRecovery === phase.event.time) return;
    const xyz = await this.solver.readPositions();
    let x=0,z=0,count=0,minRestY=Infinity;
    for(let i=0;i<this.mesh.vertexCount;i++) {
      const y=this.mesh.positions[i*4+1];minRestY=Math.min(minRestY,y);
      if(y>.78 && y<1.15 && Math.abs(this.mesh.positions[i*4])<.24){x+=xyz[i*3];z+=xyz[i*3+2];count++;}
    }
    if(count && Number.isFinite(x+z+minRestY)){
      const frame=samplePoseTransform(this.timeline.poseKeys,time,this.authorRoot,this.jointOffsets);
      const rig=evaluateRig(this.mesh,{pose:samplePose(this.timeline.poseKeys,time,this.pose),rootRotation:frame.root.rotation,jointOffsets:frame.offsets});
      const target=skinCPU(this.mesh,rig.matrices);let tx=0,tz=0,n=0;minRestY=Infinity;
      for(let i=0;i<this.mesh.vertexCount;i++){
        minRestY=Math.min(minRestY,target[i*4+1]);const y=this.mesh.positions[i*4+1];
        if(y>.78&&y<1.15&&Math.abs(this.mesh.positions[i*4])<.24){tx+=target[i*4];tz+=target[i*4+2];n++;}
      }
      this.root=[x/count-tx/Math.max(1,n),this.material.thickness-minRestY,z/count-tz/Math.max(1,n)].map((v,i)=>v-frame.root.position[i]);
    }
    this.lastRecovery=phase.event.time;
  }

  async stepFixed(dt = 1/60, quality = 'preview') {
    const target = Math.min(this.timeline.duration, this.time + dt);
    if(target <= this.time + 1e-8) return;
    await this.prepareRecovery(target);
    const inputs=this.inputsAt(target,quality),phase=this.phaseAt(target);
    if(this.autoRagdoll&&phase.event?.type==='release'&&this.lastAutoRagdoll!==phase.event.time){this.setRagdoll(true);this.lastAutoRagdoll=phase.event.time;}
    const matrices=this.stepRagdollPhysics(target,target-this.time);if(matrices)inputs.boneMatrices=matrices;
    this.solver.step(target-this.time,inputs);
    this.time=target;
    if($('recordCamera').checked && quality==='preview' && this.time-this.lastRecord>=.1){
      insertKey(this.timeline.cameraKeys,{time:this.time,value:copy(this.camera)});this.lastRecord=this.time;
    }
    if(this.grabRecord && this.grab) insertKey(this.grabRecord.samples,{time:this.time,value:[...this.grab.target]});
  }

  async reset(clearCache = false) {
    this.playing=false; this.releaseGrab(); this.time=0; this.accumulator=0; this.liveRevision++;
    this.root=[0,this.spawnHeight,0]; this.lastRecovery=null; this.lastDiagnostic=null;this.lastAutoRagdoll=null;
    this.inputsAt(0);if(this.ragdollEnabled)this.ragdoll=createRagdoll(this.mesh,this.rig,{fixed:this.ragdollLocks});else this.ragdoll=null;
    this.cachedMode=false; this.checkpoints=[];
    if(clearCache)this.invalidate('物理模拟已重置。');
    if(this.solver){
      this.solver.reset({boneMatrices:this.inputsAt(0).boneMatrices});
      if(this.solver.readState) this.checkpoints.push({time:0,root:[...this.root],lastRecovery:null,lastAutoRagdoll:null,ragdollEnabled:this.ragdollEnabled,ragdoll:this.ragdoll?structuredClone(this.ragdoll):null,state:await this.solver.readState()});
    }
    this.refreshTimeline(); this.updateTransport();
    $('resumeLive').hidden=true;
  }

  invalidate(message) {
    this.cache=null;this.cachedMode=false;this.checkpoints=[];this.liveRevision++;this.sceneColliders=null;
    $('bakeProgress').value=0;$('bakeStatus').textContent='暂无有效缓存。完成场景编辑后请重新烘焙。';
    $('cacheBadge').textContent='实时 · 未缓存';$('viewMode').textContent='实时预览';$('resumeLive').hidden=true;
    $('bakeRange').hidden=true;document.querySelectorAll('.track').forEach(el=>el.classList.remove('has-cache'));
    if(message)this.status(message);
  }

  async physicsChanged(message='物理设置已更改，已按当前时间轴重新开始模拟。') {
    if(this.busy)return;
    if(this.density!==this.previewDensity){await this.rebuild(this.previewDensity,message);return;}
    this.invalidate(message);this.busy=true;
    try{await this.reset();this.draw();}finally{this.busy=false;this.startPendingBake();}
  }

  startPendingBake(){
    if(!this.pendingBake||this.busy||this.cancel)return;
    const {calibration,options}=this.pendingBake;this.pendingBake=null;
    this.bake(calibration,options);
  }

  draw() {
    if(!this.renderer || !this.solver)return;
    if(this.timeline.cameraKeys.length && !this.cameraOverride && !$('recordCamera').checked) this.camera=sampleCamera(this.timeline.cameraKeys,this.time,this.homeCamera);
    this.renderer.render({camera:this.camera,appearance:{...this.appearance,seamOpen:this.seam?this.phaseAt(this.time).seam:0},showGround:this.showGround,ragdollShapes:this.ragdollEnabled&&this.editor?.tool==='pose'?this.ragdoll?.colliders:null,colliders:this.colliderList(),wireframe:this.wireframe,rigJoints:this.showRig?this.rig?.joints:null,grab:this.grab});
    this.framesRendered++;
    this.updateOverlay();this.updateTransport();this.editor?.drawGizmo();
  }

  updateOverlay() {
    const phase=samplePhase(this.timeline.phases,this.time,this.seam,this.phaseSettings);
    const diagnostic=this.lastDiagnostic;
    const recent=diagnostic && Math.abs(diagnostic.time-this.time)<1.5 && !this.cachedMode;
    const blocked=recent && phase.binding===1 && (diagnostic.poseRms>.04 || diagnostic.maxSeamGap>this.material.thickness*2);
    $('phaseLabel').textContent=blocked?'姿势恢复受阻':recent && phase.inflation>.01 && !diagnostic.pressureEnabled?'等待接缝闭合':PHASE_LABELS[phase.phase];
    $('bindingValue').textContent=Math.round(phase.binding*100);
    $('airValue').textContent=Math.round(phase.inflation*100);
    $('timeBadge').textContent=`${this.time.toFixed(2)} 秒`;
    if(this.frameCount%15===0&&this.generalMode==='camera'&&!$('generalPanel').hidden)this.updateCameraReadout();
    const canvas=$('viewport'), w=canvas.clientWidth,h=canvas.clientHeight;
    if(this.grab && typeof projectPoint==='function'){
      const p=projectPoint(this.camera,this.grab.target,w,h);
      $('grabMarker').hidden=!p;if(p){$('grabMarker').style.left=`${p[0]}px`;$('grabMarker').style.top=`${p[1]}px`;}
    }else $('grabMarker').hidden=true;
    $('rigSvg').replaceChildren();
    if(this.showRig && this.rig?.joints && typeof projectPoint==='function'){
      const ns='http://www.w3.org/2000/svg';
      for(let i=0;i<this.mesh.bones.length;i++){
        const p=projectPoint(this.camera,this.rig.joints[i],w,h);
        if(!p?.every(Number.isFinite))continue;
        const parent=this.mesh.bones[i].parent;
        if(parent>=0){const q=projectPoint(this.camera,this.rig.joints[parent],w,h);if(q){const l=document.createElementNS(ns,'line');l.setAttribute('x1',q[0]);l.setAttribute('y1',q[1]);l.setAttribute('x2',p[0]);l.setAttribute('y2',p[1]);$('rigSvg').append(l);}}
        const circle=document.createElementNS(ns,'circle');circle.setAttribute('cx',p[0]);circle.setAttribute('cy',p[1]);circle.setAttribute('r',2.5);$('rigSvg').append(circle);
      }
    }
  }

  updateTransport(){
    $('playButton').textContent=this.playing?'Ⅱ':'▶';$('playButton').setAttribute('aria-label',this.playing?'暂停':'播放');
    const minutes=Math.floor(this.time/60),seconds=this.time%60;
    $('timecode').textContent=`${String(minutes).padStart(2,'0')}:${seconds.toFixed(2).padStart(5,'0')}`;
    if(!this.editor?.scrubbing){$('scrubber').value=this.time;$('playhead').style.left=`${this.time/this.timeline.duration*100}%`;}
    $('scrubber').max=this.timeline.duration;
    $('durationLabel').textContent=this.timeline.duration.toFixed(2);
  }

  async animate(now) {
    if(this.failed)return;
    const elapsed=Math.min(.1,Math.max(0,(now-this.last)/1000));this.last=now;
    try{
      this.editor?.tick(elapsed);
      if(!this.busy && this.playing){
        this.accumulator=Math.min(this.accumulator+elapsed,.1);
        if(this.cachedMode && this.cache){
          this.time=Math.min(this.time+elapsed,this.cache.frames.length/this.cache.fps-1/this.cache.fps);
          const index=clamp(Math.round(this.time*this.cache.fps),0,this.cache.frames.length-1);
          this.solver.writePositions(this.cache.frames[index]);
          if(this.cache.boneFrames?.[index]){this.rig=this.currentRig();this.rig.matrices=this.cache.boneFrames[index];}
          this.inputsAt(this.time);
          if(index>=this.cache.frames.length-1)this.playing=false;
        } else {
          let steps=0;
          while(this.accumulator>=1/60 && steps<3){await this.stepFixed();this.accumulator-=1/60;steps++;}
          if(this.time>=this.timeline.duration-1e-6)this.playing=false;
          this.captureCheckpoint();
        }
      }
      if(!this.busy)this.draw();
      this.frameCount++;
      if(this.frameCount%15===0){
        const span=(now-(this.fpsStart??now-250))/1000;this.fps=15/Math.max(.001,span);this.fpsStart=now;
        $('fpsValue').textContent=Math.round(this.fps);
        if(!this.busy)await this.gpu.device.queue.onSubmittedWorkDone();
        if(this.frameCount%60===0 && this.playing && !this.busy && !this.cachedMode)await this.inspectSimulation();
      }
    }catch(error){this.fatal(error.message);}
    requestAnimationFrame(t=>this.animate(t));
  }

  captureCheckpoint(){
    if(this.checkpointPending || !this.solver.readState || this.time-(this.checkpoints.at(-1)?.time??-1)<1)return;
    this.checkpointPending=true;
    const revision=this.liveRevision,solver=this.solver,time=this.time,root=[...this.root],lastRecovery=this.lastRecovery,lastAutoRagdoll=this.lastAutoRagdoll,ragdollEnabled=this.ragdollEnabled,ragdoll=this.ragdoll?structuredClone(this.ragdoll):null;
    solver.readState().then(state=>{
      if(revision===this.liveRevision && solver===this.solver){this.checkpoints.push({time,root,lastRecovery,lastAutoRagdoll,ragdollEnabled,ragdoll,state});if(this.checkpoints.length>16)this.checkpoints.splice(1,1);}
    }).catch(e=>this.status(`检查点不可用：${e.message}`,true)).finally(()=>{this.checkpointPending=false;});
  }

  async inspectSimulation(){
    if(!this.solver.diagnostics)return null;
    const revision=this.liveRevision,solver=this.solver;
    const diagnostic=await solver.diagnostics();
    if(revision!==this.liveRevision || solver!==this.solver)return null;
    this.lastDiagnostic={...diagnostic,time:this.time};
    if(!diagnostic.finite)throw new Error('GPU 状态出现非有限数值。请重置模拟，或降低材质与交互强度。');
    if(diagnostic.hashOverflow>0){
      const message='自接触索引未通过验证。请重置模拟；不能使用不完整的碰撞结果。';
      this.playing=false;this.status(message,true);
      if(this.baking)throw new Error(message);
    }
    return diagnostic;
  }

  async seek(time, forceLive=false){
    if(this.busy || !this.solver)return;
    const simulate = forceLive || this.playing;
    this.playing=false;this.releaseGrab();this.busy=true;
    const target=clamp(time,0,this.timeline.duration);
    try{
      if(this.cache && !forceLive){
        const i=clamp(Math.round(target*this.cache.fps),0,this.cache.frames.length-1);
        this.time=i/this.cache.fps;this.solver.writePositions(this.cache.frames[i]);
        if(this.cache.boneFrames?.[i]){this.rig=this.currentRig();this.rig.matrices=this.cache.boneFrames[i];}this.cachedMode=true;
        $('viewMode').textContent=this.cache.complete?'烘焙回放':'部分缓存';$('resumeLive').hidden=false;
        this.inputsAt(this.time);
      }else{
        const cp=[...this.checkpoints].reverse().find(c=>c.time<=target+1e-6);
        if(cp && this.solver.writeState){this.solver.writeState(cp.state);this.time=cp.time;this.root=[...cp.root];this.lastRecovery=cp.lastRecovery;this.lastAutoRagdoll=cp.lastAutoRagdoll??null;this.ragdollEnabled=cp.ragdollEnabled??false;this.ragdoll=cp.ragdoll?structuredClone(cp.ragdoll):null;}
        else{this.time=0;this.root=[0,this.spawnHeight,0];this.lastRecovery=null;this.lastAutoRagdoll=null;this.inputsAt(0);this.ragdoll=this.ragdollEnabled?createRagdoll(this.mesh,this.rig,{fixed:this.ragdollLocks}):null;this.solver.reset({boneMatrices:this.inputsAt(0).boneMatrices});}
        $('ragdollEnabled').checked=this.ragdollEnabled;this.renderRagdollLocks();this.editor?.syncRagdollState();
        this.cachedMode=false;
        if(simulate){
          let steps=0;
          while(this.time<target-1e-6){await this.stepFixed(Math.min(1/60,target-this.time));if(++steps%30===0){this.draw();await nextPaint();}}
          this.status(`已正向重新模拟至 ${this.time.toFixed(2)} 秒。`);
        }else{
          // Paused scrubbing only moves the playhead: forward simulation is reserved for playback and baking.
          this.time=target;
          if(this.ragdollEnabled&&this.ragdoll)this.syncRagdoll();else this.inputsAt(this.time);
          this.status(`已定位到 ${this.time.toFixed(2)} 秒。暂停时不推演物理，按播放或烘焙才会继续模拟。`);
        }
        $('viewMode').textContent='实时预览';$('resumeLive').hidden=true;
      }
      this.draw();
    }finally{this.busy=false;}
  }

  leavePoseForPlayback(){
    if(this.editor.tool==='pose'){if(this.editor.gizmoDrag)this.editor.commitPose();this.editor.gizmoDrag=null;this.editor.setTool('camera');}this.setRigVisible(false);this.editor.syncModes();
  }

  setRigVisible(visible){
    this.showRig=!!visible;$('rigOverlay').setAttribute('aria-pressed',String(this.showRig));
  }

  syncRagdoll(){
    if(!this.ragdollEnabled||!this.ragdoll)return false;
    this.rig=evaluateRagdoll(this.mesh,this.ragdoll);return true;
  }
  currentRig(){return this.ragdollEnabled&&this.ragdoll?evaluateRagdoll(this.mesh,this.ragdoll):evaluateRig(this.mesh);}

  setRagdoll(enabled){
    if(this.busy||!this.mesh)return;
    enabled=!!enabled;
    if(enabled===this.ragdollEnabled){$('ragdollEnabled').checked=enabled;return;}
    if(enabled){
      this.inputsAt(this.time);this.ragdoll=createRagdoll(this.mesh,this.rig,{fixed:this.ragdollLocks});
      this.ragdollEnabled=true;this.invalidate('布娃娃已启用，主要骨骼由刚体动力学驱动。');this.playing=true;this.leavePoseForPlayback();
    }else{
      const activeEvent=this.phaseAt(this.time).event;
      this.disableRagdoll(true);this.playing=false;this.lastAutoRagdoll=activeEvent?.type==='release'?activeEvent.time:null;
      const keyed=this.timeline.poseKeys.length>0;
      this.invalidate(keyed?'已退出布娃娃：骨骼保持当前物理结果，已有姿势关键帧全部保留；如需保存该结果请点击“+ 姿势关键帧”。':'已退出布娃娃：刚体停止驱动，骨骼保持在当前物理结果上。');
      if(keyed)this.refreshPoseRig();else this.inputsAt(this.time);
    }
    $('ragdollEnabled').checked=this.ragdollEnabled;this.editor?.syncRagdollState();this.renderRagdollLocks();this.draw();
  }

  /** Stop driving the skeleton with rigid bodies; keepPose freezes the current ragdoll result in place. */
  disableRagdoll(keepPose=true){
    if(!this.ragdollEnabled)return;
    if(keepPose)this.captureRagdollPose();
    this.ragdollEnabled=false;this.ragdoll=null;$('ragdollEnabled').checked=false;
    this.renderRagdollLocks();this.editor?.syncRagdollState();
  }

  resetAfterRagdollExit(){
    this.root=[0,this.spawnHeight,0];this.lastRecovery=null;this.checkpoints=[];
    const rig=evaluateRig(this.mesh,{pose:this.pose,root:this.authorRoot.position,rootRotation:this.authorRoot.rotation,jointOffsets:this.jointOffsets});this.rig=rig;
    this.solver.reset({boneMatrices:rig.matrices});
  }

  captureRagdollPose(){
    if(!this.ragdoll)return;
    const frame=captureRagdollFrame(this.mesh,this.ragdoll);
    if(!frame)return;
    this.pose=frame.pose;this.jointOffsets=frame.offsets;this.authorRoot=frame.authorRoot;this.root=[0,0,0];
    // Existing pose keyframes are preserved: the ragdoll result becomes an unkeyed draft until recorded.
    if(this.timeline.poseKeys.length)this.editor.poseDraft=true;
    this.editor.syncTransformInputs();
  }

  /** Evaluate the authored pose directly, skipping pose keyframe sampling. */
  refreshPoseRig(){
    this.rig=evaluateRig(this.mesh,{pose:this.pose,root:this.root.map((v,i)=>v+this.authorRoot.position[i]),rootRotation:this.authorRoot.rotation,jointOffsets:this.jointOffsets});
    return this.rig;
  }

  renderRagdollLocks(){
    const container=$('ragdollLocks');if(!container)return;
    container.replaceChildren();
    if(!this.ragdollEnabled||!this.ragdoll){container.textContent='启用布娃娃后可选择固定位置的刚体。';return;}
    for(const body of this.ragdoll.bodies){const label=document.createElement('label');label.className='check-row';const input=document.createElement('input');input.type='checkbox';input.checked=this.ragdollLocks.has(body.name);input.addEventListener('change',()=>{if(input.checked)this.ragdollLocks.add(body.name);else this.ragdollLocks.delete(body.name);this.ragdoll.fixed=new Set(this.ragdoll.bodies.filter(b=>this.ragdollLocks.has(b.name)).map(b=>b.index));});const text=document.createElement('span');text.textContent=`${jointLabel(body.name)} · 仅锁位置`;label.append(input,text);container.append(label);}
  }

  stepRagdollPhysics(target,dt){
    if(this.ragdollEnabled&&this.ragdoll){stepRagdoll(this.ragdoll,dt,{gravity:this.gravity,gravityEnabled:this.gravityEnabled,colliders:this.colliderList()});this.rig=evaluateRagdoll(this.mesh,this.ragdoll);}
    return this.rig?.matrices;
  }

  async togglePlay(){
    if(this.busy)return;
    if(!this.playing && this.time>=this.timeline.duration-.001){if(this.cache)await this.seek(0);else await this.reset();}
    this.playing=!this.playing;
    if(this.playing)this.leavePoseForPlayback();this.cameraOverride=false;this.accumulator=0;this.last=performance.now();this.updateTransport();
  }

  async setPhase(type){
    if(this.busy)return;
    if(this.cachedMode)await this.seek(this.time,true);
    if(this.density!==this.previewDensity)await this.rebuild(this.previewDensity,'已回到实时预览精度。');
    this.invalidate();
    insertKey(this.timeline.phases,{time:this.time,type,duration:this.phaseSettings[type+'Duration'],target:this.phaseSettings[type+'Binding']});
    if(type==='inflate'&&this.ragdollEnabled)this.setRagdoll(false);
    if(type==='release')this.lastAutoRagdoll=null;else this.lastAutoRagdoll=this.time;
    this.refreshTimeline();this.leavePoseForPlayback();this.playing=true;this.status(type==='release'?'正在解除骨架约束，并释放薄壳内的空气。':'正在闭合接缝，随后在碰撞约束与骨架辅助下充气。');
  }

  async bake(calibration=false,options={}){
    if(this.busy){
      if(this.baking)return null;
      this.pendingBake={calibration,options};this.cancel=false;$('cancelBake').hidden=false;
      this.status('正在完成物理重置，随后自动开始烘焙。可点击取消。');return {pending:true,complete:false};
    }
    this.releaseGrab();this.playing=false;
    const duration=options.duration??(calibration?Math.min(2,this.bakeDuration):Math.min(this.bakeDuration,this.timeline.duration)),fps=this.timeline.fps;
    const bakeDensity=this.bakeDensity;
    const bakeCount=this.bakeVertexCount()||this.mesh.vertexCount;
    const bytes=cacheBytes(bakeCount,duration,fps)+(this.ragdollEnabled?Math.round(duration*fps+1)*(this.mesh.bones?.length??0)*64:0);
    if(bytes>CACHE_LIMIT*.9){this.status(`缓存需要 ${(bytes/1048576).toFixed(0)} MiB，另需工作缓冲区。请降低烘焙网格精度或缩短片段（上限为 512 MiB）。`,true);return null;}
    if(this.density!==bakeDensity){
      try{await this.rebuild(bakeDensity,`已切换到烘焙网格精度（${DENSITIES.find(d=>d.id===bakeDensity)?.label??bakeDensity}），正在烘焙。`);}
      catch(error){this.status(`烘焙失败：${error.message}`,true);return {complete:false,error:error.message};}
    }
    this.busy=true;this.baking=true;this.cancel=false;this.setEditingDisabled(true);
    $('cancelBake').hidden=false;$('bakeButton').hidden=true;$('bakeProgress').value=0;
    const started=performance.now(),deadline=started+(options.deadlineMs??295000);
    const frames=[],boneFrames=[],total=Math.round(duration*fps)+1;let complete=false;
    const snapshotBones=(target=boneFrames)=>{if(this.ragdollEnabled)target.push(new Float32Array(this.rig.matrices));};
    try{
      await this.reset(false);
      frames.push(await this.solver.readPositions());snapshotBones();
      let i=1;
      while(i<total && !this.cancel && performance.now()<deadline){
        const pending=[],pendingBones=[];
        for(let batch=0;batch<3 && i<total && !this.cancel && performance.now()<deadline;batch++,i++){
          const target=i/fps;
          while(this.time<target-1e-7)await this.stepFixed(Math.min(1/60,target-this.time),'bake');
          pending.push(this.solver.readPositions());snapshotBones(pendingBones);
        }
        const chunks=await Promise.all(pending);
        for(const xyz of chunks){if(!xyz.every(Number.isFinite))throw new Error('模拟位置出现非有限数值，烘焙已停止。');frames.push(xyz);boneFrames.push(...pendingBones);}
        if(frames.length%30<3 || i>=total)await this.inspectSimulation();
        $('bakeProgress').value=frames.length/total;
        const elapsed=(performance.now()-started)/1000;
        $('bakeStatus').textContent=`${calibration?'校准中':'烘焙中'} ${frames.length} / ${total} 帧 · ${elapsed.toFixed(1)} 秒 · ${Math.round(frames.length/total*100)}%`;
        this.draw();await nextPaint();
      }
      complete=frames.length===total;
      const elapsed=(performance.now()-started)/1000;
      if(calibration){
        const estimate=elapsed*Math.min(this.bakeDuration,this.timeline.duration)/duration;
        $('bakeEstimate').textContent=`约 ${estimate.toFixed(0)} 秒*`;
        $('bakeEstimate').title='根据两秒样本推算；密集接触与姿势恢复可能耗时更长。';
        this.status(`校准用时 ${elapsed.toFixed(2)} 秒。完整烘焙预计约 ${estimate.toFixed(0)} 秒；折叠接触可能耗时更长。`);
        await this.reset(false);
      }else{
        this.cache={frames,boneFrames,fps,complete,duration:(frames.length-1)/fps,elapsed,vertexCount:this.mesh.vertexCount,density:this.density};
        this.cachedMode=true;this.time=0;this.solver.writePositions(frames[0]);this.inputsAt(0);
        $('resumeLive').hidden=false;
        $('cacheBadge').textContent=`${complete?'已烘焙':'部分缓存'} · ${frames.length} 帧 · ${DENSITIES.find(d=>d.id===this.density)?.label??this.density}`;
        $('viewMode').textContent=complete?'烘焙回放':'部分缓存';
        $('bakeStatus').textContent=`${complete?'已完成':this.cancel?'已取消 · 部分缓存':'已达时限 · 部分缓存'}：${frames.length}/${total} 帧，烘焙精度 ${DENSITIES.find(d=>d.id===this.density)?.label??this.density}，用时 ${elapsed.toFixed(1)} 秒，占用 ${(frames.length*this.mesh.vertexCount*12/1048576).toFixed(1)} MiB。`;
        this.status(`${$('bakeStatus').textContent}恢复实时模拟会回到实时预览精度。`);this.refreshTimeline();
      }
      return {complete,frames:frames.length,total,elapsed,bytes:frames.length*this.mesh.vertexCount*12,density:this.density};
    }catch(error){this.status(`烘焙失败：${error.message}`,true);$('bakeStatus').textContent=`失败：${error.message}`;this.errors.push(error.message);return {complete:false,error:error.message};}
    finally{
      this.busy=false;this.baking=false;this.setEditingDisabled(false);$('cancelBake').hidden=true;$('bakeButton').hidden=false;this.draw();
    }
  }

  setEditingDisabled(disabled){
    document.querySelectorAll('aside input,aside select,aside button,.header-actions button,.transport button,.timeline input,.timeline button,.viewport-actions button').forEach(el=>{el.disabled=disabled;});
    $('cancelBake').disabled=false;$('helpButton').disabled=false;
    if(!disabled)$('deleteKey').disabled=!this.editor.selection.size;
  }

  /** Vertex count of the bake mesh, measured without replacing the live preview mesh. */
  bakeVertexCount(){
    if(this.density===this.bakeDensity&&this.mesh)return this.mesh.vertexCount;
    const key=`${this.preset}|${this.bakeDensity}|${this.seam}|${BODY_PRESETS.map(p=>this.bodyWeights[p.id]??0).join(',')}`;
    if(this.bakeCountCache?.key!==key){
      try{this.bakeCountCache={key,count:generateHumanoid({preset:this.preset,bodyWeights:this.bodyWeights,density:this.bakeDensity,seam:this.seam}).vertexCount};}
      catch{return this.mesh?.vertexCount??0;}
    }
    return this.bakeCountCache.count;
  }

  updateBakeSummary(){
    const t=this.timeline,d=Math.min(this.bakeDuration,t.duration);$('bakeFrames').textContent=Math.round(d*t.fps)+1;
    const count=this.bakeVertexCount();
    if(count)$('bakeMemory').textContent=`${(cacheBytes(count,d,t.fps)/1048576).toFixed(1)} MiB`;
    $('bakeDensity').value=this.bakeDensity;
    $('duration').value=t.duration;$('bakeDuration').value=this.bakeDuration;$('cacheFps').value=t.fps;$('scrubber').step=1/t.fps;
    $('bakeButton').textContent=`烘焙 ${Math.min(d,t.duration).toFixed(1)} 秒`;
    this.updateTransport();
  }

  panel(id){
    document.querySelectorAll('.inspector-panel').forEach(el=>el.hidden=el.id!==id);
    document.querySelectorAll('[data-panel]').forEach(el=>{const selected=el.dataset.panel===id;el.classList.toggle('selected',selected);el.setAttribute('aria-selected',selected);});
  }

  /** The general tab is contextual: the camera tool exposes camera settings, grab exposes grab settings. */
  showGeneral(mode,reveal=false){
    const next=mode==='grab'?'grab':'camera';
    if(this.generalMode!==next){
      this.generalMode=next;
      $('generalGrab').hidden=next!=='grab';
      $('generalCamera').hidden=next==='grab';
    }
    if(next==='camera')this.updateCameraReadout();
    if(reveal&&$('generalPanel').hidden)this.panel('generalPanel');
  }

  updateCameraReadout(){
    if(!this.camera)return;
    const c=this.camera,yaw=((c.yaw*180/Math.PI+540)%360)-180;
    $('cameraReadout').textContent=`距离 ${c.distance.toFixed(2)} 米 · 方位 ${Math.round(yaw)}° · 俯仰 ${Math.round(c.pitch*180/Math.PI)}° · 目标 ${c.target.map(v=>v.toFixed(2)).join(' / ')}`;
  }

  refreshTimeline(){
    if(this.editor)this.editor.renderTimeline();else this.updateBakeSummary();
  }

  deleteSelected(){return this.editor.removeSelected();}

  frameSubject(){
    this.camera=createCamera();
    const p=this.rig?.joints?.[0];
    if(p){this.camera.target[0]=p[0];this.camera.target[2]=p[2];}
    this.homeCamera=copy(this.camera);this.cameraOverride=true;$('fov').value=this.camera.fov;
  }

  handleWheel(event){
    event.preventDefault();if(this.busy)return;
    if(event.shiftKey&&this.grab&&this.pointer){
      const amount=clamp(event.deltaY*.001,-.15,.15);
      this.pointer.planePoint=this.pointer.planePoint.map((v,i)=>v+this.pointer.normal[i]*amount);
      this.grab.target=this.grab.target.map((v,i)=>v+this.pointer.normal[i]*amount);
    }else{zoomCamera(this.camera,event.deltaY);this.cameraOverride=true;if(this.editor.tool==='camera')this.showGeneral('camera');}
  }

  syncPoseInputs(){
    const p=this.pose[$('joint').value]||[0,0,0];
    ['X','Y','Z'].forEach((axis,i)=>{$(`pose${axis}`).value=p[i];$(`pose${axis}Value`).textContent=`${Math.round(p[i])}°`;});
  }

  updateMaterialUI(){
    const m=this.material;
    const values={thickness:m.thickness*1000,mass:m.mass*1000,stretch:Math.log10(m.stretch),bend:Math.log10(m.bend),damping:m.damping,friction:m.friction,pressure:m.pressure};
    for(const [id,value]of Object.entries(values))$(id).value=value;
    $('thicknessValue').textContent=`${(m.thickness*1000).toFixed(1)} 毫米`;$('massValue').textContent=`${Math.round(m.mass*1000)} 克/平方米`;
    $('stretchValue').textContent=m.stretch.toExponential(1);$('bendValue').textContent=m.bend.toExponential(1);
    for(const id of ['damping','friction','pressure'])$(`${id}Value`).textContent=m[id].toFixed(2);
    $('materialName').textContent=MATERIALS[this.materialName].name;$('materialDescription').textContent=MATERIALS[this.materialName].description;
    $('materialLabel').textContent=MATERIALS[this.materialName].name.toUpperCase();
    document.querySelectorAll('[data-material]').forEach(el=>el.classList.toggle('selected',el.dataset.material===this.materialName));
  }

  renderObjects(){
    $('objectList').replaceChildren();
    if(!this.objects.length){const span=document.createElement('span');span.className='empty-note';span.textContent='添加家具或基础几何体。';$('objectList').append(span);}
    for(const object of this.objects){const row=document.createElement('button');row.className=`object-row full-width ${object.id===this.selectedObject?'selected':''}`;const title=document.createElement('span');title.textContent=`${COLLIDER_LABELS[object.kind]} ${object.id}`;const type=document.createElement('span');type.className='object-type';type.textContent='碰撞体';row.append(title,type);row.addEventListener('click',()=>{this.selectedObject=object.id;this.renderObjects();});$('objectList').append(row);}
    const selected=this.objects.find(o=>o.id===this.selectedObject);$('objectEditor').hidden=!selected;
    if(selected){['X','Y','Z'].forEach((a,i)=>$(`object${a}`).value=selected.position[i]);$('objectYaw').value=selected.rotation;$('objectScale').value=selected.scale;}
  }

  async pointerDown(event){
    if(this.busy || !this.solver)return;
    event.preventDefault();const canvas=$('viewport');canvas.focus();canvas.setPointerCapture(event.pointerId);
    const pointer={id:event.pointerId,button:event.button,x:event.clientX,y:event.clientY,mode:event.button===1?'pan':'orbit'};this.pointer=pointer;
    if(pointer.mode==='orbit'&&event.button===0&&this.editor.tool==='camera')this.showGeneral('camera',true);
    if(event.button!==0 || this.editor.tool!=='grab')return;
    pointer.mode='none';
    if(this.cachedMode){this.status('缓存回放不可抓取，请先恢复实时模拟。');return;}
    const rect=canvas.getBoundingClientRect(),ray=cameraRay(this.camera,event.clientX-rect.left,event.clientY-rect.top,rect.width,rect.height);
    const token=++this.pickToken;pointer.mode='picking';
    try{
      const hit=await this.solver.pick(ray.origin,ray.direction);
      if(token!==this.pickToken||this.pointer!==pointer)return;
      if(!hit || hit.distance>rayColliderDistance(ray.origin,ray.direction,this.colliderList())+.005){pointer.mode='none';return;}
      this.invalidate();
      this.grab={id:crypto.randomUUID(),triangle:hit.triangle,bary:[...hit.bary],target:[...hit.position],strength:Number($('grabStrength').value),radius:Number($('grabRadius').value)};
      pointer.mode='grab';pointer.depth=hit.distance;
      pointer.normal=[...ray.direction];pointer.planePoint=[...hit.position];
      this.grabRecord={id:this.grab.id,start:this.time,end:this.time,triangle:hit.triangle,bary:[...hit.bary],reference:grabReference(hit.triangle,hit.bary,this.density),strength:this.grab.strength,radius:this.grab.radius,samples:[{time:this.time,value:[...hit.position]}]};
      this.timeline.grabs.push(this.grabRecord);
      if(!this.releasedAt(this.time)&&this.gravityEnabled){this.gravityEnabled=false;this.syncGravityUI();this.toast('已自动关闭重力：释放前布料贴合骨架，柔性抓取从静止状态开始。松开鼠标后，可用视口上方的“重力”按钮重新开启。');}
      this.playing=true;this.setRigVisible(false);this.status('正在抓取薄壳。Shift + 滚轮调整深度，松开鼠标即可放下。');
    }catch(e){pointer.mode='orbit';this.status(`拾取失败：${e.message}`,true);}
  }

  pointerMove(event){
    const p=this.pointer;if(!p||event.pointerId!==p.id||this.busy)return;
    const dx=event.clientX-p.x,dy=event.clientY-p.y;p.x=event.clientX;p.y=event.clientY;
    if(p.mode==='grab' && this.grab){
      const r=$('viewport').getBoundingClientRect(),ray=cameraRay(this.camera,event.clientX-r.left,event.clientY-r.top,r.width,r.height);
      const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0),den=dot(ray.direction,p.normal);
      if(Math.abs(den)>.001){const diff=p.planePoint.map((v,i)=>v-ray.origin[i]),t=clamp(dot(diff,p.normal)/den,.15,15);const target=ray.origin.map((v,i)=>v+ray.direction[i]*t);this.grab.target=target.map(v=>clamp(v,-8,8));}
    }else if(p.mode==='orbit'){orbitCamera(this.camera,dx,dy);this.cameraOverride=true;}
    else if(p.mode==='pan'){panCamera(this.camera,dx,dy,$('viewport').clientHeight);this.cameraOverride=true;}
  }

  releaseGrab(){
    this.pickToken++;
    if(this.grabRecord){this.grabRecord.end=Math.max(this.time,this.grabRecord.start+1/60);if(this.grab)insertKey(this.grabRecord.samples,{time:this.time,value:[...this.grab.target]});this.grabRecord=null;this.refreshTimeline();}
    this.grab=null;this.pointer=null;$('grabMarker').hidden=true;
  }

  sceneData(){return{format:'membrane-scene',version:4,sceneName:this.sceneName,showGround:this.showGround,gravityEnabled:this.gravityEnabled,gravity:this.gravity,phaseSettings:copy(this.phaseSettings),ragdollEnabled:this.ragdollEnabled,autoRagdoll:this.autoRagdoll,ragdollLocks:[...this.ragdollLocks],customPoses:copy(this.customPoses),bakeDuration:this.bakeDuration,topology:this.mesh.metadata.topologyVersion??1,preset:this.preset,bodyWeights:copy(this.bodyWeights),authorRoot:copy(this.authorRoot),jointOffsets:copy(this.jointOffsets),density:this.previewDensity,bakeDensity:this.bakeDensity,seam:this.seam,spawnHeight:this.spawnHeight,materialName:this.materialName,material:copy(this.material),appearance:copy(this.appearance),camera:copy(this.camera),pose:copy(this.pose),timeline:copy(this.timeline),objects:copy(this.objects)};}

  async loadScene(data){
    if(this.busy)return;
    if(data?.format!=='membrane-scene'||![1,2,3,4].includes(data.version))throw new Error('不支持的场景格式。');
    if(data.topology!=null && data.topology!==(this.mesh.metadata.topologyVersion??1) && data.timeline?.grabs?.length)throw new Error('抓取记录的网格版本不兼容。');
    if(!BODY_PRESETS.some(p=>p.id===data.preset)||!DENSITIES.some(d=>Number(d.id)===data.density))throw new Error('体型预设或网格精度无效。');
    validateTimeline(data.timeline);
    if(!Array.isArray(data.objects)||data.objects.length>5||data.objects.some(o=>!Number.isSafeInteger(o.id)||o.id<1||!COLLIDER_KINDS.includes(o.kind)||!Array.isArray(o.position)||o.position.length!==3||!o.position.every(v=>Number.isFinite(v)&&Math.abs(v)<=5)||!Number.isFinite(o.rotation)||!Number.isFinite(o.scale)||o.scale<.2||o.scale>3)||new Set(data.objects.map(o=>o.id)).size!==data.objects.length||expandColliders(data.objects).length>32)throw new Error('碰撞体数据无效。');
    if(!Number.isFinite(data.spawnHeight)||data.spawnHeight<0||data.spawnHeight>1.5||!MATERIALS[data.materialName])throw new Error('物理设置无效。');
    const ranges={stretch:[1e-9,.001],bend:[1e-7,.1],damping:[0,8],friction:[0,1],thickness:[.001,.012],mass:[.05,1],pressure:[.1,2]};
    for(const [key,[min,max]]of Object.entries(ranges))if(!Number.isFinite(data.material?.[key])||data.material[key]<min*.9999||data.material[key]>max*1.0001)throw new Error(`材质参数“${MATERIAL_LABELS[key]}”无效。`);
    for(const key of ['skin','eyes','lips','boxers'])if(!/^#[\da-f]{6}$/i.test(data.appearance?.[key]))throw new Error('外观颜色无效。');
    if(!['plain','stripe','weave'].includes(data.appearance.pattern))throw new Error('表面样式无效。');
    validateTimeline({...defaultTimeline(),cameraKeys:[{time:0,value:data.camera}],poseKeys:[{time:0,value:data.pose}]});
    const clean=copy(data);
    clean.bodyWeights=normalizeBodyWeights(clean.bodyWeights,clean.preset);
    clean.authorRoot??={position:[0,0,0],rotation:[0,0,0]};clean.jointOffsets??={};
    clean.customPoses=validatePoseLibrary(clean.customPoses??this.customPoses);
    clean.bakeDuration=clamp(clean.bakeDuration??clean.timeline.duration,.1,120);
    clean.density=Number(clean.density);
    clean.bakeDensity=DENSITIES.some(d=>Number(d.id)===clean.bakeDensity)?Number(clean.bakeDensity):clean.density;
    const migrated=migrateLegacyClips(clean.timeline,clean.pose,clean.authorRoot,clean.jointOffsets);
    validateTimeline(clean.timeline);
    validateTimeline({...defaultTimeline(),poseKeys:[{time:0,value:clean.pose,root:clean.authorRoot,offsets:clean.jointOffsets}]});
    clean.appearance={scalpHair:true,hairColor:'#30241e',eyesClosed:true,clothing:'boxers',topColor:'#547d86',bottomColor:clean.appearance.boxers,interior:'#571d25',seam:'#92989c',...clean.appearance,pattern:'plain'};
    for(const key of ['hairColor','topColor','bottomColor','interior','seam'])if(!/^#[\da-f]{6}$/i.test(clean.appearance[key]))throw new Error('服装、内面或接缝颜色无效。');
    clean.sceneName=typeof clean.sceneName==='string'&&clean.sceneName.trim()?clean.sceneName.trim().slice(0,60):'未命名场景';
    clean.showGround=clean.showGround!==false;clean.gravityEnabled=clean.gravityEnabled!==false;
    clean.gravity=clamp(Number.isFinite(clean.gravity)?clean.gravity:-9.81,-30,10);
    clean.phaseSettings={releaseBinding:.02,releaseDuration:.3,inflateBinding:1,inflateDuration:3,...clean.phaseSettings};
    for(const [key,min,max]of [['releaseBinding',0,1],['inflateBinding',0,1],['releaseDuration',.05,30],['inflateDuration',.05,30]])if(!Number.isFinite(clean.phaseSettings[key])||clean.phaseSettings[key]<min||clean.phaseSettings[key]>max)throw new Error('释放或充气参数无效。');
    clean.ragdollLocks=Array.isArray(clean.ragdollLocks)?clean.ragdollLocks.filter(x=>typeof x==='string').slice(0,64):[];
    if(!['boxers','tshirt','jacket'].includes(clean.appearance.clothing))throw new Error('服装预设无效。');
    for(const event of clean.timeline.grabs)event.reference ||= grabReference(event.triangle,event.bary,clean.density);
    clean.appearance.hair=false;
    for(const key of ['preset','bodyWeights','authorRoot','jointOffsets','sceneName','showGround','gravityEnabled','gravity','phaseSettings','customPoses','bakeDuration','density','bakeDensity','spawnHeight','materialName','material','appearance','camera','pose','timeline','objects'])this[key]=clean[key];
    this.previewDensity=clean.density;this.bakeCountCache=null;
    this.initialPosePending=false;this.editor.resetBackup=null;$('timelineUndo').hidden=true;this.editor.renderPoseLibrary();this.editor.persistPoseLibrary();
    this.seam=!!data.seam;this.homeCamera=copy(this.camera);this.objectId=Math.max(0,...this.objects.map(o=>Number(o.id)||0))+1;
    $('density').value=this.previewDensity;$('bakeDensity').value=this.bakeDensity;$('seam').checked=this.seam;$('spawnHeight').value=this.spawnHeight;$('spawnHeightValue').textContent=`${this.spawnHeight.toFixed(2)} 米`;
    for(const [id,key]of Object.entries({skinColor:'skin',eyeColor:'eyes',lipColor:'lips',boxerColor:'boxers',hairColor:'hairColor',topColor:'topColor',bottomColor:'bottomColor',interiorColor:'interior',seamColor:'seam'}))$(id).value=this.appearance[key];
    for(const [id,key]of Object.entries({beard:'beard',scalpHair:'scalpHair',eyesClosed:'eyesClosed'}))$(id).checked=!!this.appearance[key];
    $('clothing').value=this.appearance.clothing;
    if(!['pixel','vertex'].includes(this.appearance.faceShading))this.appearance.faceShading='pixel';
    $('faceShading').value=this.appearance.faceShading;
    this.autoRagdoll=clean.autoRagdoll!==false;this.ragdollLocks=new Set(clean.ragdollLocks);this.ragdoll=null;this.ragdollEnabled=false;this.lastAutoRagdoll=null;
    this.syncSceneUI();
    this.editor.selection.clear();this.editor.poseDraft=false;this.selectedKey=null;this.cameraOverride=true;
    this.editor.syncTransformInputs();this.updateMorphUI();this.updateMaterialUI();this.renderObjects();
    await this.rebuild();
    if(clean.ragdollEnabled){this.setRagdoll(true);this.playing=false;}
    if(this.timeline.grabs.some(e=>e.triangle>=this.mesh.triangleCount))throw new Error('抓取记录引用了无效的网格三角形。');
    this.updateMorphUI();this.syncSceneUI();
    this.updatePresetButtons();this.status(migrated?'场景已恢复；旧动画片段已采样为姿势关键帧，片段编辑已移除。':'场景和自定义姿势已恢复，物理缓存需重新烘焙。');
  }

  updateSceneIdentity(){
    const body=Object.values(this.bodyWeights).filter(v=>v>.001).length>1?'混合体型':BODY_PRESETS.find(p=>this.bodyWeights[p.id]>.999)?.label??'混合体型';
    $('sceneIdentity').textContent=`${body} · ${MATERIALS[this.materialName].name}`;
  }
  syncGravityUI(){
    $('gravityEnabled').setAttribute('aria-pressed',String(this.gravityEnabled));$('gravityEnabled').textContent=this.gravityEnabled?'重力 开':'重力 关';$('gravityValue').value=this.gravity;
    $('gravityEnabled').classList.toggle('gravity-off',!this.gravityEnabled);
  }
  /** Transient viewport notice used for automatic state changes such as grabbing turning gravity off. */
  toast(message,ms=4800){
    const el=$('viewToast');if(!el)return;
    el.textContent=message;el.hidden=false;
    clearTimeout(this.toastTimer);this.toastTimer=setTimeout(()=>{el.hidden=true;},ms);
  }
  updatePhaseUI(){
    for(const [id,key]of Object.entries({releaseBinding:'releaseBinding',releaseDuration:'releaseDuration',inflateBinding:'inflateBinding',inflateDuration:'inflateDuration'})){
      const el=$(id),percent=key.endsWith('Binding');
      if(document.activeElement!==el)el.value=percent?Math.round(this.phaseSettings[key]*100):this.phaseSettings[key];
      const out=$(id+'Value');if(out)out.textContent=percent?`${Math.round(this.phaseSettings[key]*100)}%`:`${this.phaseSettings[key].toFixed(1)} 秒`;
    }
  }
  syncSceneUI(){
    $('sceneNameInput').value=this.sceneName;$('showGround').checked=this.showGround;$('autoRagdoll').checked=this.autoRagdoll;$('ragdollEnabled').checked=this.ragdollEnabled;
    this.syncGravityUI();this.updatePhaseUI();this.updateSceneIdentity();this.renderRagdollLocks();
  }

  updatePresetButtons(){document.querySelectorAll('[data-preset]').forEach(el=>el.classList.toggle('selected',this.bodyWeights[el.dataset.preset]>.999));}

  updateMorphUI(){
    document.querySelectorAll('[data-morph]').forEach(el=>{el.value=this.bodyWeights[el.dataset.morph]??0;const output=$(`${el.id}Value`);if(output)output.textContent=`${Math.round(Number(el.value)*100)}%`;});
    $('morphInfo').textContent=`原始权重在混合前自动归一化。当前：${BODY_PRESETS.filter(p=>this.bodyWeights[p.id]>.001).map(p=>`${p.label} ${Math.round(this.bodyWeights[p.id]*100)}%`).join('、')}。`;
    this.updatePresetButtons();this.updateSceneIdentity();
  }

  installUI(){
    const widths={fat:9,chubby:8,muscular:7.5,regular:6,skinny:4.5};
    $('presetGrid').replaceChildren(...BODY_PRESETS.map(p=>{
      const b=document.createElement('button');b.className=`preset-card ${p.id===this.preset?'selected':''}`;b.dataset.preset=p.id;b.title=p.label;
      const w=widths[p.id]||6;
      b.innerHTML=`<svg viewBox="0 0 30 50" aria-hidden="true"><circle cx="15" cy="6" r="4"/><path d="M${15-w} 13 Q15 10 ${15+w} 13 L27 28 24 30 ${16+w} 20 ${16+w} 32 20 48 15.8 48 15 33 14.2 48 10 48 ${14-w} 32 ${14-w} 20 6 30 3 28Z"/></svg>`;
      const label=document.createElement('span');label.textContent=p.label;b.append(label);
      b.addEventListener('click',async()=>{if(this.busy)return;this.preset=p.id;this.bodyWeights=normalizeBodyWeights(null,p.id);this.updateMorphUI();this.updatePresetButtons();await this.rebuild();});return b;
    }));
    document.querySelectorAll('[data-morph]').forEach(el=>{
      el.addEventListener('input',()=>{const output=$(`${el.id}Value`);if(output)output.textContent=`${Math.round(Number(el.value)*100)}%`;});
      el.addEventListener('change',async()=>{if(this.busy)return;this.bodyWeights=normalizeBodyWeights(Object.fromEntries([...document.querySelectorAll('[data-morph]')].map(x=>[x.dataset.morph,Number(x.value)])),this.preset);this.updateMorphUI();await this.rebuild();});
    });
    $('normalizeMorph').addEventListener('click',async()=>{if(this.busy)return;this.preset='regular';this.bodyWeights=normalizeBodyWeights(null,'regular');this.updateMorphUI();await this.rebuild();});
    $('density').replaceChildren(...DENSITIES.map(d=>new Option(d.label,d.id)));$('density').value=this.previewDensity;
    $('density').addEventListener('change',async()=>{
      if(this.busy)return;
      this.previewDensity=Number($('density').value);this.bakeCountCache=null;this.updateBakeSummary();
      if(this.cachedMode){this.status('已记录实时预览精度；烘焙回放仍使用烘焙精度，点击“恢复实时模拟”后按新精度重建。');return;}
      if(this.density!==this.previewDensity)await this.rebuild(this.previewDensity);
      this.status('实时预览网格精度已更改，抓取记录已重新映射；请重新烘焙以更新物理结果。');
    });
    $('bakeDensity').replaceChildren(...DENSITIES.map(d=>new Option(d.label,d.id)));$('bakeDensity').value=this.bakeDensity;
    $('bakeDensity').addEventListener('change',()=>{
      this.bakeDensity=Number($('bakeDensity').value);this.bakeCountCache=null;this.updateBakeSummary();
      this.status(`烘焙网格精度设为${DENSITIES.find(d=>d.id===this.bakeDensity)?.label??this.bakeDensity}；实时预览精度不受影响。`);
    });
    $('seam').addEventListener('change',async()=>{if(this.busy)return;this.seam=$('seam').checked;await this.rebuild();});
    $('spawnHeight').addEventListener('input',()=>{$('spawnHeightValue').textContent=`${Number($('spawnHeight').value).toFixed(2)} 米`;});
    $('spawnHeight').addEventListener('change',()=>{this.spawnHeight=Number($('spawnHeight').value);this.physicsChanged();});
    for(const [id,key]of Object.entries({skinColor:'skin',eyeColor:'eyes',lipColor:'lips',boxerColor:'boxers',hairColor:'hairColor',topColor:'topColor',bottomColor:'bottomColor',interiorColor:'interior',seamColor:'seam'}))$(id).addEventListener('input',()=>{this.appearance[key]=$(id).value;});
    $('showGround').addEventListener('change',()=>this.showGround=$('showGround').checked);
    $('sceneNameInput').addEventListener('input',()=>{this.sceneName=$('sceneNameInput').value.trim()||'未命名场景';this.updateSceneIdentity();});
    $('gravityEnabled').addEventListener('click',()=>{this.gravityEnabled=!this.gravityEnabled;this.syncGravityUI();});
    $('gravityValue').addEventListener('change',()=>{this.gravity=clamp(Number($('gravityValue').value)||-9.81,-30,10);this.syncGravityUI();});
    const applyPhase=(id,key)=>{
      const percent=key.endsWith('Binding'),raw=Number($(id).value);
      if(!Number.isFinite(raw))return false;
      const value=percent?clamp(raw/100,0,1):clamp(raw,.05,30);
      if(Math.abs(value-this.phaseSettings[key])<1e-9)return false;
      this.phaseSettings[key]=value;this.updatePhaseUI();return true;
    };
    for(const [id,key]of Object.entries({releaseBinding:'releaseBinding',releaseDuration:'releaseDuration',inflateBinding:'inflateBinding',inflateDuration:'inflateDuration'})){
      $(id).addEventListener('input',()=>applyPhase(id,key));
      $(id).addEventListener('change',()=>{if(applyPhase(id,key)&&this.cache)this.invalidate('阶段参数已更新，旧烘焙缓存已失效；模拟继续使用新参数。');});
    }
    $('autoRagdoll').addEventListener('change',()=>this.autoRagdoll=$('autoRagdoll').checked);
    $('ragdollEnabled').addEventListener('change',()=>this.setRagdoll($('ragdollEnabled').checked));
    for(const [id,key]of Object.entries({beard:'beard',scalpHair:'scalpHair',eyesClosed:'eyesClosed'}))$(id).addEventListener('change',()=>this.appearance[key]=$(id).checked);
    $('clothing').addEventListener('change',()=>this.appearance.clothing=$('clothing').value);
    $('faceShading').addEventListener('change',()=>{this.appearance.faceShading=$('faceShading').value;this.status(this.appearance.faceShading==='pixel'?'已启用逐像素面部着色：五官与胡须在任意网格精度下保持清晰。':'已启用顶点烘焙着色：渲染更快，低精度网格下五官细节可能丢失。');this.draw();});
    $('grabRadius').addEventListener('input',()=>{$('grabRadiusValue').textContent=`${Math.round(Number($('grabRadius').value)*100)} 厘米`;});
    document.querySelectorAll('[data-panel]').forEach(el=>el.addEventListener('click',()=>this.panel(el.dataset.panel)));
    document.querySelectorAll('[data-material]').forEach(el=>el.addEventListener('click',()=>{this.materialName=el.dataset.material;this.material={...MATERIALS[this.materialName]};this.appearance.roughness=this.materialName==='cloth'?.8:.38;this.updateMaterialUI();this.updateSceneIdentity();this.physicsChanged();}));
    for(const id of ['thickness','mass','stretch','bend','damping','friction','pressure']){
      $(id).addEventListener('input',()=>{const value=Number($(id).value);this.material[id]=id==='thickness'||id==='mass'?value/1000:id==='stretch'||id==='bend'?10**value:value;this.updateMaterialUI();});
      $(id).addEventListener('change',()=>this.physicsChanged());
    }
    $('grabStrength').addEventListener('input',()=>{$('grabStrengthValue').textContent=`${Math.round(Number($('grabStrength').value)*100)}%`;if(this.grab)this.grab.strength=Number($('grabStrength').value);});
    document.querySelectorAll('[data-add]').forEach(el=>el.addEventListener('click',()=>{if(this.objects.length>=5){this.status('最多可添加五个场景物体，以限制碰撞计算与 GPU 资源开销。',true);return;}const o=createObject(el.dataset.add,this.objectId++);this.objects.push(o);this.selectedObject=o.id;this.renderObjects();this.physicsChanged();}));
    for(const id of ['objectX','objectY','objectZ','objectYaw','objectScale'])$(id).addEventListener('change',()=>{const o=this.objects.find(o=>o.id===this.selectedObject);if(!o)return;const value=Number($(id).value);if(!Number.isFinite(value))return;const axis=['objectX','objectY','objectZ'].indexOf(id);if(axis>=0)o.position[axis]=clamp(value,axis===1?0:-5,5);else if(id==='objectYaw')o.rotation=clamp(value,-180,180);else o.scale=clamp(value,.2,3);this.renderObjects();this.physicsChanged();});
    $('removeObject').addEventListener('click',()=>{this.objects=this.objects.filter(o=>o.id!==this.selectedObject);this.selectedObject=null;this.renderObjects();this.physicsChanged();});
    $('wireframe').addEventListener('click',()=>{this.wireframe=!this.wireframe;$('wireframe').setAttribute('aria-pressed',this.wireframe);});
    $('rigOverlay').addEventListener('click',()=>this.setRigVisible(!this.showRig));
    $('frameCamera').addEventListener('click',()=>this.frameSubject());
    $('playButton').addEventListener('click',()=>this.togglePlay());
    $('resetButton').addEventListener('click',async()=>{if(this.busy)return;if(this.cache){await this.seek(0);return;}if(this.density!==this.previewDensity){await this.rebuild(this.previewDensity);return;}this.busy=true;try{await this.reset();this.draw();}finally{this.busy=false;}});
    $('resetSimulation').addEventListener('click',async()=>{if(this.busy)return;this.busy=true;try{if(this.ragdollEnabled)this.disableRagdoll(false);if(this.density!==this.previewDensity)await this.rebuild(this.previewDensity);this.editor.resetToSelectedPose();await this.reset(true);this.draw();this.status('模拟已重置，骨骼恢复为当前选择的姿势。');}finally{this.busy=false;}});
    $('stepButton').addEventListener('click',async()=>{if(this.busy)return;if(this.cachedMode){await this.seek(this.time+1/this.timeline.fps);return;}this.playing=false;this.busy=true;try{let n=Math.round(60/this.timeline.fps);for(let i=0;i<n;i++)await this.stepFixed(1/(this.timeline.fps*n));this.draw();}finally{this.busy=false;}});
    $('releaseButton').addEventListener('click',()=>this.setPhase('release'));
    $('inflateButton').addEventListener('click',()=>this.setPhase('inflate'));
    $('keyCamera').addEventListener('click',()=>{insertKey(this.timeline.cameraKeys,{time:this.time,value:copy(this.camera)});this.refreshTimeline();this.status('已添加相机关键帧，模拟缓存保持不变。');});
    $('recordCamera').addEventListener('change',()=>{this.lastRecord=-1;this.cameraOverride=$('recordCamera').checked;});
    $('fov').addEventListener('input',()=>{this.camera.fov=Number($('fov').value);$('fovValue').textContent=`${this.camera.fov}°`;this.cameraOverride=true;});
    this.updateMorphUI();this.syncSceneUI();
    this.showGeneral('camera');
    for(const id of ['duration','cacheFps'])$(id).addEventListener('change',()=>{this.timeline.duration=clamp(Number($('duration').value)||30,1,120);this.timeline.fps=Number($('cacheFps').value);this.refreshTimeline();this.physicsChanged();});
    $('bakeDuration').addEventListener('change',()=>{this.bakeDuration=clamp(Number($('bakeDuration').value)||30,.1,120);this.updateBakeSummary();this.status(`烘焙长度设为 ${this.bakeDuration.toFixed(1)} 秒；时间轴仍为 ${this.timeline.duration.toFixed(1)} 秒。`);});
    $('bakeButton').addEventListener('click',()=>this.bake());$('calibrateButton').addEventListener('click',()=>this.bake(true));$('cancelBake').addEventListener('click',()=>{this.cancel=true;this.pendingBake=null;});
    $('bakeShortcut').addEventListener('click',()=>this.panel('bakePanel'));
    $('resumeLive').addEventListener('click',async()=>{const t=this.time;if(this.density!==this.previewDensity){await this.rebuild(this.previewDensity,'已恢复实时物理模拟，并按实时预览精度重建；请重新烘焙。');return;}await this.seek(t,true);this.invalidate('已恢复实时物理模拟，后续烘焙帧已失效。');});
    $('helpButton').addEventListener('click',()=>$('helpDialog').showModal());$('closeHelp').addEventListener('click',()=>$('helpDialog').close());$('retryButton').addEventListener('click',()=>location.reload());
    $('saveScene').addEventListener('click',()=>{const blob=new Blob([JSON.stringify(this.sceneData(),null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='布料模拟-场景.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);this.status('场景设置已下载，大型模拟缓存仍仅保存在当前会话中。');});
    $('loadScene').addEventListener('click',()=>$('sceneFile').click());$('sceneFile').addEventListener('change',async()=>{const file=$('sceneFile').files[0];if(!file)return;try{if(file.size>10*1024*1024)throw new Error('场景文件超过 10 MiB。');await this.loadScene(JSON.parse(await file.text()));}catch(e){this.status(`无法加载场景：${e.message}`,true);}finally{$('sceneFile').value='';}});
    this.refreshTimeline();this.updateMaterialUI();
  }
}

const studio=new Studio();
window.clothStudio=studio;
window.addEventListener('unhandledrejection',event=>studio.fatal(event.reason?.message||String(event.reason)));
studio.initialize().catch(error=>studio.fatal(error.message));
