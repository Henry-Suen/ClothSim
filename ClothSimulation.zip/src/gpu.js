export async function initializeGPU(onError) {
  if (!globalThis.isSecureContext) throw new Error('浏览器需要安全的本地环境。请在 Chrome 或 Edge 中打开此文件，或通过 http://127.0.0.1:8000 本地服务访问。');
  if (!navigator.gpu) throw new Error('WebGPU 不可用。请在 Chrome 或 Edge 中启用图形硬件加速，然后重启浏览器。本应用不使用 CPU 替代求解。');
  const adapter = await navigator.gpu.requestAdapter({ powerPreference: 'high-performance' }).catch(error => {
    throw new Error(`无法连接 WebGPU 适配器。请检查显卡驱动及浏览器的硬件加速设置。驱动诊断：${error.message}`);
  });
  if (!adapter) throw new Error('未找到可用的 WebGPU 适配器。请检查图形硬件加速、显卡驱动及 chrome://gpu 页面。');
  const device = await adapter.requestDevice({
    requiredLimits: {
      maxStorageBuffersPerShaderStage: Math.min(16, adapter.limits.maxStorageBuffersPerShaderStage),
      maxStorageBufferBindingSize: Math.min(256 * 1024 * 1024, adapter.limits.maxStorageBufferBindingSize),
      maxBufferSize: Math.min(512 * 1024 * 1024, adapter.limits.maxBufferSize),
    },
  }).catch(error => {
    throw new Error(`无法创建 GPU 设备。请检查显卡是否满足资源限制，并关闭占用大量显存的应用后重试。驱动诊断：${error.message}`);
  });
  device.addEventListener('uncapturederror', event => onError?.(`GPU 运行错误：${event.error.message}`));
  device.lost.then(info => onError?.(`GPU 设备连接已断开${info.reason === 'destroyed' ? '（设备已释放）' : ''}。请重新加载应用以恢复。${info.message ? `驱动诊断：${info.message}` : ''}`));
  const info = adapter.info || {};
  return { device, adapter, format: navigator.gpu.getPreferredCanvasFormat(), info: { vendor: info.vendor || 'GPU', architecture: info.architecture || '', device: info.device || '', description: info.description || '', fallback: info.isFallbackAdapter || false } };
}
