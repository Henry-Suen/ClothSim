import { clamp, timelineItems, retimeSelection, deleteSelection, samplePose, samplePoseTransform, insertKey, validateTimeline, validatePoseLibrary, migrateLegacyClips } from './timeline.js';
import { cameraRay, projectPoint, moveCamera, getCameraPosition, transformObjectGizmo, hitObjectGizmo } from './renderer.js';
import { evaluateRig, POSE_JOINTS, POSE_PRESETS, createPosePreset } from './rig.js';

const $=id=>document.getElementById(id);
const copy=x=>structuredClone(x);
const add=(a,b)=>a.map((v,i)=>v+b[i]);
const sub=(a,b)=>a.map((v,i)=>v-b[i]);
const mul=(a,t)=>a.map(v=>v*t);
const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
const length=v=>Math.hypot(...v);
const unit=v=>mul(v,1/Math.max(1e-8,length(v)));
const axisVector=i=>[0,1,2].map(j=>Number(i===j));
const editable=target=>target?.closest?.('input,select,textarea,[contenteditable="true"]');
const CLIPS={stand:'站立',walk:'原地行走',sit:'坐下'};
const LABELS={camera:'相机',pose:'姿势',phase:'模拟阶段',grab:'柔性抓取',clip:'动作片段',release:'释放',inflate:'充气'};
const JOINTS={hips:'骨盆',spine:'腰椎',chest:'胸部',neck:'颈部',head:'头部',upperArm:'上臂',forearm:'前臂',hand:'手掌',thigh:'大腿',shin:'小腿',foot:'脚掌'};
export function jointLabel(name){if(name==='root')return '根节点（整体）';const [base,side]=name.split('.');return `${side==='L'?'左':side==='R'?'右':''}${JOINTS[base]??base.replace(/finger/,'手指').replace(/thumb/,'拇指').replace(/toe/,'脚趾')}`;}
const download=(name,data)=>{const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};

export class StudioEditor {
  constructor(studio){
    this.s=studio;this.tool='camera';this.gizmo='rotate';this.selectedJoint='hips';this.keys=new Set();this.selection=new Set();
    this.timelineMode='scrub';this.scrubbing=false;this.seekTarget=null;this.seeking=false;this.gizmoDrag=null;this.handles=[];this.jointHits=[];this.poseDraft=false;
    try{studio.customPoses=validatePoseLibrary(JSON.parse(localStorage.getItem('cloth-poses-v1')||'[]'));}catch{studio.customPoses=[];}
    this.install();this.renderTimeline();this.renderPoseLibrary();this.syncTransformInputs();
  }
  install(){
    const s=this.s;
    document.querySelectorAll('[data-tool]').forEach(b=>b.addEventListener('click',()=>this.setTool(b.dataset.tool)));
    document.querySelectorAll('[data-gizmo]').forEach(b=>b.addEventListener('click',()=>{this.gizmo=b.dataset.gizmo;this.syncModes();}));
    $('selectRoot').addEventListener('click',()=>{this.setTool('pose');this.selectedJoint='root';this.syncTransformInputs();});
    $('joint').addEventListener('change',()=>{this.selectedJoint=$('joint').value;this.syncTransformInputs();});
    for(const axis of ['X','Y','Z']){
      $(`root${axis}`).addEventListener('change',()=>{if(s.busy)return;this.preparePoseDraft();s.authorRoot.position['XYZ'.indexOf(axis)]=clamp(Number($(`root${axis}`).value)||0,-5,5);this.previewPose();this.commitPose();});
      $(`rootR${axis}`).addEventListener('change',()=>{if(s.busy)return;this.preparePoseDraft();s.authorRoot.rotation['XYZ'.indexOf(axis)]=clamp(Number($(`rootR${axis}`).value)||0,-180,180);this.previewPose();this.commitPose();});
      $(`offset${axis}`).addEventListener('change',()=>{if(s.busy||this.selectedJoint==='root')return;this.preparePoseDraft();const v=s.jointOffsets[this.selectedJoint]??[0,0,0];v['XYZ'.indexOf(axis)]=clamp(Number($(`offset${axis}`).value)||0,-.5,.5);s.jointOffsets[this.selectedJoint]=v;this.previewPose();this.commitPose();});
    }
    $('keyPose').addEventListener('click',()=>{if(s.busy)return;this.commitPose(true);});
    $('resetPose').addEventListener('click',()=>this.applyPose('stand'));
    $('savePose').addEventListener('click',()=>this.savePose());
    $('deletePose').addEventListener('click',()=>{if(s.busy)return;const id=$('posePreset').value;if(!id.startsWith('user-'))return;s.customPoses=s.customPoses.filter(p=>p.id!==id);this.persistPoseLibrary();this.renderPoseLibrary();s.status('已删除自定义姿势，当前人物姿势保持不变。');});
    $('posePreset').addEventListener('change',()=>{ $('deletePose').disabled=!$('posePreset').value.startsWith('user-');this.applyPose($('posePreset').value); });
    $('exportPoses').addEventListener('click',()=>download('布料模拟-姿势库.json',{format:'cloth-poses',version:1,poses:s.customPoses}));
    $('importPoses').addEventListener('click',()=>$('poseFile').click());
    $('poseFile').addEventListener('change',async()=>{const file=$('poseFile').files[0];if(!file||s.busy)return;try{
      if(file.size>1024*1024)throw new Error('姿势文件超过 1 MiB。');const data=JSON.parse(await file.text());
      if(data.format!=='cloth-poses'||data.version!==1)throw new Error('不支持的姿势库格式。');
      const poses=validatePoseLibrary(data.poses),merged=new Map(s.customPoses.map(p=>[p.id,p]));for(const p of poses)merged.set(p.id,p);
      s.customPoses=validatePoseLibrary([...merged.values()]);this.persistPoseLibrary();this.renderPoseLibrary();s.status('姿势库已导入。');
    }catch(e){s.status(`姿势导入失败：${e.message}`,true);}finally{$('poseFile').value='';}});
    for(const axis of ['X','Y','Z']){
      $(`pose${axis}`).addEventListener('pointerdown',()=>this.preparePoseDraft());
      $(`pose${axis}`).addEventListener('input',()=>{if(s.busy)return;this.preparePoseDraft();s.pose[$('joint').value]=['X','Y','Z'].map(a=>Number($(`pose${a}`).value));this.previewPose();});
      $(`pose${axis}`).addEventListener('change',()=>this.commitPose());
    }
    document.querySelectorAll('[data-timeline-mode]').forEach(b=>b.addEventListener('click',()=>{this.timelineMode=b.dataset.timelineMode;this.syncModes();}));
    $('timelineReset').addEventListener('click',()=>this.clearTimeline());
    $('timelineUndo').addEventListener('click',async()=>{
      if(s.busy||!this.resetBackup)return;this.cancelEditing();s.timeline=this.resetBackup;this.resetBackup=null;$('timelineUndo').hidden=true;
      this.renderTimeline();await s.physicsChanged('已撤销时间轴清空。');
    });
    $('timelineSave').addEventListener('click',()=>download('布料模拟-时间轴.json',{format:'cloth-timeline',version:3,topology:s.mesh?.metadata.topologyVersion??1,density:s.density,timeline:s.timeline}));
    $('timelineLoad').addEventListener('click',()=>$('timelineFile').click());
    $('timelineFile').addEventListener('change',async()=>{
      const file=$('timelineFile').files[0];if(!file||s.busy)return;
      try{if(file.size>10*1024*1024)throw new Error('文件超过 10 MiB。');const data=JSON.parse(await file.text());await this.loadTimeline(data);}
      catch(e){s.status(`时间轴加载失败：${e.message}`,true);}finally{$('timelineFile').value='';}
    });
    $('deleteKey').addEventListener('click',()=>this.removeSelected());
    $('ruler').addEventListener('pointerdown',e=>this.startScrub(e));
    $('playhead').style.pointerEvents='auto';$('playhead').style.cursor='ew-resize';$('playhead').addEventListener('pointerdown',e=>this.startScrub(e));
    $('scrubber').addEventListener('pointerdown',()=>{this.scrubbing=true;s.playing=false;});
    $('scrubber').addEventListener('input',()=>this.requestSeek(Number($('scrubber').value)));
    $('scrubber').addEventListener('change',()=>{this.scrubbing=false;this.requestSeek(Number($('scrubber').value));});
    for(const name of ['pointerup','pointercancel'])$('scrubber').addEventListener(name,()=>{this.scrubbing=false;});
    for(const track of document.querySelectorAll('.track'))track.addEventListener('pointerdown',e=>{
      if(e.target!==track)return;
      if(this.timelineMode==='select'||e.shiftKey)this.startMarquee(e);else this.startScrub(e);
    });
    const canvas=$('viewport');
    canvas.addEventListener('contextmenu',e=>e.preventDefault());
    canvas.addEventListener('pointerdown',e=>this.pointerDown(e));
    canvas.addEventListener('pointermove',e=>this.pointerMove(e));
    canvas.addEventListener('pointerup',()=>this.pointerUp());
    canvas.addEventListener('pointercancel',()=>this.pointerUp());
    canvas.addEventListener('lostpointercapture',()=>this.pointerUp());
    canvas.addEventListener('wheel',e=>s.handleWheel(e),{passive:false});
    canvas.addEventListener('pointerleave',()=>{if(!s.pointer)$('grabBrush').hidden=true;});
    window.addEventListener('keydown',e=>this.keyDown(e));
    window.addEventListener('keyup',e=>this.keys.delete(e.code));
    window.addEventListener('blur',()=>{this.keys.clear();this.pointerUp();});
    this.syncModes();
  }
  cancelEditing(){
    this.seekTarget=null;this.scrubbing=false;this.gizmoDrag=null;this.poseDraft=false;this.keys.clear();this.selection.clear();
    this.s.playing=false;this.s.releaseGrab();this.s.selectedKey=null;$('recordCamera').checked=false;this.s.lastRecord=-1;
  }
  async clearTimeline(){
    const s=this.s;if(s.busy){s.status('正在计算，请结束定位或取消烘焙后再清空时间轴。');return;}
    this.cancelEditing();this.resetBackup=copy(s.timeline);
    s.timeline={duration:s.timeline.duration,fps:s.timeline.fps,cameraKeys:[],poseKeys:[],clips:[],phases:[],grabs:[]};
    $('timelineUndo').hidden=false;this.renderTimeline();await s.physicsChanged('时间轴已清空，当前基础姿势保留。可点击“撤销清空”恢复。');this.syncTransformInputs();
  }
  renderPoseLibrary(selected=$('posePreset').value){
    $('posePreset').replaceChildren(...POSE_PRESETS.map(p=>new Option(p.label,p.id)),...this.s.customPoses.map(p=>new Option(`自定义 · ${p.name}`,p.id)));
    if([...$('posePreset').options].some(p=>p.value===selected))$('posePreset').value=selected;
    $('deletePose').disabled=!$('posePreset').value.startsWith('user-');
  }
  persistPoseLibrary(){
    try{localStorage.setItem('cloth-poses-v1',JSON.stringify(this.s.customPoses));return true;}
    catch{this.s.status('浏览器无法持久保存姿势，请使用“导出姿势库”保存文件。',true);return false;}
  }
  currentPose(){
    const s=this.s,transform=samplePoseTransform(s.timeline.poseKeys,s.time,s.authorRoot,s.jointOffsets);
    return this.poseDraft?{value:copy(s.pose),root:copy(s.authorRoot),offsets:copy(s.jointOffsets)}:{value:samplePose(s.timeline.poseKeys,s.time,s.pose),root:transform.root,offsets:transform.offsets};
  }
  savePose(){
    const s=this.s;if(s.busy)return;
    const name=$('poseName').value.trim();if(!name){s.status('请先输入新姿势名称。',true);$('poseName').focus();return;}
    if(s.customPoses.length>=100){s.status('自定义姿势已达 100 个，请先删除不需要的姿势。',true);return;}
    const pose={id:`user-${crypto.randomUUID()}`,name,...this.currentPose()};
    validatePoseLibrary([pose]);s.customPoses.push(pose);const saved=this.persistPoseLibrary();this.renderPoseLibrary(pose.id);
    if(saved)s.status(`已保存新姿势“${name}”，刷新页面后仍可使用；也可导出备份。`);
  }
  async applyPose(id){
    const s=this.s;if(s.busy||!s.mesh||s.ragdollEnabled){if(s.ragdollEnabled)s.status('请先退出布娃娃，再应用姿势。');return;}
    const frame=id.startsWith('user-')?copy(s.customPoses.find(p=>p.id===id)):createPosePreset(s.mesh,id);if(!frame)return;
    s.playing=false;s.releaseGrab();this.gizmoDrag=null;this.poseDraft=true;s.pose=copy(frame.value);s.authorRoot=copy(frame.root);s.jointOffsets=copy(frame.offsets);
    this.previewPose();this.commitPose();this.setTool('pose');s.status('已应用静态姿势，可拖动关节修改并保存为新姿势。');
  }
  /** Reset the base skeleton to the pose currently selected in the pose library. */
  resetToSelectedPose(){
    const s=this.s;if(!s.mesh)return;
    const id=$('posePreset').value||'stand';
    const frame=id.startsWith('user-')?copy(s.customPoses.find(p=>p.id===id)):createPosePreset(s.mesh,id);
    if(!frame)return;
    this.gizmoDrag=null;this.poseDraft=false;this.selection.clear();
    s.pose=copy(frame.value);s.authorRoot=copy(frame.root);s.jointOffsets=copy(frame.offsets||{});
    s.timeline.poseKeys=[];
    this.renderTimeline();this.syncTransformInputs();
  }
  async loadTimeline(data){
    const s=this.s;if(data?.format!=='cloth-timeline'||![1,2,3].includes(data.version))throw new Error('不支持的时间轴文件。');
    const t=copy(data.timeline);validateTimeline(t);
    for(const event of t.grabs){
      if(data.topology!=null && data.topology!==(s.mesh.metadata.topologyVersion??1))throw new Error('抓取记录与当前网格版本不兼容。');
      if(!event.reference && data.density!==s.density)throw new Error('旧抓取记录缺少跨密度映射。');
    }
    const migrated=migrateLegacyClips(t,s.pose,s.authorRoot,s.jointOffsets);validateTimeline(t);
    this.cancelEditing();this.resetBackup=null;$('timelineUndo').hidden=true;
    s.timeline=t;await s.rebuild();s.status(migrated?'时间轴已加载，旧片段已转换为姿势关键帧。':'时间轴已加载，模拟缓存已清除。');
  }
  syncModes(){
    document.querySelectorAll('[data-tool]').forEach(b=>{b.classList.toggle('selected',b.dataset.tool===this.tool);b.setAttribute('aria-pressed',b.dataset.tool===this.tool);});
    document.querySelectorAll('[data-gizmo]').forEach(b=>{b.classList.toggle('selected',b.dataset.gizmo===this.gizmo);b.setAttribute('aria-pressed',b.dataset.gizmo===this.gizmo);});
    document.querySelectorAll('[data-timeline-mode]').forEach(b=>{b.classList.toggle('selected',b.dataset.timelineMode===this.timelineMode);b.setAttribute('aria-pressed',b.dataset.timelineMode===this.timelineMode);});
    $('toolLabel').textContent={camera:'相机模式',grab:'柔性抓取模式',pose:'姿势编辑模式'}[this.tool];
    $('viewport').style.cursor=this.tool==='grab'?'crosshair':this.tool==='pose'?'default':'grab';
  }
  syncRagdollState(){
    const locked=this.s.ragdollEnabled;
    document.querySelectorAll('[data-gizmo],#selectRoot,#applyPose,#savePose,#resetPose,#keyPose').forEach(el=>el.disabled=locked);
    document.querySelectorAll('#rigPanel .xyz-row input,#rigPanel .pose-range,#rigPanel #joint').forEach(el=>el.disabled=locked);
    $('ragdollPoseNotice').hidden=!(locked&&this.tool==='pose');
  }
  setTool(tool){
    if(this.s.busy||!['camera','grab','pose'].includes(tool))return;
    this.pointerUp();this.keys.clear();this.tool=tool;
    if(tool==='pose'){
      this.s.playing=false;this.s.panel('rigPanel');this.s.setRigVisible(true);this.syncTransformInputs();
      if(this.s.ragdollEnabled)this.s.status('布娃娃关节由物理约束驱动；可查看线框碰撞体，关闭布娃娃后才能编辑姿势。');
    }else this.s.setRigVisible(false);
    this.s.showGeneral(tool==='grab'?'grab':'camera',tool==='grab');
    if(tool!=='grab')$('grabBrush').hidden=true;
    this.syncModes();this.syncRagdollState();this.s.draw();
  }
  tick(dt){
    if(!this.s.busy&&!this.seeking&&this.seekTarget!=null)this.drainSeeks();
    if(this.s.busy||!this.keys.size)return;
    if(editable(document.activeElement)||$('helpDialog').open){this.keys.clear();return;}
    const n=k=>Number(this.keys.has(k));
    const movement={forward:n('KeyW')-n('KeyS'),right:n('KeyD')-n('KeyA'),up:n('KeyE')-n('KeyQ')};
    if(movement.forward||movement.right||movement.up){moveCamera(this.s.camera,movement,dt,this.keys.has('ShiftLeft')?3:1.2);this.s.cameraOverride=true;}
  }
  keyDown(e){
    if(editable(e.target)||$('helpDialog').open)return;
    if(e.code==='Escape'){this.pointerUp();this.keys.clear();return;}
    const inTimeline=$('timelinePanel').contains(document.activeElement);
    if((e.code==='Delete'||e.code==='Backspace') && (inTimeline||this.selection.size)) {e.preventDefault();this.removeSelected();return;}
    if((e.ctrlKey||e.metaKey)&&e.code==='KeyA'&&inTimeline){e.preventDefault();this.selection=new Set(timelineItems(this.s.timeline).map(x=>x.token));this.renderTimeline();return;}
    if(e.code==='Space'){e.preventDefault();this.s.togglePlay();return;}
    if(e.code==='KeyF'){e.preventDefault();this.s.frameSubject();return;}
    if(!e.ctrlKey&&!e.metaKey&&!e.altKey&&['KeyW','KeyA','KeyS','KeyD','KeyQ','KeyE','ShiftLeft'].includes(e.code)){
      if(inTimeline)return;e.preventDefault();this.keys.add(e.code);
    }
  }
  requestSeek(time){
    this.s.playing=false;this.seekTarget=clamp(time,0,this.s.timeline.duration);this.poseDraft=false;
    $('playhead').style.left=`${this.seekTarget/this.s.timeline.duration*100}%`;
    if(!this.seeking)this.drainSeeks();
  }
  async drainSeeks(){
    if(this.s.baking||this.s.busy)return;
    this.seeking=true;
    try{while(this.seekTarget!=null){const t=this.seekTarget;this.seekTarget=null;await this.s.seek(t);}}
    finally{this.seeking=false;this.syncTransformInputs();}
  }
  startScrub(e){
    if(this.s.busy||e.button!==0)return;e.preventDefault();e.stopPropagation();this.scrubbing=true;
    const element=e.currentTarget;const bounds=$('ruler').getBoundingClientRect();element.setPointerCapture(e.pointerId);
    if(element.classList.contains('track')){this.selection.clear();this.s.selectedKey=null;this.paintSelection();}
    const update=e=>this.requestSeek((e.clientX-bounds.left)/bounds.width*this.s.timeline.duration);
    const end=e=>{update(e);this.scrubbing=false;element.removeEventListener('pointermove',update);element.removeEventListener('pointerup',end);element.removeEventListener('pointercancel',cancel);};
    const cancel=()=>{this.scrubbing=false;element.removeEventListener('pointermove',update);element.removeEventListener('pointerup',end);element.removeEventListener('pointercancel',cancel);};
    element.addEventListener('pointermove',update);element.addEventListener('pointerup',end);element.addEventListener('pointercancel',cancel);update(e);
  }
  startMarquee(e){
    if(this.s.busy||e.button!==0)return;e.preventDefault();e.stopPropagation();$('timelinePanel').focus();
    const area=$('timelineTracks'),bounds=area.getBoundingClientRect(),start=[e.clientX,e.clientY],prior=(e.ctrlKey||e.metaKey||e.shiftKey)?new Set(this.selection):new Set();
    const element=e.currentTarget;element.setPointerCapture(e.pointerId);$('selectionRect').hidden=false;
    const update=ev=>{
      const left=Math.min(start[0],ev.clientX),top=Math.min(start[1],ev.clientY),right=Math.max(start[0],ev.clientX),bottom=Math.max(start[1],ev.clientY);
      Object.assign($('selectionRect').style,{left:`${left-bounds.left}px`,top:`${top-bounds.top}px`,width:`${right-left}px`,height:`${bottom-top}px`});
      this.selection=new Set(prior);
      for(const b of area.querySelectorAll('[data-token]')){const r=b.getBoundingClientRect();if(r.left<=right&&r.right>=left&&r.top<=bottom&&r.bottom>=top)this.selection.add(b.dataset.token);}
      this.paintSelection();
    };
    const end=()=>{$('selectionRect').hidden=true;element.removeEventListener('pointermove',update);element.removeEventListener('pointerup',end);element.removeEventListener('pointercancel',end);this.s.selectedKey=null;};
    element.addEventListener('pointermove',update);element.addEventListener('pointerup',end);element.addEventListener('pointercancel',end);update(e);
  }
  paintSelection(){
    document.querySelectorAll('[data-token]').forEach(b=>b.classList.toggle('selected',this.selection.has(b.dataset.token)));
    $('selectionCount').textContent=this.selection.size?`已选 ${this.selection.size} 项`:'未选择';$('deleteKey').disabled=!this.selection.size;
    this.s.selectedKey=null;
  }
  renderTimeline(){
    const s=this.s,t=s.timeline;timelineItems(t);$('ruler').replaceChildren();
    const range=$('bakeRange');range.hidden=!s.cache;
    if(s.cache){range.style.width=`${Math.min(100,s.cache.duration/t.duration*100)}%`;range.classList.toggle('partial',!s.cache.complete);range.title=`${s.cache.complete?'烘焙缓存':'部分缓存'}：0–${s.cache.duration.toFixed(2)} 秒`;}
    for(const track of document.querySelectorAll('.track'))track.classList.toggle('has-cache',!!s.cache);
    for(let i=0;i<=10;i++){const span=document.createElement('span');span.textContent=(t.duration*i/10).toFixed(t.duration<10?1:0);span.style.left=`${i*10}%`;$('ruler').append(span);}
    for(const id of ['cameraTrack','animationTrack','simulationTrack'])$(id).replaceChildren();
    const items=timelineItems(t),all=new Set(items.map(e=>e.token));this.selection=new Set([...this.selection].filter(id=>all.has(id)));
    for(const {type,item,token}of items){
      if(type==='clip')continue;
      const block=type==='grab',start=item.time??item.start;
      const b=document.createElement('button');b.dataset.token=token;b.dataset.keyType=type;
      b.className=block?'timeline-clip grab':`timeline-key ${type}`;
      b.style.left=`${clamp(start/t.duration,0,1)*100}%`;
      if(block)b.style.width=`${Math.max(.4,Math.min(t.duration,item.end)-start)/t.duration*100}%`;
      b.title=`${type==='phase'?LABELS[item.type]:LABELS[type]} · ${start.toFixed(2)} 秒`;
      b.setAttribute('aria-label',b.title);if(block)b.textContent='抓取';
      b.addEventListener('pointerdown',e=>this.startItemDrag(e,{type,item,token}));
      $(type==='camera'?'cameraTrack':type==='pose'?'animationTrack':'simulationTrack').append(b);
    }
    this.paintSelection();s.updateBakeSummary();
  }
  startItemDrag(e,entry){
    const s=this.s;if(s.busy||e.button!==0)return;e.preventDefault();e.stopPropagation();s.playing=false;$('timelinePanel').focus();
    const toggle=e.ctrlKey||e.metaKey||e.shiftKey;
    if(toggle){if(this.selection.has(entry.token))this.selection.delete(entry.token);else this.selection.add(entry.token);}
    else if(!this.selection.has(entry.token))this.selection=new Set([entry.token]);
    this.paintSelection();if(!this.selection.has(entry.token))return;
    s.selectedKey=null;
    const origin=copy(s.timeline),selection=new Set(this.selection),x=e.clientX,width=$('ruler').getBoundingClientRect().width;
    let result={changed:false,physics:false};const button=e.currentTarget;button.setPointerCapture(e.pointerId);
    const update=ev=>{
      const draft=copy(origin);result=retimeSelection(draft,selection,(ev.clientX-x)/width*origin.duration);s.timeline=draft;
      for(const {token,item}of timelineItems(draft)){const b=document.querySelector(`[data-token="${CSS.escape(token)}"]`);if(b)b.style.left=`${(item.time??item.start)/draft.duration*100}%`;}
    };
    const end=async()=>{
      button.removeEventListener('pointermove',update);button.removeEventListener('pointerup',end);button.removeEventListener('pointercancel',cancel);
      if(result.changed&&result.physics)await s.physicsChanged('关键帧已整体移动，模拟已重置。');
      this.renderTimeline();
    };
    const cancel=()=>{s.timeline=origin;button.removeEventListener('pointermove',update);button.removeEventListener('pointerup',end);button.removeEventListener('pointercancel',cancel);this.renderTimeline();};
    button.addEventListener('pointermove',update);button.addEventListener('pointerup',end);button.addEventListener('pointercancel',cancel);
  }
  async removeSelected(){
    if(this.s.busy)return;const r=deleteSelection(this.s.timeline,this.selection);this.selection.clear();this.s.selectedKey=null;
    if(r.physics)await this.s.physicsChanged('已删除所选关键帧，模拟缓存已清除。');
    this.renderTimeline();
  }
  syncTransformInputs(){
    const s=this.s,frame=this.poseDraft?{root:s.authorRoot,offsets:s.jointOffsets}:samplePoseTransform(s.timeline.poseKeys,s.time,s.authorRoot,s.jointOffsets);
    const pose=this.poseDraft?s.pose:samplePose(s.timeline.poseKeys,s.time,s.pose);
    ['X','Y','Z'].forEach((a,i)=>{$(`root${a}`).value=frame.root.position[i].toFixed(3);$(`rootR${a}`).value=frame.root.rotation[i].toFixed(1);$(`offset${a}`).value=(frame.offsets[this.selectedJoint]?.[i]??0).toFixed(3);});
    if(this.selectedJoint!=='root'&&s.mesh?.bones.some(b=>b.name===this.selectedJoint))$('joint').value=this.selectedJoint;
    const rotation=pose[$('joint').value]??[0,0,0];
    ['X','Y','Z'].forEach((a,i)=>{$(`pose${a}`).value=rotation[i];$(`pose${a}Value`).textContent=`${Math.round(rotation[i])}°`;});
  }
  preparePoseDraft(){
    const s=this.s;if(this.poseDraft||s.busy||s.ragdollEnabled)return;
    s.playing=false;s.releaseGrab();s.pose=samplePose(s.timeline.poseKeys,s.time,s.pose);
    const frame=samplePoseTransform(s.timeline.poseKeys,s.time,s.authorRoot,s.jointOffsets);
    s.authorRoot=frame.root;s.jointOffsets=frame.offsets;this.poseDraft=true;s.cachedMode=false;
  }
  previewPose(){
    const s=this.s;if(!s.solver||s.busy)return;
    s.rig=evaluateRig(s.mesh,{pose:s.pose,jointOffsets:s.jointOffsets,rootRotation:s.authorRoot.rotation,root:add(s.root,s.authorRoot.position)});
    s.solver.reset({boneMatrices:s.rig.matrices});this.syncTransformInputs();s.draw();
  }
  commitPose(force=false){
    const s=this.s;if(s.busy||(!this.poseDraft&&!force))return;
    if(force&&!this.poseDraft)this.preparePoseDraft();
    const keyed=force||s.timeline.poseKeys.length>0;
    if(keyed)insertKey(s.timeline.poseKeys,{time:s.time,value:copy(s.pose),root:copy(s.authorRoot),offsets:copy(s.jointOffsets)});
    this.poseDraft=false;s.invalidate(keyed?'姿势关键帧已记录。':'基础姿势已修改，可保存为新姿势或添加关键帧。');this.renderTimeline();this.syncTransformInputs();
  }
  pointerDown(e){
    const s=this.s;if(s.busy)return;
    if(e.button===0&&this.tool!=='pose'&&this.objectGizmo){
      const r=$('viewport').getBoundingClientRect(),hit=hitObjectGizmo([e.clientX-r.left,e.clientY-r.top],this.objectGizmo);
      if(hit){e.preventDefault();$('viewport').focus();$('viewport').setPointerCapture(e.pointerId);this.startObjectGizmo(e,hit);return;}
    }
    if(e.button===0&&this.tool==='pose'){
      e.preventDefault();$('viewport').focus();$('viewport').setPointerCapture(e.pointerId);
      const r=$('viewport').getBoundingClientRect(),p=[e.clientX-r.left,e.clientY-r.top];
      const handle=this.handles.filter(h=>h.distance(p)<12).sort((a,b)=>a.distance(p)-b.distance(p))[0];
      if(handle){this.startGizmo(e,handle);return;}
      const joint=this.jointHits.filter(h=>length(sub(h.screen,p))<15).sort((a,b)=>length(sub(a.screen,p))-length(sub(b.screen,p)))[0];
      if(joint){this.selectedJoint=joint.name;this.syncTransformInputs();s.draw();return;}
      return;
    }
    s.pointerDown(e);
  }
  pointerMove(e){
    if(this.gizmoDrag){this.moveGizmo(e);return;}
    this.s.pointerMove(e);
    if(this.tool==='grab'){
      const r=$('viewport').getBoundingClientRect(),radius=Number($('grabRadius').value),pixels=clamp(radius*this.s.camera.distance**-1*r.height/(2*Math.tan(this.s.camera.fov*Math.PI/360)),12,95);
      $('grabBrush').hidden=false;Object.assign($('grabBrush').style,{left:`${e.clientX-r.left}px`,top:`${e.clientY-r.top}px`,width:`${pixels*2}px`,height:`${pixels*2}px`});
    }
  }
  pointerUp(){if(this.gizmoDrag?.kind==='object'){this.gizmoDrag=null;this.s.physicsChanged('碰撞体视口变换已更新，物理缓存已清除。');this.s.draw();return;}if(this.gizmoDrag){this.gizmoDrag=null;this.commitPose();}this.s.releaseGrab();}
  startObjectGizmo(e,hit){
    const object=this.s.objects.find(o=>o.id===hit.objectId);if(!object)return;
    this.gizmoDrag={kind:'object',id:e.pointerId,object,start:[e.clientX,e.clientY],position:[...object.position],rotation:object.rotation,axis:hit.axisIndex,mode:hit.kind,pivot:this.objectGizmo.pivot};
  }
  moveObjectGizmo(e){
    const d=this.gizmoDrag,o=this.s.objects.find(o=>o.id===d.object.id);if(!o)return;
    if(d.mode==='translate'){
      const axis=this.objectGizmo?.axes[['x','y','z'][d.axis]],dx=e.clientX-d.start[0],dy=e.clientY-d.start[1],distance=axis?dot([dx,dy],[axis.dx,axis.dy])/Math.max(5,axis.length)*this.objectGizmo.size:-dy*.004;
      o.position=[...d.position];o.position[d.axis]=clamp(d.position[d.axis]+distance,d.axis===1?0:-5,5);
    }else{
      const r=$('viewport').getBoundingClientRect(),p=d.pivot,a0=Math.atan2(d.start[1]-r.top-p.y,d.start[0]-r.left-p.x),a1=Math.atan2(e.clientY-r.top-p.y,e.clientX-r.left-p.x);
      o.rotation=clamp(d.rotation+(a1-a0)*180/Math.PI,-180,180);
    }
    this.s.renderObjects();this.s.draw();
  }
  rootPoint(){const s=this.s;return s.rig?.joints?.[0]??add(s.root,s.authorRoot.position);}
  drawGizmo(){
    const svg=$('gizmoSvg');svg.replaceChildren();this.handles=[];this.jointHits=[];
    const s=this.s,canvas=$('viewport'),w=canvas.clientWidth,h=canvas.clientHeight,ns='http://www.w3.org/2000/svg';
    this.objectGizmo=null;
    if(this.tool!=='pose'&&s.selectedObject!=null){
      const gizmo=transformObjectGizmo(s.objects,s.selectedObject,this.gizmo,s.camera,w,h);
      if(gizmo){this.objectGizmo=gizmo;
        for(const [name,a]of Object.entries(gizmo.axes)){
          if(gizmo.mode==='translate'){
            const l=document.createElementNS(ns,'line');for(const [k,v]of Object.entries({x1:gizmo.pivot.x,y1:gizmo.pivot.y,x2:a.tip[0],y2:a.tip[1],stroke:a.color,'stroke-width':4}))l.setAttribute(k,v);svg.append(l);
            const c=document.createElementNS(ns,'circle');for(const [k,v]of Object.entries({cx:a.tip[0],cy:a.tip[1],r:6,fill:a.color}))c.setAttribute(k,v);svg.append(c);
          }else{const line=document.createElementNS(ns,'polyline');for(const [k,v]of Object.entries({points:a.points.map(p=>p.join(',')).join(' '),fill:'none',stroke:a.color,'stroke-width':3}))line.setAttribute(k,v);svg.append(line);}
        }
        const label=document.createElementNS(ns,'text');for(const [k,v]of Object.entries({x:gizmo.pivot.x+13,y:gizmo.pivot.y-13,fill:'#e5d5a0','font-size':12}))label.setAttribute(k,v);label.textContent=`碰撞体 ${s.selectedObject} · ${this.gizmo==='rotate'?'旋转':'平移'}`;svg.append(label);
      }
    }
    if(this.tool!=='pose'||!s.rig||s.ragdollEnabled)return;
    const append=(tag,attrs)=>{const el=document.createElementNS(ns,tag);for(const [k,v]of Object.entries(attrs))el.setAttribute(k,v);svg.append(el);return el;};
    const permitted=new Set(POSE_JOINTS);
    s.mesh.bones.forEach((b,i)=>{
      if(!permitted.has(b.name))return;const p=projectPoint(s.camera,s.rig.joints[i],w,h);if(!p)return;
      this.jointHits.push({name:b.name,screen:p.slice(0,2)});
      append('circle',{cx:p[0],cy:p[1],r:b.name===this.selectedJoint?7:5,fill:b.name===this.selectedJoint?'#f1dc9e':'#142f38',stroke:'#b2d6d0','stroke-width':1.5,'data-joint':b.name});
    });
    const root=this.rootPoint(),rootScreen=projectPoint(s.camera,root,w,h);
    if(rootScreen){append('rect',{x:rootScreen[0]-9,y:rootScreen[1]-9,width:18,height:18,fill:'none',stroke:'#efc978','stroke-width':2,'data-joint':'root'});this.jointHits.unshift({name:'root',screen:rootScreen.slice(0,2)});}
    const index=this.selectedJoint==='root'?0:s.mesh.bones.findIndex(b=>b.name===this.selectedJoint);
    const center=s.rig.joints[Math.max(0,index)],screen=projectPoint(s.camera,center,w,h);if(!screen)return;
    this.gizmoCenter=center;
    const distance=length(sub(getCameraPosition(s.camera),center)),size=distance*Math.tan(s.camera.fov*Math.PI/360)*.22;
    const world=s.rig.worldMatrices;
    const parent=s.mesh.bones[index]?.parent??-1;
    const basis=(i)=>this.selectedJoint==='root'||parent<0||!world?axisVector(i):unit([world[parent*16+i*4],world[parent*16+i*4+1],world[parent*16+i*4+2]]);
    for(let axis=0;axis<3;axis++){
      const vector=basis(axis),color=['#ed8b81','#9bcea0','#83bce2'][axis];
      if(this.gizmo==='translate'){
        const tip=projectPoint(s.camera,add(center,mul(vector,size)),w,h);if(!tip)continue;
        append('line',{x1:screen[0],y1:screen[1],x2:tip[0],y2:tip[1],stroke:color,'stroke-width':3,'data-axis':axis});
        append('circle',{cx:tip[0],cy:tip[1],r:5,fill:color});
        this.handles.push({kind:'translate',axis,vector,center,size,screen:screen.slice(0,2),tip:tip.slice(0,2),distance:p=>segmentDistance(p,screen,tip)});
      }else{
        const u=basis((axis+1)%3),v=basis((axis+2)%3),points=[];
        for(let j=0;j<=64;j++){const angle=j/64*Math.PI*2,q=add(center,add(mul(u,Math.cos(angle)*size),mul(v,Math.sin(angle)*size)));const p=projectPoint(s.camera,q,w,h);if(p)points.push(p.slice(0,2));}
        append('polyline',{points:points.map(p=>p.join(',')).join(' '),fill:'none',stroke:color,'stroke-width':2.5,'data-axis':axis});
        this.handles.push({kind:'rotate',axis,vector,center,size,screen:screen.slice(0,2),points,distance:p=>Math.min(...points.slice(1).map((q,i)=>segmentDistance(p,points[i],q)))});
      }
    }
    const label=append('text',{x:screen[0]+15,y:screen[1]-14,fill:'#e7e5c6','font-size':12});label.textContent=`${jointLabel(this.selectedJoint)} · ${this.gizmo==='rotate'?'旋转':'平移'}`;
  }
  startGizmo(e,handle){
    const s=this.s;this.preparePoseDraft();
    const r=$('viewport').getBoundingClientRect(),point=[e.clientX-r.left,e.clientY-r.top];
    const isRoot=this.selectedJoint==='root';
    const initial=isRoot?(handle.kind==='translate'?s.authorRoot.position:s.authorRoot.rotation):(handle.kind==='translate'?s.jointOffsets[this.selectedJoint]??[0,0,0]:s.pose[this.selectedJoint]??[0,0,0]);
    const ray=cameraRay(s.camera,point[0],point[1],r.width,r.height);
    this.gizmoDrag={...handle,id:e.pointerId,start:point,initial:[...initial],isRoot,startIntersection:planeHit(ray,handle.center,handle.vector)};
  }
  moveGizmo(e){
    const d=this.gizmoDrag,s=this.s;if(!d||e.pointerId!==d.id&&d.kind!=='object')return;
    if(d.kind==='object'){this.moveObjectGizmo(e);return;}
    const r=$('viewport').getBoundingClientRect(),p=[e.clientX-r.left,e.clientY-r.top],value=[...d.initial];
    if(d.kind==='translate'){
      const projected=sub(d.tip,d.screen),scale=length(projected);
      if(scale>5)value[d.axis]+=dot(sub(p,d.start),unit(projected))/scale*d.size;
      else value[d.axis]+=(d.start[1]-p[1])*d.size/65;
      value[d.axis]=clamp(value[d.axis],d.isRoot?-5:-.5,d.isRoot?5:.5);
    }else{
      const ray=cameraRay(s.camera,p[0],p[1],r.width,r.height),hit=planeHit(ray,d.center,d.vector);
      let angle;
      if(hit&&d.startIntersection){const a=unit(sub(d.startIntersection,d.center)),b=unit(sub(hit,d.center));const cross=[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];angle=Math.atan2(dot(cross,d.vector),dot(a,b))*180/Math.PI;}
      else angle=(p[0]-d.start[0]-(p[1]-d.start[1]))*.5;
      value[d.axis]=clamp(value[d.axis]+angle,-180,180);
    }
    if(d.isRoot){if(d.kind==='translate')s.authorRoot.position=value;else s.authorRoot.rotation=value;}
    else if(d.kind==='translate')s.jointOffsets[this.selectedJoint]=value;else s.pose[this.selectedJoint]=value;
    this.previewPose();
  }
}
function segmentDistance(p,a,b){const ab=sub(b.slice(0,2),a.slice(0,2)),ap=sub(p,a.slice(0,2)),t=clamp(dot(ap,ab)/Math.max(1e-8,dot(ab,ab)),0,1);return length(sub(ap,mul(ab,t)));}
function planeHit(ray,center,normal){const denominator=dot(ray.direction,normal);if(Math.abs(denominator)<.08)return null;const t=dot(sub(center,ray.origin),normal)/denominator;return t>0?add(ray.origin,mul(ray.direction,t)):null;}
