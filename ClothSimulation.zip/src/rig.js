const DEG = Math.PI / 180;

export const POSE_JOINTS = [
  'hips', 'spine', 'chest', 'neck', 'head',
  'upperArm.L', 'forearm.L', 'hand.L', 'upperArm.R', 'forearm.R', 'hand.R',
  'thigh.L', 'shin.L', 'foot.L', 'thigh.R', 'shin.R', 'foot.R',
];

function multiply(a, b) {
  const out = new Float64Array(16);
  for (let column = 0; column < 4; column++) for (let row = 0; row < 4; row++) {
    for (let k = 0; k < 4; k++) out[column * 4 + row] += a[k * 4 + row] * b[column * 4 + k];
  }
  return out;
}

function transform(position, rotation) {
  const [x, y, z] = rotation.map(angle => angle * DEG);
  const sx = Math.sin(x), cx = Math.cos(x), sy = Math.sin(y), cy = Math.cos(y), sz = Math.sin(z), cz = Math.cos(z);
  // Column-major T * Rz * Ry * Rx; translations are local to the parent joint.
  return new Float64Array([
    cz * cy, sz * cy, -sy, 0,
    cz * sy * sx - sz * cx, sz * sy * sx + cz * cx, cy * sx, 0,
    cz * sy * cx + sz * sx, sz * sy * cx - cz * sx, cy * cx, 0,
    position[0], position[1], position[2], 1,
  ]);
}

export function legacyPoseFrame(clip = 'stand', time = 0, speed = 1) {
  const animation = {}, offset = [0,0,0];
  const rotation = (name, x, y = 0, z = 0) => { animation[name] = [x, y, z]; };
  if (clip === 'walk') {
    const phase = time * speed * Math.PI * 2 * .85;
    offset[1] += .009 * (1 - Math.cos(phase * 2));
    rotation('hips', 0, Math.sin(phase) * 4, Math.sin(phase) * 2);
    rotation('chest', 0, -Math.sin(phase) * 6, -Math.sin(phase) * 2);
    for (const [suffix, side] of [['L', 1], ['R', -1]]) {
      const swing = Math.sin(phase + (side < 0 ? Math.PI : 0));
      rotation(`thigh.${suffix}`, swing * 27);
      rotation(`shin.${suffix}`, Math.max(0, -swing) * 48);
      rotation(`foot.${suffix}`, -Math.max(0, -swing) * 17);
      rotation(`upperArm.${suffix}`, -swing * 23, 0, -side * 23);
      rotation(`forearm.${suffix}`, -12 - Math.max(0, swing) * 13);
    }
  } else if (clip === 'sit') {
    const progress = Math.min(1, Math.max(0, time * Math.max(0, speed) / 2));
    const ease = progress * progress * (3 - 2 * progress);
    offset[1] -= .39 * ease;
    offset[2] -= .12 * ease;
    rotation('spine', 7 * ease);
    rotation('chest', -7 * ease);
    for (const [suffix, side] of [['L', 1], ['R', -1]]) {
      rotation(`thigh.${suffix}`, -90 * ease, side * 3 * ease);
      rotation(`shin.${suffix}`, 90 * ease);
      rotation(`upperArm.${suffix}`, -32 * ease, 0, -side * 20 * ease);
      rotation(`forearm.${suffix}`, -33 * ease);
      rotation(`hand.${suffix}`, 8 * ease);
    }
  } else if (clip !== 'stand') {
    throw new RangeError(`Unknown animation clip: ${clip}`);
  }
  return {value:animation,root:{position:offset,rotation:[0,0,0]},offsets:{}};
}

export const POSE_PRESETS = [{id:'stand',label:'站立'},{id:'walk',label:'走姿'},{id:'sit',label:'坐姿'},{id:'lie',label:'躺姿'},{id:'prone',label:'趴着'}];

export function createPosePreset(mesh, id) {
  if(!POSE_PRESETS.some(p=>p.id===id))throw new RangeError('未知姿势预设。');
  const frame=legacyPoseFrame(id==='lie'||id==='prone'?'stand':id,id==='walk'?1/(.85*4):2);
  if(id==='stand'||id==='lie'||id==='prone'){
    frame.value={'upperArm.L':[0,0,-22],'upperArm.R':[0,0,22],'forearm.L':[-6,0,0],'forearm.R':[-6,0,0]};
  }
  if(id==='lie')frame.root.rotation=[-90,0,0];
  if(id==='prone'){frame.root.rotation=[90,0,0];frame.value.head=[-12,0,0];}
  if(mesh){
    const rig=evaluateRig(mesh,{pose:frame.value,root:frame.root.position,rootRotation:frame.root.rotation});
    const xyz=skinCPU(mesh,rig.matrices);let minY=Infinity;
    for(let i=1;i<xyz.length;i+=4)minY=Math.min(minY,xyz[i]);
    frame.root.position[1]+=.008-minY;
  }
  return frame;
}

/** Evaluate only the small skeleton. Vertex skinning stays on the GPU during simulation. */
export function evaluateRig(mesh, { clip = 'stand', time = 0, speed = 1, pose = {}, root = [0, 0, 0], jointOffsets = {}, rootRotation = [0, 0, 0] } = {}) {
  const frame=legacyPoseFrame(clip,time,speed),animation=frame.value,offset=root.map((v,i)=>v+frame.root.position[i]);
  const matrices = new Float32Array(mesh.bones.length * 16), worldMatrices = new Float32Array(matrices.length), joints = [], world = [];
  mesh.bones.forEach((bone, index) => {
    const parent = bone.parent >= 0 ? mesh.bones[bone.parent] : null;
    const jointOffset = jointOffsets[bone.name] || [0, 0, 0];
    const translation = bone.position.map((value, axis) => (parent ? value - parent.position[axis] : value + offset[axis]) + (jointOffset[axis] || 0));
    const animated = animation[bone.name] || [0, 0, 0], adjustment = pose[bone.name] || [0, 0, 0];
    const local = transform(translation, animated.map((value, axis) => value + (adjustment[axis] || 0)));
    // Root orientation is composed, not added to authored Euler angles: pivot stays at the hips.
    const global = parent ? multiply(world[bone.parent], local)
      : multiply(transform(translation, rootRotation), transform([0, 0, 0], animated.map((value, axis) => value + (adjustment[axis] || 0))));
    world.push(global);
    worldMatrices.set(global, index * 16);
    joints.push([global[12], global[13], global[14]]);
    const skin = global.slice();
    for (let row = 0; row < 3; row++) {
      skin[12 + row] -= global[row] * bone.position[0] + global[4 + row] * bone.position[1] + global[8 + row] * bone.position[2];
    }
    matrices.set(skin, index * 16);
  });
  return { matrices, joints, worldMatrices };
}

/** CPU skinning is deliberately an explicit utility for tests and reset, not the live frame loop. */
export function skinCPU(mesh, matrices) {
  const result = new Float32Array(mesh.positions.length);
  for (let vertex = 0; vertex < mesh.vertexCount; vertex++) {
    const index = vertex * 4, x = mesh.positions[index], y = mesh.positions[index + 1], z = mesh.positions[index + 2];
    for (let influence = 0; influence < 4; influence++) {
      const weight = mesh.boneWeights[index + influence];
      if (!weight) continue;
      const m = mesh.boneIndices[index + influence] * 16;
      for (let axis = 0; axis < 3; axis++) result[index + axis] += weight * (matrices[m + axis] * x + matrices[m + 4 + axis] * y + matrices[m + 8 + axis] * z + matrices[m + 12 + axis]);
    }
    result[index + 3] = 1;
  }
  return result;
}
