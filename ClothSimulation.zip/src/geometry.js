export const BODY_PRESETS = [
  { id: 'fat', label: '肥胖' },
  { id: 'chubby', label: '壮胖' },
  { id: 'muscular', label: '肌肉' },
  { id: 'regular', label: '标准' },
  { id: 'skinny', label: '纤瘦' },
];

export const DENSITIES = [
  { id: 0, label: '低' },
  { id: 1, label: '中' },
  { id: 2, label: '高' },
];

const SHAPES = {
  fat: { shoulder: .231, chest: .222, waist: .29, hip: .261, depth: .177, belly: .245, arm: .090, thigh: .121, calf: .078, head: 1.065, neck: 1.22, muscle: .35, softness: 1 },
  chubby: { shoulder: .219, chest: .205, waist: .225, hip: .227, depth: .151, belly: .178, arm: .078, thigh: .104, calf: .067, head: 1.035, neck: 1.14, muscle: .5, softness: .58 },
  muscular: { shoulder: .204, chest: .194, waist: .162, hip: .194, depth: .137, belly: .104, arm: .087, thigh: .102, calf: .070, head: 1, neck: 1.10, muscle: 1, softness: 0 },
  regular: { shoulder: .184, chest: .164, waist: .157, hip: .181, depth: .117, belly: .106, arm: .063, thigh: .080, calf: .055, head: 1, neck: 1, muscle: .23, softness: .12 },
  skinny: { shoulder: .162, chest: .141, waist: .120, hip: .148, depth: .091, belly: .077, arm: .038, thigh: .057, calf: .041, head: .98, neck: .87, muscle: .16, softness: 0 },
};

export function normalizeBodyWeights(weights = {}, fallback = 'regular') {
  const result = Object.fromEntries(BODY_PRESETS.map(({ id }) => [id, Number.isFinite(weights?.[id]) ? Math.max(0, weights[id]) : 0]));
  const maximum = Math.max(...Object.values(result));
  if (!maximum) {
    result[Object.hasOwn(SHAPES, fallback) ? fallback : 'regular'] = 1;
    return result;
  }
  const sum = Object.values(result).reduce((total, value) => total + value / maximum, 0);
  for (const id in result) result[id] = result[id] / maximum / sum;
  return result;
}
const TAU = Math.PI * 2;
const add = (a, b) => a.map((v, i) => v + b[i]);
const mul = (a, s) => a.map(v => v * s);
const mix = (a, b, t) => a.map((v, i) => v * (1 - t) + b[i] * t);
const unit = a => mul(a, 1 / Math.hypot(...a));
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const edgeKey = (a, b) => a < b ? `${a},${b}` : `${b},${a}`;

function weighted(vertices, factors) {
  const p = [0, 0, 0], w = {};
  for (let i = 0; i < vertices.length; i++) {
    const v = vertices[i], f = factors ? factors[i] : 1 / vertices.length;
    for (let k = 0; k < 3; k++) p[k] += v.p[k] * f;
    for (const bone in v.w) w[bone] = (w[bone] || 0) + v.w[bone] * f;
  }
  return { p, w };
}

function orientFaces(vertices, faces) {
  const edges = new Map(), neighbors = Array.from({ length: faces.length }, () => []);
  faces.forEach((face, fi) => {
    face.forEach((a, i) => {
      const b = face[(i + 1) % face.length], key = edgeKey(a, b);
      const list = edges.get(key) || [];
      list.push({ fi, direction: a < b ? 1 : -1 });
      edges.set(key, list);
    });
  });
  for (const [key, list] of edges) {
    if (list.length !== 2) throw new Error(`Cage edge ${key} has ${list.length} faces`);
    const [a, b] = list, flip = a.direction === b.direction;
    neighbors[a.fi].push([b.fi, flip]);
    neighbors[b.fi].push([a.fi, flip]);
  }
  const flips = new Int8Array(faces.length).fill(-1), queue = [0];
  flips[0] = 0;
  for (let qi = 0; qi < queue.length; qi++) {
    const fi = queue[qi];
    for (const [other, different] of neighbors[fi]) {
      const expected = flips[fi] ^ Number(different);
      if (flips[other] < 0) { flips[other] = expected; queue.push(other); }
      else if (flips[other] !== expected) throw new Error('Non-orientable cage');
    }
  }
  if (queue.length !== faces.length) throw new Error('Disconnected cage');
  faces.forEach((face, i) => { if (flips[i]) face.reverse(); });
  let volume = 0;
  for (const f of faces) for (let i = 1; i + 1 < f.length; i++) {
    const a = vertices[f[0]].p, b = vertices[f[i]].p, c = vertices[f[i + 1]].p;
    const n = cross(b, c);
    volume += (a[0] * n[0] + a[1] * n[1] + a[2] * n[2]) / 6;
  }
  if (volume < 0) faces.forEach(f => f.reverse());
}

function subdivide(vertices, faces, seamPath) {
  const next = vertices.map(v => ({ p: v.p.slice(), w: { ...v.w } }));
  const facePoints = faces.map(f => weighted(f.map(i => vertices[i])));
  const faceOffset = next.length;
  next.push(...facePoints);
  const edges = new Map();
  const incidentFaces = Array.from({ length: vertices.length }, () => []);
  const incidentEdges = Array.from({ length: vertices.length }, () => []);
  faces.forEach((face, fi) => {
    face.forEach((a, i) => {
      incidentFaces[a].push(fi);
      const b = face[(i + 1) % face.length], key = edgeKey(a, b);
      let edge = edges.get(key);
      if (!edge) {
        edge = { a, b, faces: [] };
        edges.set(key, edge);
        incidentEdges[a].push(edge);
        incidentEdges[b].push(edge);
      }
      edge.faces.push(fi);
    });
  });
  for (const edge of edges.values()) {
    edge.index = next.length;
    edge.mid = weighted([vertices[edge.a], vertices[edge.b]]);
    next.push(weighted([vertices[edge.a], vertices[edge.b], ...edge.faces.map(i => facePoints[i])]));
  }
  for (let i = 0; i < vertices.length; i++) {
    const n = incidentEdges[i].length;
    const f = weighted(incidentFaces[i].map(j => facePoints[j]));
    const r = weighted(incidentEdges[i].map(e => e.mid));
    next[i] = weighted([f, r, vertices[i]], [1 / n, 2 / n, (n - 3) / n]);
  }
  const quads = [];
  faces.forEach((face, fi) => face.forEach((a, i) => {
    const b = face[(i + 1) % face.length], prev = face[(i + face.length - 1) % face.length];
    quads.push([a, edges.get(edgeKey(a, b)).index, faceOffset + fi, edges.get(edgeKey(prev, a)).index]);
  }));
  const path = [];
  seamPath.forEach((a, i) => {
    path.push(a);
    if (i + 1 < seamPath.length) path.push(edges.get(edgeKey(a, seamPath[i + 1])).index);
  });
  return { vertices: next, faces: quads, seamPath: path };
}

function slitSpine(vertices, faces, path) {
  const pathEdges = new Set();
  for (let i = 0; i + 1 < path.length; i++) pathEdges.add(edgeKey(path[i], path[i + 1]));
  const seamVertices = new Set(path.slice(1, -1));
  const incident = new Map([...seamVertices].map(i => [i, []]));
  faces.forEach((face, fi) => face.forEach(v => incident.get(v)?.push(fi)));
  const replacements = new Map(), pairs = [];
  for (const v of seamVertices) {
    const around = incident.get(v), adjacency = new Map(around.map(fi => [fi, []])), edges = new Map();
    for (const fi of around) {
      const face = faces[fi], index = face.indexOf(v);
      for (const other of [face[(index + 1) % face.length], face[(index + face.length - 1) % face.length]]) {
        const key = edgeKey(v, other);
        if (!pathEdges.has(key)) {
          const list = edges.get(key) || [];
          list.push(fi); edges.set(key, list);
        }
      }
    }
    for (const list of edges.values()) if (list.length === 2) {
      adjacency.get(list[0]).push(list[1]); adjacency.get(list[1]).push(list[0]);
    }
    let seed = around[0], best = -Infinity;
    for (const fi of around) {
      const x = faces[fi].reduce((sum, vi) => sum + vertices[vi].p[0], 0);
      if (x > best) { best = x; seed = fi; }
    }
    const selected = new Set([seed]), queue = [seed];
    for (let i = 0; i < queue.length; i++) for (const fi of adjacency.get(queue[i])) {
      if (!selected.has(fi)) { selected.add(fi); queue.push(fi); }
    }
    const duplicate = vertices.length;
    vertices.push({ p: vertices[v].p.slice(), w: { ...vertices[v].w } });
    pairs.push(v, duplicate);
    for (const fi of selected) {
      if (!replacements.has(fi)) replacements.set(fi, new Map());
      replacements.get(fi).set(v, duplicate);
    }
  }
  for (const [fi, map] of replacements) faces[fi] = faces[fi].map(v => map.get(v) ?? v);
  return new Uint32Array(pairs);
}

/** A sewn, genus-zero cage: every appendage replaces a surface patch, never overlaps a separate solid. */
function generateEndpoint(preset, density, seam) {
  const s = SHAPES[preset], bones = [], boneMap = {}, vertices = [], faces = [];
  const bone = (name, parent, position) => {
    const index = bones.length;
    bones.push({ name, parent: parent === null ? -1 : boneMap[parent], position });
    boneMap[name] = index; return index;
  };
  bone('hips', null, [0, .94, 0]);
  bone('spine', 'hips', [0, 1.10, 0]);
  bone('chest', 'spine', [0, 1.38, 0]);
  bone('neck', 'chest', [0, 1.578, 0]);
  bone('head', 'neck', [0, 1.667, -.004]);
  const weight = (a, b, t = .5) => b ? { [boneMap[a]]: 1 - t, [boneMap[b]]: t } : { [boneMap[a]]: 1 };
  const vertex = (p, w) => { vertices.push({ p, w }); return vertices.length - 1; };
  const ring = (points, w) => points.map(p => vertex(p, w));
  const tube = (a, b, skip = []) => {
    for (let i = 0; i < a.length; i++) if (!skip.includes(i)) faces.push([a[i], a[(i + 1) % a.length], b[(i + 1) % b.length], b[i]]);
  };
  const circle = (center, u, v, rx, ry, count, w, phase = 0) => ring(Array.from({ length: count }, (_, i) => {
    const a = i / count * TAU + phase;
    return add(center, add(mul(u, Math.cos(a) * rx), mul(v, Math.sin(a) * ry)));
  }), w);
  const rectCoordinates = n => {
    const result = [];
    for (let i = 0; i <= n; i++) result.push([i, 0]);
    for (let j = 1; j <= 2; j++) result.push([n, j]);
    for (let i = n - 1; i >= 0; i--) result.push([i, 2]);
    result.push([0, 1]); return result;
  };
  const rectangle = (center, u, v, width, height, n, w) => ring(rectCoordinates(n).map(([i, j]) => add(center, add(mul(u, (i / n - .5) * width), mul(v, (j / 2 - .5) * height)))), w);
  const gridEnd = (boundary, center, u, v, width, height, n, w) => {
    const indices = new Map(rectCoordinates(n).map(([i, j], k) => [`${i},${j}`, boundary[k]]));
    for (let i = 1; i < n; i++) indices.set(`${i},1`, vertex(add(center, mul(u, (i / n - .5) * width)), w));
    return i => [[i, 0], [i + 1, 0], [i + 1, 1], [i + 1, 2], [i, 2], [i, 1]].map(([x, y]) => indices.get(`${x},${y}`));
  };
  const alignPort = (port, center, u, v) => {
    const projected = port.map(i => {
      const p = add(vertices[i].p, mul(center, -1));
      return [p.reduce((sum, value, k) => sum + value * u[k], 0), p.reduce((sum, value, k) => sum + value * v[k], 0)];
    });
    const area = projected.reduce((sum, p, i) => {
      const q = projected[(i + 1) % projected.length];
      return sum + p[0] * q[1] - q[0] * p[1];
    }, 0);
    return area < 0 ? port.slice().reverse() : port;
  };
  const digit = (port, center, direction, u, v, length, radius, depth, name, parent) => {
    bone(name, parent, center);
    let previous = alignPort(port, center, u, v);
    const relative = add(vertices[previous[0]].p, mul(center, -1));
    const phase = Math.atan2(relative.reduce((sum, value, k) => sum + value * v[k], 0) / depth, relative.reduce((sum, value, k) => sum + value * u[k], 0) / radius);
    for (const [t, scale] of [[.18, 1], [.53, .94], [.86, .79], [1, .35]]) {
      const next = circle(add(center, mul(direction, length * t)), u, v, radius * scale, depth * scale, 6, weight(name), phase);
      tube(previous, next); previous = next;
    }
    faces.push(previous.slice());
  };

  // Ring boundaries at the shoulder ports and crotch are shared with the limb roots.
  const rows = [
    [.865, s.hip, s.depth * .98, -.008], [.96, s.hip * 1.04, s.depth * 1.04, .004],
    [1.095, s.waist, s.belly, .004 + .032 * s.softness], [1.275, (s.waist + s.chest) / 2, s.depth, .004],
    [1.405, s.chest, s.depth, -.004], [1.475, s.shoulder * .98, s.depth * 1.02, -.006],
    [1.527, s.shoulder * .73, s.depth * .72, -.008], [1.572, .058 * s.neck, .056 * s.neck, -.010],
    [1.641, .068 * s.head, .064 * s.head, .016], [1.685, .084 * s.head, .079 * s.head, .030],
    [1.723, .098 * s.head, .092 * s.head, -.003], [1.779, .098 * s.head, .098 * s.head, -.008],
    [1.837, .092 * s.head, .092 * s.head, -.014], [1.879, .059 * s.head, .060 * s.head, -.016],
  ];
  const torsoWeight = y => y < 1 ? weight('hips') : y < 1.2 ? weight('hips', 'spine', .8) : y < 1.42 ? weight('spine', 'chest', .8) : y < 1.56 ? weight('chest') : y < 1.65 ? weight('neck') : weight('head');
  const n = 20;
  const torso = rows.map(([y, rx, rz, z], row) => ring(Array.from({ length: n }, (_, i) => {
    const angle = i / n * TAU, front = Math.max(0, Math.sin(angle));
    const x = Math.cos(angle) * rx;
    // A flatter facial plane and broader mandibular corners replace the spherical lower head.
    const faceZ = row >= 8 && row <= 11 && front > 0 ? rz * front ** .48 : Math.sin(angle) * rz;
    const shoulderSlope = row === 6 ? .006 * Math.abs(Math.cos(angle)) : 0;
    const clavicleRound = row === 6 ? .009 * Math.sin(angle) ** 2 : 0;
    const shoulderDome = row===5 ? .034*Math.abs(Math.cos(angle))**2 : 0;
    const shoulderTopDepth = row===5 ? s.depth*.13*Math.abs(Math.cos(angle)) : 0;
    const underarm = row === 4 ? -.034 * Math.abs(Math.cos(angle)) ** 6 : 0;
    return [x, y + shoulderSlope + clavicleRound + shoulderDome + underarm + (row === 0 ? Math.abs(Math.cos(angle)) * .02 : 0), faceZ + z + (Math.cos(angle)>=0?shoulderTopDepth:-shoulderTopDepth)];
  }), y >= 1.64 ? weight('head') : y >= 1.57 ? weight('neck') : torsoWeight(y)));
  for (let j = 0; j + 1 < torso.length; j++) {
    for (let i = 0; i < n; i++) {
      const shoulderPort = (j === 4 || j === 5) && [18, 19, 0, 1, 8, 9, 10, 11].includes(i);
      const nosePort = j === 10 && (i === 4 || i === 5);
      if (!shoulderPort && !nosePort) faces.push([torso[j][i], torso[j][(i + 1) % n], torso[j + 1][(i + 1) % n], torso[j + 1][i]]);
    }
  }
  const top = vertex([0, 1.89, -.01], weight('head'));
  for (let i = 0; i < n; i++) faces.push([torso.at(-1)[i], torso.at(-1)[(i + 1) % n], top]);
  const patch = (row, start, width, height) => {
    const result = [];
    for (let i = 0; i <= width; i++) result.push(torso[row][(start + i) % n]);
    for (let j = 1; j <= height; j++) result.push(torso[row + j][(start + width) % n]);
    for (let i = width - 1; i >= 0; i--) result.push(torso[row + height][(start + i) % n]);
    for (let j = height - 1; j >= 1; j--) result.push(torso[row + j][start]);
    return result;
  };
  const noseRoot = patch(10, 4, 2, 1);
  const noseTip = ring([
    [.016, 1.731, .120], [0, 1.726, .140], [-.016, 1.731, .120],
    [-.010, 1.766, .109], [0, 1.774, .113], [.010, 1.766, .109],
  ].map(p => [p[0] * s.head, p[1], p[2] * s.head]), weight('head'));
  tube(noseRoot, noseTip); faces.push(noseTip.slice());

  for (const [suffix, side] of [['L', 1], ['R', -1]]) {
    const shoulder = [side * s.shoulder * .88, 1.515, -.006];
    const elbow = [side * (s.shoulder + .205), 1.224, -.012];
    const wrist = [side * (s.shoulder + .301), .997, .004];
    bone(`upperArm.${suffix}`, 'chest', shoulder);
    bone(`forearm.${suffix}`, `upperArm.${suffix}`, elbow);
    bone(`hand.${suffix}`, `forearm.${suffix}`, wrist);
    const direction = unit(add(wrist, mul(elbow, -1)));
    const u = [side * -direction[1], side * direction[0], 0], v = [0, 0, side];
    let armRoot = patch(4, side > 0 ? 18 : 8, 4, 2);
    // 腋下与肩环渐变跟随上臂；肩口顶边留在胸骨，避免手臂动作牵拉颈根。
    for (const i of armRoot) vertices[i].w = weight('chest', `upperArm.${suffix}`, vertices[i].p[1] > 1.5 ? 0 : .45);
    const rootCenter = weighted(armRoot.map(i => vertices[i])).p;
    // 肩口沿用固定绕序，避免宽胸窄肩端点改变投影方向后翻转顶点对应。
    armRoot.reverse();
    // Match circle phase to the shoulder boundary, avoiding a twisted branch.
    const rel = add(vertices[armRoot[0]].p, mul(rootCenter, -1));
    const phase = Math.atan2(rel[2] * side, rel[0] * u[0] + rel[1] * u[1]);
    let previous = armRoot;
    const armRings = [
      [[side * (s.shoulder + s.arm * .80), 1.486, -.005], s.arm * 1.10, s.arm * 1.12, weight('chest', `upperArm.${suffix}`, .60)],
      [add(mix(shoulder, elbow, .57), [0, 0, .011 * s.muscle]), s.arm, s.arm * (1 + .20 * s.muscle), weight(`upperArm.${suffix}`)],
      [elbow, s.arm * .67, s.arm * .74, weight(`upperArm.${suffix}`, `forearm.${suffix}`)],
      [mix(elbow, wrist, .35), s.arm * .86, s.arm * .91, weight(`forearm.${suffix}`)],
      [mix(elbow, wrist, .89), .020 + s.arm * .15, .022 + s.arm * .15, weight(`forearm.${suffix}`, `hand.${suffix}`, .2)],
    ];
    for (const [center, radius, depth, w] of armRings) {
      const next = circle(center, u, v, radius, depth, 12, w, phase);
      tube(previous, next); previous = next;
    }
    // Keep cyclic correspondence identical across presets for recorded surface attachments.
    const palmBase = rectangle(wrist, u, v, .065, .035, 4, weight(`hand.${suffix}`));
    previous = [...previous.slice(10), ...previous.slice(0, 10)];
    tube(previous, palmBase);
    const palmMiddleCenter = add(wrist, mul(direction, .038));
    const palmEndCenter = add(wrist, mul(direction, .082));
    const palmMiddle = rectangle(palmMiddleCenter, u, v, .090, .036, 4, weight(`hand.${suffix}`));
    const palmEnd = rectangle(palmEndCenter, u, v, .092, .030, 4, weight(`hand.${suffix}`));
    tube(palmBase, palmMiddle, [10, 11]); tube(palmMiddle, palmEnd);
    const fingerPort = gridEnd(palmEnd, palmEndCenter, u, v, .092, .03, 4, weight(`hand.${suffix}`));
    const fingerNames = ['index', 'middle', 'ring', 'little'], lengths = [.073, .083, .077, .060];
    for (let i = 0; i < 4; i++) {
      const center = add(palmEndCenter, mul(u, ((i + .5) / 4 - .5) * .092));
      const spread = unit(add(direction, mul(u, (i - 1.5) * .11)));
      digit(fingerPort(i), center, spread, u, v, lengths[i], .010, .0105, `${fingerNames[i]}.${suffix}`, `hand.${suffix}`);
    }
    const thumbPort = [palmBase[10], palmBase[11], palmBase[0], palmMiddle[0], palmMiddle[11], palmMiddle[10]];
    const thumbCenter = weighted(thumbPort.map(i => vertices[i])).p;
    const thumbDirection = unit(add(mul(u, -.82), mul(direction, .57)));
    const thumbU = unit(add(mul(direction, .82), mul(u, .57)));
    digit(thumbPort, thumbCenter, thumbDirection, thumbU, v, .069, .0135, .012, `thumb.${suffix}`, `hand.${suffix}`);
  }

  const crotch = [];
  for (let j = 1; j < 4; j++) crotch.push(vertex([0, .815 + Math.abs(j - 2) * .008, s.depth * 1.02 * (1 - j / 2)], weight('hips')));
  for (const [suffix, side] of [['L', 1], ['R', -1]]) {
    const hipX = s.hip * .56;
    const hip = [side * hipX, .89, -.006], knee = [side * hipX, .50, .009], ankle = [side * hipX, .125, .006];
    bone(`thigh.${suffix}`, 'hips', hip);
    bone(`shin.${suffix}`, `thigh.${suffix}`, knee);
    bone(`foot.${suffix}`, `shin.${suffix}`, ankle);
    const root = side > 0
      ? [...Array.from({ length: 11 }, (_, i) => torso[0][(15 + i) % n]), ...crotch]
      : [...Array.from({ length: 11 }, (_, i) => torso[0][(5 + i) % n]), ...crotch.slice().reverse()];
    // Both leg rings use the same cyclic correspondence as their half-pelvis openings.
    const startAngle = side > 0 ? -Math.PI / 2 : Math.PI / 2;
    let previous = root;
    const legRings = [
      [[side * hipX, .805, -.005], s.thigh, s.thigh * 1.08, weight('hips', `thigh.${suffix}`, .85)],
      [[side * hipX, .69, .007], s.thigh * .98, s.thigh * (1.07 + .10 * s.muscle), weight(`thigh.${suffix}`)],
      [[side * (hipX - .006 * s.muscle), .555, .020], s.thigh * .76, s.thigh * .82, weight(`thigh.${suffix}`, `shin.${suffix}`, .15)],
      [knee, s.thigh * .60, s.thigh * .63, weight(`thigh.${suffix}`, `shin.${suffix}`)],
      [[side * (hipX + .004), .385, -.013], s.calf, s.calf * 1.16, weight(`shin.${suffix}`)],
      [[side * hipX, .235, -.010], s.calf * .67, s.calf * .79, weight(`shin.${suffix}`)],
      [ankle, .026 + s.calf * .13, .034 + s.calf * .14, weight(`shin.${suffix}`, `foot.${suffix}`, .7)],
    ];
    for (const [center, rx, rz, w] of legRings) {
      const next = circle(center, [1, 0, 0], [0, 0, 1], rx, rz, 14, w, startAngle);
      tube(previous, next); previous = next;
    }
    const footCenter = [side * hipX, .036, .043], footEndCenter = [side * hipX, .042, .139];
    const footWidth = .116, footHeight = .048, u = [1, 0, 0], v = [0, 1, 0];
    const footBase = rectangle(footCenter, u, v, .080, .050, 5, weight(`foot.${suffix}`));
    for (const id of footBase) {
      const p = vertices[id].p, height = (p[1] - .030) / .050, across = Math.abs(p[0] - side * hipX) / .040;
      p[2] = -.018 + height * .084 - .004 * (1 - across * across);
    }
    // Ankle horizontal rings turn through ninety degrees into the foot's vertical rings.
    const desired = side > 0 ? 0 : 7;
    previous = [...previous.slice(desired), ...previous.slice(0, desired)];
    tube(previous, footBase);
    const footEnd = rectangle(footEndCenter, u, v, footWidth, footHeight, 5, weight(`foot.${suffix}`));
    for (const id of footEnd) {
      const p=vertices[id].p, across=Math.abs(p[0]-side*hipX)/(footWidth*.5);
      const round=Math.sqrt(Math.max(0,1-across*across));
      p[1]=.012+(p[1]-.012)*(.55+.45*round);
      p[2]-=.004*across*across;
    }
    tube(footBase, footEnd);
    const toePort = gridEnd(footEnd, footEndCenter, u, v, footWidth, footHeight, 5, weight(`foot.${suffix}`));
    for (let i = 0; i < 5; i++) {
      const rank = side > 0 ? i : 4 - i;
      const port=toePort(i),toeStart=[port.reduce((sum,id)=>sum+vertices[id].p[0],0)/port.length,footEndCenter[1]+.006,footEndCenter[2]+.012];
      const toeDepth=rank===0?.012:.010,toeWidth=rank===0?.0105:.0085;
      for(const vertexId of port){const q=vertices[vertexId].p;q[2]=toeStart[2];q[0]+=.55*(toeStart[0]-q[0]);}
      digit(port, toeStart, [0, -.04, 1], u, v, [.042,.039,.035,.030,.026][rank], toeWidth, toeDepth, `toe${rank + 1}.${suffix}`, `foot.${suffix}`);
    }
  }

  const used = new Set(faces.flat()), remap = new Map(), compactVertices = [];
  vertices.forEach((v, i) => { if (used.has(i)) { remap.set(i, compactVertices.length); compactVertices.push(v); } });
  const compactFaces = faces.map(face => face.map(i => remap.get(i)));
  orientFaces(compactVertices, compactFaces);
  let cage = { vertices: compactVertices, faces: compactFaces, seamPath: [2, 3, 4, 5, 6].map(i => remap.get(torso[i][15])) };
  for (let level = 0; level <= density; level++) cage = subdivide(cage.vertices, cage.faces, cage.seamPath);
  const gaussian = (value, center, width) => Math.exp(-(((value - center) / width) ** 2));
  const soleHeight = ([x, y, z]) => {
    if (y >= .1) return y;
    // 压平承重足底，保留足背厚度；只在内侧中足抬高轻微足弓。
    const rise = Math.max(0, Math.min(1, (y - .020) / .074));
    const soleScale = .22 + .78 * rise * rise * (3 - 2 * rise);
    const medial = gaussian(Math.abs(x) - s.hip * .56, -.021, .028);
    const arch = .007 * medial * gaussian(z, .052, .050) * gaussian(y, .025, .030) * (1 - rise);
    const base = .012 + (y - .012) * soleScale + arch;
    const heel=Math.max(0,Math.min(1,(-z-.010)/.050))*Math.max(0,Math.min(1,(.060-y)/.040));
    return base*(1-heel)+Math.min(y,.0145)*heel;
  };
  for (const joint of bones) joint.position[1] = soleHeight(joint.position);
  for (const { p, w } of cage.vertices) {
    const [x, y, z] = p, front = Math.max(0, Math.min(1, z / (s.depth * .65)));
    const torsoInfluence = (w[boneMap.hips] || 0) + (w[boneMap.spine] || 0) + (w[boneMap.chest] || 0);
    const soft=Math.min(1,Math.max(0,(s.softness-.45)/.55));
    const pec = gaussian(Math.abs(x), s.chest * .55, s.chest * (.39 + .10 * soft)) * gaussian(y, 1.395-soft*.035, .080 + .015 * soft);
    const lowerPec=gaussian(Math.abs(x),s.chest*.51,s.chest*(.34+.08*soft))*gaussian(y,1.362-soft*.035,.049+.015*soft);
    const belly = gaussian(x, 0, s.waist * .87) * gaussian(y, 1.065-soft*.040, .132+.008*soft);
    const hangingBelly=gaussian(x,0,s.waist*.76)*gaussian(y,1.002,.080);
    const foldY=1.008+.020*Math.min(1,Math.abs(x)/Math.max(.01,s.waist));
    const bellyFold=gaussian(x,0,s.waist*.72)*gaussian(y,foldY,.018);
    const subPecFold=gaussian(Math.abs(x),s.chest*.51,s.chest*.33)*gaussian(y,1.335-soft*.045,.018);
    const sternum = gaussian(x, 0, .020) * gaussian(y, 1.413, .090);
    const abs = gaussian(Math.abs(x), .047, .030) * (gaussian(y, 1.16, .033) + gaussian(y, 1.238, .032) + gaussian(y, 1.307, .030));
    const chestFold = gaussian(Math.abs(x), s.chest * .47, s.chest * .38) * gaussian(y, 1.324, .027);
    const coveredPelvis = gaussian(x, 0, .060 + .018 * s.softness) * gaussian(y, .891, .062);
    p[2] += torsoInfluence * front * ((.008 + .045 * s.muscle + .034 * s.softness + .035*soft) * pec + .012*soft*lowerPec - .010 * s.muscle * sternum + (.082 * s.softness+.022*soft) * belly+.026*soft*hangingBelly - .009 * s.muscle * abs - .009 * s.softness * chestFold + (.019 + .004 * s.softness) * coveredPelvis);
    p[1]-=torsoInfluence*front*(.032*soft*lowerPec+.026*soft*hangingBelly);
    p[2]-=torsoInfluence*front*soft*(.004*subPecFold+.003*bellyFold);
    if (z < 0) p[2] -= torsoInfluence * Math.min(1, -z / s.depth) * (.015 * gaussian(y, .927, .090) + .010 * s.muscle * gaussian(Math.abs(x), .058, .034) * gaussian(y, 1.31, .19));
    const headInfluence = w[boneMap.head] || 0;
    if (headInfluence > .1) {
      const chin = gaussian(x, 0, .036 * s.head) * gaussian(y, 1.676, .018);
      const jawPad = gaussian(Math.abs(x), .054 * s.head, .026 * s.head) * gaussian(y, 1.674, .020);
      const jawAngle = gaussian(Math.abs(x), .066 * s.head, .016 * s.head) * gaussian(y, 1.674, .020) * gaussian(z, .012 * s.head, .027 * s.head);
      const submental = gaussian(x, 0, .059 * s.head) * gaussian(y, 1.652, .010);
      // 颏尖保持收敛，下颌缘连续过渡到两侧，避免下巴向前突出。
      p[2] += headInfluence * front * (.020 * chin + .010 * jawPad - .012 * submental);
      const jawEdgeY=1.660+.035*Math.min(1,Math.abs(x)/(.075*s.head));
      const jawEdgeZ=.103*s.head-1.12*Math.abs(x);
      const jawLine=gaussian(y,jawEdgeY,.012)*gaussian(z,jawEdgeZ,.020);
      p[2]+=headInfluence*(.006*jawLine+.005*jawAngle);
      p[1]-=headInfluence*(.004*jawLine+.005*jawAngle);
      p[0]+=Math.sign(x)*headInfluence*.006*jawAngle;
      if (y > 1.643 && y < 1.689 && Math.abs(x) < .082 * s.head) {
        p[1] -= .006 * chin;
        p[2] += .009 * Math.max(0, -z / (.05 * s.head)) * submental;
      }
    }
    p[0] += Math.sign(x) * headInfluence * .010 * gaussian(Math.abs(x), .092 * s.head, .018) * gaussian(y, 1.753, .022) * gaussian(z, -.009, .030);
    p[1] = soleHeight(p);
  }
  const seamPairs = seam ? slitSpine(cage.vertices, cage.faces, cage.seamPath) : new Uint32Array();
  const count = cage.vertices.length;
  const positions = new Float32Array(count * 4), normals = new Float32Array(count * 4);
  const boneIndices = new Uint32Array(count * 4), boneWeights = new Float32Array(count * 4);
  cage.vertices.forEach((v, i) => {
    if (v.p[1] > 1.5701 && v.p[1] < 1.64) v.w = weight('neck');
    positions.set([...v.p, 1], i * 4);
    const weights = Object.entries(v.w).filter(([, w]) => w > 1e-8).sort((a, b) => b[1] - a[1]).slice(0, 4);
    const total = weights.reduce((sum, [, w]) => sum + w, 0);
    weights.forEach(([b, w], k) => { boneIndices[i * 4 + k] = Number(b); boneWeights[i * 4 + k] = w / total; });
  });
  const triangles = [];
  for (const face of cage.faces) for (let i = 1; i + 1 < face.length; i++) triangles.push(face[0], face[i], face[i + 1]);
  const indices = new Uint32Array(triangles);
  const restVolume = measureSurface(positions, indices, normals);
  return {
    positions, indices, normals, boneIndices, boneWeights, seamPairs, bones,
    vertexCount: count, triangleCount: indices.length / 3, restVolume,
    metadata: {
      preset, density, seam, topologyVersion: 1, height: 1.89, headCenter: [0, 1.766, -.008],
      headSize: [.098 * s.head, .120, .098 * s.head], faceLandmarks: { eyeY: 1.774, mouthY: 1.695, noseY: 1.738, chinY: 1.646 }, boxerMin: .79, boxerMax: 1.035,
      digitCount: { fingers: 10, toes: 10 }, connectedShells: 1,
      seamPath: Uint32Array.from(cage.seamPath), subdivisionLevels: density + 1,
    },
  };
}

function measureSurface(positions, indices, normals) {
  normals.fill(0);
  let volume = 0;
  for (let i = 0; i < indices.length; i += 3) {
    const a = indices[i] * 4, b = indices[i + 1] * 4, c = indices[i + 2] * 4;
    const ax = positions[a], ay = positions[a + 1], az = positions[a + 2];
    const bx = positions[b], by = positions[b + 1], bz = positions[b + 2];
    const cx = positions[c], cy = positions[c + 1], cz = positions[c + 2];
    const nx = (by - ay) * (cz - az) - (bz - az) * (cy - ay);
    const ny = (bz - az) * (cx - ax) - (bx - ax) * (cz - az);
    const nz = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax);
    for (const vertex of [a, b, c]) {
      normals[vertex] += nx; normals[vertex + 1] += ny; normals[vertex + 2] += nz;
    }
    volume += (ax * (by * cz - bz * cy) + ay * (bz * cx - bx * cz) + az * (bx * cy - by * cx)) / 6;
  }
  for (let i = 0; i < positions.length; i += 4) {
    const length = Math.hypot(normals[i], normals[i + 1], normals[i + 2]) || 1;
    for (let k = 0; k < 3; k++) normals[i + k] /= length;
  }
  return volume;
}

// At most five endpoint meshes are retained, including across density/seam changes.
const endpointCache = new Map();
function endpoint(preset, density, seam) {
  const key = `${preset}:${density}:${Boolean(seam)}`;
  let mesh = endpointCache.get(key);
  if (mesh) endpointCache.delete(key);
  else mesh = generateEndpoint(preset, density, seam);
  endpointCache.set(key, mesh);
  if (endpointCache.size > 5) endpointCache.delete(endpointCache.keys().next().value);
  return mesh;
}

export function generateHumanoid({ preset = 'regular', density = 0, seam = false, bodyWeights } = {}) {
  if (!Object.hasOwn(SHAPES, preset)) throw new RangeError(`Unknown body preset: ${preset}`);
  if (![0, 1, 2].includes(density)) throw new RangeError('Density must be 0, 1, or 2');
  const normalized = normalizeBodyWeights(bodyWeights, preset);
  const sources = Object.entries(normalized).filter(([, weight]) => weight > 0).map(([id, weight]) => ({ mesh: endpoint(id, density, seam), weight }));
  const base = sources[0].mesh;
  const mesh = {
    ...base,
    positions: base.positions.slice(), normals: base.normals.slice(), indices: base.indices.slice(),
    boneIndices: base.boneIndices.slice(), boneWeights: base.boneWeights.slice(), seamPairs: base.seamPairs.slice(),
    bones: base.bones.map(bone => ({ ...bone, position: bone.position.slice() })),
    metadata: {
      ...base.metadata, preset, bodyWeights: normalized,
      headCenter: base.metadata.headCenter.slice(), headSize: base.metadata.headSize.slice(),
      faceLandmarks: { ...base.metadata.faceLandmarks }, digitCount: { ...base.metadata.digitCount }, seamPath: base.metadata.seamPath.slice(),
    },
  };
  if (sources.length > 1) {
    // Blend the actual endpoint vertices, not shape parameters: all indexed surface attachments remain stable.
    for (let i = 0; i < mesh.positions.length; i += 4) for (let axis = 0; axis < 3; axis++) {
      mesh.positions[i + axis] = sources.reduce((value, source) => value + source.mesh.positions[i + axis] * source.weight, 0);
    }
    mesh.bones.forEach((bone, index) => {
      bone.position = bone.position.map((_, axis) => sources.reduce((value, source) => value + source.mesh.bones[index].position[axis] * source.weight, 0));
    });
    for (const key of ['headCenter', 'headSize']) mesh.metadata[key] = mesh.metadata[key].map((_, axis) => sources.reduce((value, source) => value + source.mesh.metadata[key][axis] * source.weight, 0));
    mesh.restVolume = measureSurface(mesh.positions, mesh.indices, mesh.normals);
  }
  return mesh;
}

export function validateMesh(mesh, { throwOnError = false } = {}) {
  const { positions, indices, boneIndices, boneWeights, bones } = mesh;
  const errors = [], count = positions.length / 4, edges = new Map();
  const adjacency = Array.from({ length: count }, () => []);
  let volume = 0, degenerateTriangles = 0, invalidIndices = 0;
  for (let i = 0; i < indices.length; i += 3) {
    const ids = [indices[i], indices[i + 1], indices[i + 2]];
    if (ids.some(id => id >= count)) { invalidIndices++; continue; }
    const [a, b, c] = ids.map(id => Array.from(positions.subarray(id * 4, id * 4 + 3)));
    const normal = cross(add(b, mul(a, -1)), add(c, mul(a, -1)));
    if (Math.hypot(...normal) < 1e-12) degenerateTriangles++;
    const bc = cross(b, c); volume += (a[0] * bc[0] + a[1] * bc[1] + a[2] * bc[2]) / 6;
    for (let k = 0; k < 3; k++) {
      const aId = ids[k], bId = ids[(k + 1) % 3], key = edgeKey(aId, bId);
      const edge = edges.get(key) || { count: 0, direction: 0 };
      edge.count++; edge.direction += aId < bId ? 1 : -1; edges.set(key, edge);
      adjacency[aId].push(bId); adjacency[bId].push(aId);
    }
  }
  let boundaryEdges = 0, nonManifoldEdges = 0, inconsistentWinding = 0;
  for (const edge of edges.values()) {
    if (edge.count === 1) boundaryEdges++;
    else if (edge.count !== 2) nonManifoldEdges++;
    else if (edge.direction !== 0) inconsistentWinding++;
  }
  let components = 0;
  const visited = new Uint8Array(count);
  for (let start = 0; start < count; start++) if (!visited[start]) {
    components++; visited[start] = 1;
    const queue = [start];
    for (let i = 0; i < queue.length; i++) for (const other of adjacency[queue[i]]) if (!visited[other]) {
      visited[other] = 1; queue.push(other);
    }
  }
  let invalidWeights = 0, nonFiniteVertices = 0;
  for (let i = 0; i < count; i++) {
    if (![positions[i * 4], positions[i * 4 + 1], positions[i * 4 + 2]].every(Number.isFinite)) nonFiniteVertices++;
    if (boneWeights && boneIndices && bones) {
      let sum = 0, invalid = false;
      for (let k = 0; k < 4; k++) {
        const w = boneWeights[i * 4 + k]; sum += w;
        if (!Number.isFinite(w) || w < 0 || boneIndices[i * 4 + k] >= bones.length) invalid = true;
      }
      if (invalid || Math.abs(sum - 1) > 1e-5) invalidWeights++;
    }
  }
  const expectedBoundaryEdges = mesh.metadata?.seam ? (mesh.metadata.seamPath.length - 1) * 2 : 0;
  if (invalidIndices) errors.push(`${invalidIndices} invalid triangle indices`);
  if (degenerateTriangles) errors.push(`${degenerateTriangles} degenerate triangles`);
  if (nonFiniteVertices) errors.push(`${nonFiniteVertices} non-finite vertices`);
  if (components !== 1) errors.push(`${components} connected components`);
  if (boundaryEdges !== expectedBoundaryEdges) errors.push(`${boundaryEdges} boundary edges; expected ${expectedBoundaryEdges}`);
  if (nonManifoldEdges) errors.push(`${nonManifoldEdges} non-manifold edges`);
  if (inconsistentWinding) errors.push(`${inconsistentWinding} inconsistently wound edges`);
  if (invalidWeights) errors.push(`${invalidWeights} invalid skin weights`);
  if (!(volume > 0)) errors.push('Non-positive volume');
  const report = { valid: errors.length === 0, errors, volume, boundaryEdges, nonManifoldEdges, inconsistentWinding, components, degenerateTriangles, invalidWeights, vertexCount: count, triangleCount: indices.length / 3, eulerCharacteristic: count - edges.size + indices.length / 3 };
  if (throwOnError && errors.length) throw new Error(errors.join('; '));
  return report;
}
