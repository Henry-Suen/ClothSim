struct Parameters {
  counts: vec4<u32>,
  offsets: vec4<u32>,
  scratch: vec4<u32>,
  control: vec4<f32>,
  material: vec4<f32>,
  cloth: vec4<f32>,
  sceneInfo: vec4<u32>,
  grabPoint: vec4<f32>,
  grabBary: vec4<f32>,
  resetOffset: vec4<f32>,
  rayOrigin: vec4<f32>,
  rayDirection: vec4<f32>,
  settings: vec4<f32>,
  surface: vec4<u32>,
  surfaceScratch: vec4<u32>,
}
struct Vertex {
  rest: vec4<f32>,
  previous: vec4<f32>,
  velocity: vec4<f32>,
  skinned: vec4<f32>,
  boneIds: vec4<u32>,
  boneWeights: vec4<f32>,
  ranges: vec4<u32>,
  contact: vec4<f32>,
  gradient: vec4<f32>,
  baseNormal: vec4<f32>,
}
struct Constraint {
  ids: vec4<u32>,
  rest: f32,
  kind: u32,
  lambda: f32,
  spare: f32,
  deltaA: vec4<f32>,
  deltaB: vec4<f32>,
  deltaC: vec4<f32>,
  deltaD: vec4<f32>,
}
@group(0) @binding(0) var<uniform> params: Parameters;
@group(0) @binding(1) var<storage, read_write> positions: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> normals: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> vertices: array<Vertex>;
@group(0) @binding(4) var<storage, read_write> constraints: array<Constraint>;
@group(0) @binding(5) var<storage, read> topology: array<u32>;
@group(0) @binding(6) var<storage, read> scene: array<vec4<f32>>;
@group(0) @binding(7) var<storage, read_write> scratch: array<atomic<u32>>;
@group(0) @binding(8) var<storage, read_write> grabPatch: array<vec4<f32>>;

fn invMass(index: u32) -> f32 {
  return 1.0 / max(vertices[index].rest.w * params.cloth.y, 0.000001);
}
fn safeNormal(v: vec3<f32>) -> vec3<f32> {
  return v * inverseSqrt(max(dot(v, v), 1e-18));
}
fn bounded(v: vec3<f32>, maximum: f32) -> vec3<f32> {
  return v * min(1.0, maximum * inverseSqrt(max(dot(v, v), 1e-18)));
}
fn motionLimit() -> f32 {
  return max(2.0 * params.cloth.x, 0.001);
}
fn speedLimit() -> f32 {
  return min(10.0, motionLimit() / params.control.x);
}
fn getFloat(index: u32) -> f32 {
  return bitcast<f32>(atomicLoad(&scratch[index]));
}
fn putFloat(index: u32, value: f32) {
  atomicStore(&scratch[index], bitcast<u32>(value));
}
fn skinPoint(index: u32) -> vec3<f32> {
  let point = vec4<f32>(vertices[index].rest.xyz, 1.0);
  var result = vec4<f32>(0.0);
  for (var k = 0u; k < 4u; k++) {
    let bone = min(vertices[index].boneIds[k], params.sceneInfo.x - 1u) * 4u;
    let matrix = mat4x4<f32>(scene[bone], scene[bone + 1u], scene[bone + 2u], scene[bone + 3u]);
    result += (matrix * point) * vertices[index].boneWeights[k];
  }
  return result.xyz;
}
fn triangle(index: u32) -> vec3<u32> {
  let start = params.offsets.y + index * 3u;
  return vec3<u32>(topology[start], topology[start + 1u], topology[start + 2u]);
}
fn cellOf(point: vec3<f32>) -> vec3<i32> {
  return vec3<i32>(floor(point / max(2.0 * params.cloth.x, 0.006)));
}
fn hashCell(cell: vec3<i32>) -> u32 {
  let c = bitcast<vec3<u32>>(cell);
  return ((c.x * 73856093u) ^ (c.y * 19349663u) ^ (c.z * 83492791u)) & params.counts.w;
}
fn connected(a: u32, b: u32) -> bool {
  let range = vertices[a].ranges;
  for (var j = 0u; j < range.y; j++) {
    let encoded = topology[range.x + j];
    let link = constraints[encoded >> 2u];
    if (link.kind != 2u || params.control.w > 0.01) {
      if (link.ids.x == b || link.ids.y == b || (link.kind == 1u && (link.ids.z == b || link.ids.w == b))) {
        return true;
      }
    }
  }
  return false;
}

@compute @workgroup_size(128)
fn skin(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  vertices[i].skinned = vec4<f32>(skinPoint(i), 1.0);
}

@compute @workgroup_size(128)
fn reset(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i < params.counts.x) {
    var point = vertices[i].rest.xyz;
    if (params.resetOffset.w > 0.5) { point = skinPoint(i); }
    point += params.resetOffset.xyz;
    positions[i] = vec4<f32>(point, 1.0);
    vertices[i].previous = positions[i];
    vertices[i].skinned = vec4<f32>(skinPoint(i), 1.0);
    vertices[i].velocity = vec4<f32>(0.0);
    vertices[i].contact = vec4<f32>(0.0);
  }
  if (i < params.counts.y) { constraints[i].lambda = 0.0; }
  if (i == 0u) {
    putFloat(0u, params.cloth.w);
    putFloat(1u, 0.0);
    putFloat(2u, 0.0);
    atomicStore(&scratch[3u], 0u);
    atomicStore(&scratch[14u], 0u);
    putFloat(12u, 0.0);
  }
}

@compute @workgroup_size(128)
fn captureGrab(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x || params.sceneInfo.w >= params.counts.z) { return; }
  let ids = triangle(params.sceneInfo.w);
  let center = positions[ids.x].xyz * params.grabBary.x + positions[ids.y].xyz * params.grabBary.y + positions[ids.z].xyz * params.grabBary.z;
  grabPatch[i] = vec4<f32>(positions[i].xyz - center, grabPatch[i].w);
}

@compute @workgroup_size(128)
fn predict(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i < params.counts.y) { constraints[i].lambda = 0.0; }
  if (i == 0u) { putFloat(2u, 0.0); }
  if (i >= params.counts.x) { return; }
  let dt = params.control.x;
  let original = positions[i].xyz;
  vertices[i].previous = positions[i];
  vertices[i].contact = vec4<f32>(0.0);
  let velocity = bounded(vertices[i].velocity.xyz, speedLimit()) * exp(-params.material.z * dt);
  var displacement = velocity * dt + vec3<f32>(0.0, params.grabBary.w, 0.0) * dt * dt;
  if (params.control.w > 0.999 && params.control.z > 0.001 && getFloat(12u) < params.cloth.x * 2.0) {
    let desired = params.cloth.w * params.control.z;
    let deficit = clamp(1.0 - getFloat(0u) / max(desired, 1e-6), 0.0, 1.0);
    let force = normals[i].xyz * vertices[i].rest.w * invMass(i) * params.cloth.z * 8.0 * params.control.z * deficit;
    displacement += bounded(force * dt * dt, 0.002);
  }
  positions[i] = vec4<f32>(original + bounded(displacement, motionLimit()), 1.0);
}

@compute @workgroup_size(128)
fn solveConstraints(@builtin(global_invocation_id) gid: vec3<u32>) {
  let index = gid.x;
  if (index >= params.counts.y) { return; }
  var link = constraints[index];
  link.deltaA = vec4<f32>(0.0);
  link.deltaB = vec4<f32>(0.0);
  link.deltaC = vec4<f32>(0.0);
  link.deltaD = vec4<f32>(0.0);
  if (link.kind == 2u && params.control.w < 0.001) {
    link.lambda = 0.0;
    constraints[index] = link;
    return;
  }
  let a = link.ids.x;
  let b = link.ids.y;
  let pa = positions[a].xyz;
  let pb = positions[b].xyz;
  let wa = invMass(a);
  let wb = invMass(b);
  let dt = params.control.x;
  var compliance = params.material.x;
  var error = 0.0;
  var ga = vec3<f32>(0.0);
  var gb = vec3<f32>(0.0);
  var gc = vec3<f32>(0.0);
  var gd = vec3<f32>(0.0);
  var wc = 0.0;
  var wd = 0.0;
  var degree = max(vertices[a].ranges.y, vertices[b].ranges.y);
  if (link.kind == 1u) {
    let c = link.ids.z;
    let d = link.ids.w;
    let pc = positions[c].xyz;
    let pd = positions[d].xyz;
    let edge = pb - pa;
    let edge2 = dot(edge, edge);
    let n1raw = cross(edge, pc - pa);
    let n2raw = cross(pd - pa, edge);
    let area1 = length(n1raw);
    let area2 = length(n2raw);
    if (edge2 < 1e-12 || area1 < 1e-9 || area2 < 1e-9) {
      constraints[index] = link;
      return;
    }
    let edgeLength = sqrt(edge2);
    let n1 = n1raw / area1;
    let n2 = n2raw / area2;
    let angle = atan2(dot(cross(n1, n2), edge / edgeLength), clamp(dot(n1, n2), -1.0, 1.0));
    error = angle - link.rest;
    error -= 6.28318530718 * floor((error + 3.14159265359) / 6.28318530718);
    gc = -n1 * edgeLength / area1;
    gd = -n2 * edgeLength / area2;
    gb = -(dot(pc - pa, edge) / edge2) * gc - (dot(pd - pa, edge) / edge2) * gd;
    ga = -gb - gc - gd;
    wc = invMass(c);
    wd = invMass(d);
    degree = max(degree, max(vertices[c].ranges.y, vertices[d].ranges.y));
    // Thin-shell bending/membrane stiffness ratio is thickness squared / 12.
    compliance = 12.0 * params.material.y / max(link.spare * params.cloth.x * params.cloth.x, 1e-10);
  } else {
    let difference = pa - pb;
    let distance = length(difference);
    ga = safeNormal(difference);
    gb = -ga;
    error = distance - link.rest;
    if (link.kind == 2u) {
      compliance = params.material.x + pow(1.0 - params.control.w, 3.0) * 0.02;
    }
  }
  let alpha = compliance / (dt * dt);
  let denominator = wa * dot(ga, ga) + wb * dot(gb, gb) + wc * dot(gc, gc) + wd * dot(gd, gd) + alpha;
  var deltaLambda = (-error - alpha * link.lambda) / max(denominator, 1e-10);
  deltaLambda *= min(0.9, 3.0 / f32(max(degree, 1u)));
  let maxDisplacement = max(max(length(ga) * wa, length(gb) * wb), max(length(gc) * wc, length(gd) * wd)) * abs(deltaLambda);
  deltaLambda *= min(1.0, 0.008 / max(maxDisplacement, 1e-10));
  link.lambda += deltaLambda;
  link.deltaA = vec4<f32>(wa * deltaLambda * ga, 0.0);
  link.deltaB = vec4<f32>(wb * deltaLambda * gb, 0.0);
  link.deltaC = vec4<f32>(wc * deltaLambda * gc, 0.0);
  link.deltaD = vec4<f32>(wd * deltaLambda * gd, 0.0);
  constraints[index] = link;
}

@compute @workgroup_size(128)
fn gatherConstraints(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  let range = vertices[i].ranges;
  var correction = vec3<f32>(0.0);
  for (var k = 0u; k < range.y; k++) {
    let entry = topology[range.x + k];
    let link = constraints[entry >> 2u];
    switch (entry & 3u) {
      case 0u: { correction += link.deltaA.xyz; }
      case 1u: { correction += link.deltaB.xyz; }
      case 2u: { correction += link.deltaC.xyz; }
      default: { correction += link.deltaD.xyz; }
    }
  }
  positions[i] = vec4<f32>(positions[i].xyz + bounded(correction, 0.015), 1.0);
}

var<workgroup> volumeValues: array<f32, 128>;
var<workgroup> gradientValues: array<f32, 128>;
var<workgroup> seamValues: array<f32, 128>;
@compute @workgroup_size(128)
fn volumePartial(@builtin(global_invocation_id) gid: vec3<u32>, @builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
  let i = gid.x;
  var value = 0.0;
  var gradient = vec3<f32>(0.0);
  var area = 0.0;
  var denominator = 0.0;
  var seamGap = 0.0;
  if (i < params.counts.x) {
    let range = vertices[i].ranges;
    if (params.settings.y > 0.5) {
      for (var k = 0u; k < range.y; k++) {
        let link = constraints[topology[range.x + k] >> 2u];
        if (link.kind == 2u) {
          seamGap = max(seamGap, distance(positions[link.ids.x].xyz, positions[link.ids.y].xyz));
        }
      }
    }
    for (var k = 0u; k < range.w; k++) {
      let ids = triangle(topology[range.z + k]);
      let a = positions[ids.x].xyz;
      let b = positions[ids.y].xyz;
      let c = positions[ids.z].xyz;
      value += dot(a, cross(b, c)) / 18.0;
      area += length(cross(b - a, c - a)) / 6.0;
      if (i == ids.x) { gradient += cross(b, c) / 6.0; }
      if (i == ids.y) { gradient += cross(c, a) / 6.0; }
      if (i == ids.z) { gradient += cross(a, b) / 6.0; }
    }
    gradient *= params.settings.x;
    vertices[i].gradient = vec4<f32>(gradient, area);
    denominator = invMass(i) * dot(gradient, gradient);
  }
  volumeValues[lid.x] = value * params.settings.x;
  gradientValues[lid.x] = denominator;
  seamValues[lid.x] = seamGap;
  workgroupBarrier();
  for (var stride = 64u; stride > 0u; stride >>= 1u) {
    if (lid.x < stride) {
      volumeValues[lid.x] += volumeValues[lid.x + stride];
      gradientValues[lid.x] += gradientValues[lid.x + stride];
      seamValues[lid.x] = max(seamValues[lid.x], seamValues[lid.x + stride]);
    }
    workgroupBarrier();
  }
  if (lid.x == 0u) {
    putFloat(params.scratch.x + wid.x * 3u, volumeValues[0]);
    putFloat(params.scratch.x + wid.x * 3u + 1u, gradientValues[0]);
    putFloat(params.scratch.x + wid.x * 3u + 2u, seamValues[0]);
  }
}

@compute @workgroup_size(1)
fn volumeFinish() {
  var volume = 0.0;
  var denominator = 0.0;
  var seamGap = 0.0;
  for (var k = 0u; k < params.scratch.y; k++) {
    volume += getFloat(params.scratch.x + k * 3u);
    denominator += getFloat(params.scratch.x + k * 3u + 1u);
    seamGap = max(seamGap, getFloat(params.scratch.x + k * 3u + 2u));
  }
  putFloat(0u, volume);
  putFloat(12u, seamGap);
  var deltaLambda = 0.0;
  if (params.control.w > 0.999 && params.control.z > 0.001 && params.cloth.z > 0.001 && seamGap < params.cloth.x * 2.0) {
    let dt = params.control.x;
    let alpha = 0.0000002 / (max(params.cloth.z, 0.001) * dt * dt);
    let error = volume - params.cloth.w * params.control.z;
    if (error < 0.0) {
      let oldLambda = max(0.0, getFloat(2u));
      // 只增压投影：不通过负位移撤回已经施加的支撑。
      deltaLambda = clamp((-error - alpha * oldLambda) / max(denominator + alpha, 1e-10), 0.0, 0.05);
      putFloat(2u, oldLambda + deltaLambda);
    } else {
      putFloat(2u, 0.0);
    }
  } else {
    putFloat(2u, 0.0);
  }
  putFloat(1u, deltaLambda);
}

@compute @workgroup_size(128)
fn applyVolume(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  let change = invMass(i) * getFloat(1u) * vertices[i].gradient.xyz;
  positions[i] = vec4<f32>(positions[i].xyz + bounded(change, 0.004), 1.0);
}

// 先缓存叶包围盒，再聚合内部节点，避免为每层反复读取三角形顶点。
@compute @workgroup_size(128)
fn surfaceLeafBounds(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i < params.counts.x) {
    for (var k = 0u; k < 4u; k++) { atomicStore(&scratch[params.surfaceScratch.x + i * 4u + k], 0u); }
  }
  if (i >= topology[params.surfaceScratch.w]) { return; }
  let leaf = topology[params.surfaceScratch.w + i + 1u];
  let node = params.surface.x + leaf * 6u;
  let start = topology[node];
  let count = topology[node + 1u];
  var low = vec3<f32>(1e30);
  var high = vec3<f32>(-1e30);
  for (var k = 0u; k < count; k++) {
    let ids = triangle(topology[params.surface.z + start + k]);
    for (var corner = 0u; corner < 3u; corner++) {
      low = min(low, min(positions[ids[corner]].xyz, vertices[ids[corner]].previous.xyz));
      high = max(high, max(positions[ids[corner]].xyz, vertices[ids[corner]].previous.xyz));
    }
  }
  let base = params.surface.w + leaf * 6u;
  for (var axis = 0u; axis < 3u; axis++) {
    putFloat(base + axis, low[axis]);
    putFloat(base + axis + 3u, high[axis]);
  }
}

@compute @workgroup_size(128)
fn surfaceBounds(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.surface.y) { return; }
  let node = params.surface.x + i * 6u;
  if (topology[node + 3u] != 0u) { return; }
  let start = topology[node + 4u];
  let count = topology[node + 5u];
  var low = vec3<f32>(1e30); var high = vec3<f32>(-1e30);
  for (var k = 0u; k < count; k++) {
    let leaf = topology[params.surfaceScratch.w + start + k + 1u];
    let source = params.surface.w + leaf * 6u;
    low = min(low, vec3<f32>(getFloat(source), getFloat(source + 1u), getFloat(source + 2u)));
    high = max(high, vec3<f32>(getFloat(source + 3u), getFloat(source + 4u), getFloat(source + 5u)));
  }
  let base = params.surface.w + i * 6u;
  for (var axis = 0u; axis < 3u; axis++) {
    putFloat(base + axis, low[axis]);
    putFloat(base + axis + 3u, high[axis]);
  }
}

fn sameMaterialPoint(a: u32, b: u32) -> bool {
  if (a == b) { return true; }
  if (params.settings.y > 0.5) {
    let range = params.surfaceScratch.z + a * 2u;
    let start = topology[range];
    for (var j = 0u; j < topology[range + 1u]; j++) {
      if (topology[start + j] == b) { return true; }
    }
  }
  return false;
}

fn closestBary(p: vec3<f32>, a: vec3<f32>, b: vec3<f32>, c: vec3<f32>) -> vec3<f32> {
  let ab = b - a; let ac = c - a; let ap = p - a;
  let d1 = dot(ab, ap); let d2 = dot(ac, ap);
  if (d1 <= 0.0 && d2 <= 0.0) { return vec3<f32>(1.0, 0.0, 0.0); }
  let bp = p - b; let d3 = dot(ab, bp); let d4 = dot(ac, bp);
  if (d3 >= 0.0 && d4 <= d3) { return vec3<f32>(0.0, 1.0, 0.0); }
  let vc = d1 * d4 - d3 * d2;
  if (vc <= 0.0 && d1 >= 0.0 && d3 <= 0.0) {
    let v = d1 / max(d1 - d3, 1e-20); return vec3<f32>(1.0 - v, v, 0.0);
  }
  let cp = p - c; let d5 = dot(ab, cp); let d6 = dot(ac, cp);
  if (d6 >= 0.0 && d5 <= d6) { return vec3<f32>(0.0, 0.0, 1.0); }
  let vb = d5 * d2 - d1 * d6;
  if (vb <= 0.0 && d2 >= 0.0 && d6 <= 0.0) {
    let w = d2 / max(d2 - d6, 1e-20); return vec3<f32>(1.0 - w, 0.0, w);
  }
  let va = d3 * d6 - d5 * d4;
  if (va <= 0.0 && d4 >= d3 && d5 >= d6) {
    let w = (d4 - d3) / max(d4 - d3 + d5 - d6, 1e-20); return vec3<f32>(0.0, 1.0 - w, w);
  }
  let inverse = 1.0 / max(va + vb + vc, 1e-20);
  return vec3<f32>(1.0 - (vb + vc) * inverse, vb * inverse, vc * inverse);
}

fn segmentBary(a: vec3<f32>, b: vec3<f32>, c: vec3<f32>, d: vec3<f32>) -> vec2<f32> {
  let u = b - a; let v = d - c; let w = a - c;
  let uu = max(dot(u, u), 1e-20); let vv = max(dot(v, v), 1e-20);
  let uv = dot(u, v); let uw = dot(u, w); let vw = dot(v, w);
  let determinant = uu * vv - uv * uv;
  var s = 0.0;
  if (determinant > 1e-12 * uu * vv) { s = clamp((uv * vw - vv * uw) / determinant, 0.0, 1.0); }
  var t = (uv * s + vw) / vv;
  if (t < 0.0) { t = 0.0; s = clamp(-uw / uu, 0.0, 1.0); }
  else if (t > 1.0) { t = 1.0; s = clamp((uv - uw) / uu, 0.0, 1.0); }
  return vec2<f32>(s, t);
}

fn polynomial(c: vec4<f32>, t: f32) -> f32 { return ((c.w * t + c.z) * t + c.y) * t + c.x; }

// 线性顶点轨迹的共面条件为三次式，以导数零点划分单调区间，避免只比较帧端符号。
fn coplanarRoots(a: u32, b: u32, c: u32, d: u32) -> vec3<f32> {
  let a0 = vertices[a].previous.xyz;
  let u = vertices[b].previous.xyz - a0;
  let v = vertices[c].previous.xyz - a0;
  let w = vertices[d].previous.xyz - a0;
  let du = positions[b].xyz - positions[a].xyz - u;
  let dv = positions[c].xyz - positions[a].xyz - v;
  let dw = positions[d].xyz - positions[a].xyz - w;
  let coefficients = vec4<f32>(dot(u, cross(v, w)),
    dot(du, cross(v, w)) + dot(u, cross(dv, w)) + dot(u, cross(v, dw)),
    dot(du, cross(dv, w)) + dot(du, cross(v, dw)) + dot(u, cross(dv, dw)), dot(du, cross(dv, dw)));
  let scale = max(max(abs(coefficients.x), abs(coefficients.y)), max(abs(coefficients.z), abs(coefficients.w)));
  var roots = vec3<f32>(-1.0);
  if (scale < 1e-20) { return roots; }
  let coef = coefficients / scale;
  let bernstein = vec4<f32>(coef.x, coef.x + coef.y / 3.0, coef.x + (2.0 * coef.y + coef.z) / 3.0, coef.x + coef.y + coef.z + coef.w);
  if (all(bernstein > vec4<f32>(0.0)) || all(bernstein < vec4<f32>(0.0))) { return roots; }
  var cuts = vec4<f32>(0.0, 1.0, 1.0, 1.0);
  var cutCount = 2u;
  let discriminant = coef.z * coef.z - 3.0 * coef.w * coef.y;
  if (abs(coef.w) > 1e-7 && discriminant > 0.0) {
    let sq = sqrt(discriminant);
    let r0 = (-coef.z - sq) / (3.0 * coef.w);
    let r1 = (-coef.z + sq) / (3.0 * coef.w);
    let low = min(r0, r1); let high = max(r0, r1);
    if (low > 0.0 && low < 1.0) { cuts[cutCount - 1u] = low; cutCount++; }
    if (high > 0.0 && high < 1.0) { cuts[cutCount - 1u] = high; cutCount++; }
  } else if (abs(coef.z) > 1e-7) {
    let root = -coef.y / (2.0 * coef.z);
    if (root > 0.0 && root < 1.0) { cuts[1] = root; cutCount++; }
  }
  cuts[cutCount - 1u] = 1.0;
  var found = 0u;
  for (var interval = 0u; interval + 1u < cutCount; interval++) {
    var lo = cuts[interval]; var hi = cuts[interval + 1u];
    let flo = polynomial(coef, lo); let fhi = polynomial(coef, hi);
    if (flo * fhi > 0.0) { continue; }
    if (abs(flo) < 1e-8 && lo > 1e-5) { hi = lo; }
    else {
      for (var iteration = 0u; iteration < 18u; iteration++) {
        let middle = (lo + hi) * 0.5;
        if (polynomial(coef, middle) * flo > 0.0) { lo = middle; } else { hi = middle; }
      }
    }
    let time = (lo + hi) * 0.5;
    if (time > 1e-5 && found < 3u) { roots[found] = time; found++; }
  }
  return roots;
}

fn movingPoint(index: u32, time: f32) -> vec3<f32> { return mix(vertices[index].previous.xyz, positions[index].xyz, time); }

fn addSurfaceDelta(index: u32, delta: vec3<f32>) {
  if (dot(delta, delta) < 1e-20) { return; }
  let base = params.surfaceScratch.x + index * 4u;
  // 浮点 CAS 保留质量加权精度，不使用可能在密集折叠溢出的定点累加。
  for (var axis = 0u; axis < 3u; axis++) {
    if (delta[axis] == 0.0) { continue; }
    var old = atomicLoad(&scratch[base + axis]);
    loop {
      let exchange = atomicCompareExchangeWeak(&scratch[base + axis], old, bitcast<u32>(bitcast<f32>(old) + delta[axis]));
      if (exchange.exchanged) { break; }
      old = exchange.old_value;
    }
  }
  atomicAdd(&scratch[base + 3u], 1u);
}

fn pointFaceAllowed(pointId: u32, faceId: u32) -> bool {
  let ids = triangle(faceId);
  return !sameMaterialPoint(pointId, ids.x) && !sameMaterialPoint(pointId, ids.y) && !sameMaterialPoint(pointId, ids.z);
}

fn vertexTriangleContact(pointId: u32, faceId: u32, ids: vec3<u32>) {
  if (sameMaterialPoint(pointId, ids.x) || sameMaterialPoint(pointId, ids.y) || sameMaterialPoint(pointId, ids.z)) { return; }
  let p = positions[pointId].xyz;
  let a = positions[ids.x].xyz; let b = positions[ids.y].xyz; let c = positions[ids.z].xyz;
  let separation = params.cloth.x * 2.0;
  let pointLow = min(p, vertices[pointId].previous.xyz) - vec3<f32>(separation);
  let pointHigh = max(p, vertices[pointId].previous.xyz) + vec3<f32>(separation);
  let faceLow = min(min(a, vertices[ids.x].previous.xyz), min(min(b, vertices[ids.y].previous.xyz), min(c, vertices[ids.z].previous.xyz)));
  let faceHigh = max(max(a, vertices[ids.x].previous.xyz), max(max(b, vertices[ids.y].previous.xyz), max(c, vertices[ids.z].previous.xyz)));
  if (any(pointLow > faceHigh) || any(pointHigh < faceLow)) { return; }
  var bary = closestBary(p, a, b, c);
  var difference = p - (a * bary.x + b * bary.y + c * bary.z);
  var normal = safeNormal(difference);
  var hasContact = dot(difference, difference) < separation * separation;
  if (hasContact && dot(difference, difference) > 1e-16) {
    let features = params.surfaceScratch.y + faceId * 7u;
    var owner = faceId;
    if (bary.x == 1.0) { owner = topology[features + 1u]; }
    else if (bary.y == 1.0) { owner = topology[features + 2u]; }
    else if (bary.z == 1.0) { owner = topology[features + 3u]; }
    else if (bary.z == 0.0) { owner = topology[features + 4u]; }
    else if (bary.x == 0.0) { owner = topology[features + 5u]; }
    else if (bary.y == 0.0) { owner = topology[features + 6u]; }
    // 局部/缝合邻域的规范面可能含源点；此时保留合法非规范面。
    if (owner != faceId && pointFaceAllowed(pointId, owner)) { return; }
  }
  if (hasContact) {
    if (dot(normal, normal) < 0.5) { normal = safeNormal(cross(b - a, c - a)); }
    let before = vertices[pointId].previous.xyz - (vertices[ids.x].previous.xyz * bary.x + vertices[ids.y].previous.xyz * bary.y + vertices[ids.z].previous.xyz * bary.z);
    if (dot(before, normal) < 0.0) { normal = -normal; }
  }
  var roots = vec3<f32>(-1.0);
  if (!hasContact) {
    let travel = distance(p, vertices[pointId].previous.xyz) + max(distance(a, vertices[ids.x].previous.xyz), max(distance(b, vertices[ids.y].previous.xyz), distance(c, vertices[ids.z].previous.xyz)));
    if (dot(difference, difference) > (separation + travel) * (separation + travel)) { return; }
    roots = coplanarRoots(ids.x, ids.y, ids.z, pointId);
  }
  for (var k = 0u; k < 3u; k++) {
    let time = roots[k];
    if (time < 0.0) { continue; }
    let pa = movingPoint(ids.x, time); let pb = movingPoint(ids.y, time); let pc = movingPoint(ids.z, time);
    let pp = movingPoint(pointId, time);
    let hitBary = closestBary(pp, pa, pb, pc);
    if (distance(pp, pa * hitBary.x + pb * hitBary.y + pc * hitBary.z) > max(separation * 0.002, 1e-6)) { continue; }
    let n = safeNormal(cross(pb - pa, pc - pa));
    if (dot(n, n) < 0.5) { continue; }
    let earlier = max(0.0, time - 0.001);
    let prior = movingPoint(pointId, earlier) - (movingPoint(ids.x, earlier) * hitBary.x + movingPoint(ids.y, earlier) * hitBary.y + movingPoint(ids.z, earlier) * hitBary.z);
    normal = n * select(-1.0, 1.0, dot(prior, n) >= 0.0);
    bary = hitBary; hasContact = true;
    break;
  }
  if (!hasContact || dot(normal, normal) < 0.5) { return; }
  difference = p - (a * bary.x + b * bary.y + c * bary.z);
  let penetration = separation - dot(difference, normal);
  if (penetration <= 0.0) { return; }
  let weights = vec3<f32>(invMass(ids.x), invMass(ids.y), invMass(ids.z));
  let pointWeight = invMass(pointId);
  let lambda = penetration / max(pointWeight + dot(weights, bary * bary), 1e-10);
  addSurfaceDelta(pointId, normal * lambda * pointWeight);
  for (var k = 0u; k < 3u; k++) { addSurfaceDelta(ids[k], -normal * lambda * weights[k] * bary[k]); }
}

fn edgeEdgeContact(aId: u32, bId: u32, cId: u32, dId: u32, firstFace: u32, secondFace: u32) {
  if (sameMaterialPoint(aId, cId) || sameMaterialPoint(aId, dId) || sameMaterialPoint(bId, cId) || sameMaterialPoint(bId, dId)) { return; }
  let a = positions[aId].xyz; let b = positions[bId].xyz;
  let c = positions[cId].xyz; let d = positions[dId].xyz;
  let separation = params.cloth.x * 2.0;
  let firstLow = min(min(a, vertices[aId].previous.xyz), min(b, vertices[bId].previous.xyz)) - vec3<f32>(separation);
  let firstHigh = max(max(a, vertices[aId].previous.xyz), max(b, vertices[bId].previous.xyz)) + vec3<f32>(separation);
  let secondLow = min(min(c, vertices[cId].previous.xyz), min(d, vertices[dId].previous.xyz));
  let secondHigh = max(max(c, vertices[cId].previous.xyz), max(d, vertices[dId].previous.xyz));
  if (any(firstLow > secondHigh) || any(firstHigh < secondLow)) { return; }
  var bary = segmentBary(a, b, c, d);
  var difference = mix(a, b, bary.x) - mix(c, d, bary.y);
  var normal = safeNormal(difference);
  var hasContact = dot(difference, difference) < separation * separation;
  if (hasContact && dot(difference, difference) > 1e-16) {
    // 仅在对应 VT 确实合法时移交端点近接触，避免局部邻接/缝合漏检。
    if (bary.x == 0.0 && pointFaceAllowed(aId, secondFace)) { return; }
    if (bary.x == 1.0 && pointFaceAllowed(bId, secondFace)) { return; }
    if (bary.y == 0.0 && pointFaceAllowed(cId, firstFace)) { return; }
    if (bary.y == 1.0 && pointFaceAllowed(dId, firstFace)) { return; }
  }
  if (hasContact) {
    if (dot(normal, normal) < 0.5) { normal = safeNormal(cross(b - a, d - c)); }
    let before = mix(vertices[aId].previous.xyz, vertices[bId].previous.xyz, bary.x) - mix(vertices[cId].previous.xyz, vertices[dId].previous.xyz, bary.y);
    if (dot(before, normal) < 0.0) { normal = -normal; }
  }
  var roots = vec3<f32>(-1.0);
  if (!hasContact) {
    let travel = max(distance(a, vertices[aId].previous.xyz), distance(b, vertices[bId].previous.xyz)) + max(distance(c, vertices[cId].previous.xyz), distance(d, vertices[dId].previous.xyz));
    if (dot(difference, difference) > (separation + travel) * (separation + travel)) { return; }
    roots = coplanarRoots(aId, bId, cId, dId);
  }
  for (var k = 0u; k < 3u; k++) {
    let time = roots[k];
    if (time < 0.0) { continue; }
    let pa = movingPoint(aId, time); let pb = movingPoint(bId, time);
    let pc = movingPoint(cId, time); let pd = movingPoint(dId, time);
    let hitBary = segmentBary(pa, pb, pc, pd);
    if (distance(mix(pa, pb, hitBary.x), mix(pc, pd, hitBary.y)) > max(separation * 0.002, 1e-6)) { continue; }
    let n = safeNormal(cross(pb - pa, pd - pc));
    if (dot(n, n) < 0.5) { continue; }
    let earlier = max(0.0, time - 0.001);
    let prior = mix(movingPoint(aId, earlier), movingPoint(bId, earlier), hitBary.x) - mix(movingPoint(cId, earlier), movingPoint(dId, earlier), hitBary.y);
    normal = n * select(-1.0, 1.0, dot(prior, n) >= 0.0);
    bary = hitBary; hasContact = true;
    break;
  }
  if (!hasContact || dot(normal, normal) < 0.5) { return; }
  difference = mix(a, b, bary.x) - mix(c, d, bary.y);
  let penetration = separation - dot(difference, normal);
  if (penetration <= 0.0) { return; }
  let coefficients = vec4<f32>(1.0 - bary.x, bary.x, bary.y - 1.0, -bary.y);
  let ids = vec4<u32>(aId, bId, cId, dId);
  let weights = vec4<f32>(invMass(aId), invMass(bId), invMass(cId), invMass(dId));
  let lambda = penetration / max(dot(weights, coefficients * coefficients), 1e-10);
  for (var k = 0u; k < 4u; k++) { addSurfaceDelta(ids[k], normal * lambda * coefficients[k] * weights[k]); }
}

@compute @workgroup_size(128)
fn surfaceContacts(@builtin(global_invocation_id) gid: vec3<u32>) {
  let rank = gid.x;
  if (rank >= params.counts.z) { return; }
  let i = topology[params.surface.z + rank];
  let ids = triangle(i);
  let mask = topology[params.surfaceScratch.y + i * 7u];
  var low = vec3<f32>(1e30); var high = vec3<f32>(-1e30);
  for (var k = 0u; k < 3u; k++) {
    low = min(low, min(positions[ids[k]].xyz, vertices[ids[k]].previous.xyz));
    high = max(high, max(positions[ids[k]].xyz, vertices[ids[k]].previous.xyz));
  }
  low -= vec3<f32>(params.cloth.x * 2.0); high += vec3<f32>(params.cloth.x * 2.0);
  var node = 0u;
  loop {
    if (node >= params.surface.y) { break; }
    let offset = params.surface.x + node * 6u;
    if (topology[offset] + topology[offset + 1u] <= rank + 1u) { node = topology[offset + 2u]; continue; }
    let base = params.surface.w + node * 6u;
    let nodeLow = vec3<f32>(getFloat(base), getFloat(base + 1u), getFloat(base + 2u));
    let nodeHigh = vec3<f32>(getFloat(base + 3u), getFloat(base + 4u), getFloat(base + 5u));
    if (any(low > nodeHigh) || any(high < nodeLow)) { node = topology[offset + 2u]; continue; }
    if (topology[offset + 3u] != 0u) {
      for (var k = 0u; k < topology[offset + 1u]; k++) {
        let otherRank = topology[offset] + k;
        if (otherRank <= rank) { continue; }
        let other = topology[params.surface.z + otherRank];
        let otherMask = topology[params.surfaceScratch.y + other * 7u];
        if (((mask | otherMask) & 7u) == 0u && ((mask & 56u) == 0u || (otherMask & 56u) == 0u)) { continue; }
        let otherIds = triangle(other);
        var otherLow = vec3<f32>(1e30); var otherHigh = vec3<f32>(-1e30);
        for (var j = 0u; j < 3u; j++) {
          otherLow = min(otherLow, min(positions[otherIds[j]].xyz, vertices[otherIds[j]].previous.xyz));
          otherHigh = max(otherHigh, max(positions[otherIds[j]].xyz, vertices[otherIds[j]].previous.xyz));
        }
        if (any(low > otherHigh) || any(high < otherLow)) { continue; }
        // 每个顶点/边由唯一的关联面发射，避免一环重复接触与原子竞争。
        for (var j = 0u; j < 3u; j++) {
          if ((mask & (1u << j)) != 0u) { vertexTriangleContact(ids[j], other, otherIds); }
          if ((otherMask & (1u << j)) != 0u) { vertexTriangleContact(otherIds[j], i, ids); }
          if ((mask & (1u << (j + 3u))) == 0u) { continue; }
          for (var edge = 0u; edge < 3u; edge++) {
            if ((otherMask & (1u << (edge + 3u))) != 0u) {
              edgeEdgeContact(ids[j], ids[(j + 1u) % 3u], otherIds[edge], otherIds[(edge + 1u) % 3u], i, other);
            }
          }
        }
      }
    }
    node++;
  }
}

@compute @workgroup_size(128)
fn applySurfaceContacts(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  let base = params.surfaceScratch.x + i * 4u;
  let hits = atomicLoad(&scratch[base + 3u]);
  if (hits == 0u) { return; }
  let correction = vec3<f32>(getFloat(base), getFloat(base + 1u), getFloat(base + 2u)) / f32(hits);
  positions[i] = vec4<f32>(positions[i].xyz + correction, 1.0);
  vertices[i].contact.w = 1.0;
  vertices[i].gradient = vec4<f32>(safeNormal(correction), 0.0);
}

@compute @workgroup_size(128)
fn hashClear(@builtin(global_invocation_id) gid: vec3<u32>) {
  if (gid.x <= params.counts.w) {
    atomicStore(&scratch[params.scratch.w + gid.x], 0xffffffffu);
    atomicStore(&scratch[params.offsets.x + gid.x], 0u);
  }
}
@compute @workgroup_size(128)
fn hashBuild(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  let bucket = hashCell(cellOf(positions[i].xyz));
  let previousHead = atomicExchange(&scratch[params.scratch.w + bucket], i);
  atomicStore(&scratch[params.offsets.w + i], previousHead);
  let occupancy = atomicAdd(&scratch[params.offsets.x + bucket], 1u) + 1u;
  atomicMax(&scratch[14u], occupancy);
}

@compute @workgroup_size(128)
fn contacts(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  let point = positions[i].xyz;
  let thickness = params.cloth.x;
  let separation = 2.0 * thickness;
  let cell = cellOf(point);
  var selfDelta = vec3<f32>(0.0);
  var hits = 0.0;
  for (var z = -1; z <= 1; z++) {
    for (var y = -1; y <= 1; y++) {
      for (var x = -1; x <= 1; x++) {
        let neighborCell = cell + vec3<i32>(x, y, z);
        let bucket = hashCell(neighborCell);
        var node = atomicLoad(&scratch[params.scratch.w + bucket]);
        var traversed = 0u;
        loop {
          if (node == 0xffffffffu) { break; }
          if (node >= params.counts.x || traversed >= params.counts.x) {
            atomicMax(&scratch[3u], 1u);
            break;
          }
          let other = node;
          node = atomicLoad(&scratch[params.offsets.w + other]);
          traversed += 1u;
          if (other == i) { continue; }
          let otherPoint = positions[other].xyz;
          if (any(cellOf(otherPoint) != neighborCell)) { continue; }
          let difference = point - otherPoint;
          let distance2 = dot(difference, difference);
          if (distance2 >= separation * separation || connected(i, other)) { continue; }
          let distance = sqrt(max(distance2, 1e-14));
          var direction = difference / distance;
          if (distance2 < 1e-12) {
            direction = safeNormal(vertices[i].rest.xyz - vertices[other].rest.xyz);
            if (dot(direction, direction) < 0.1) {
              direction = vec3<f32>(select(-1.0, 1.0, i > other), 0.0, 0.0);
            }
          }
          let weight = invMass(i) / (invMass(i) + invMass(other));
          selfDelta += direction * (separation - distance) * weight;
          hits += 1.0;
        }
      }
    }
  }
  var candidate = point + selfDelta / max(hits, 1.0) * 0.85;
  let surfaceHit = atomicLoad(&scratch[params.surfaceScratch.x + i * 4u + 3u]) > 0u;
  var contactNormal = select(vec3<f32>(0.0), vertices[i].gradient.xyz, surfaceHit);
  if (candidate.y < thickness) {
    candidate.y = thickness;
    contactNormal += vec3<f32>(0.0, 1.0, 0.0);
  }
  for (var k = 0u; k < params.sceneInfo.y; k++) {
    let base = params.sceneInfo.z + k * 3u;
    let objectPosition = scene[base];
    let shape = scene[base + 1u];
    let rotation = scene[base + 2u];
    let relative = candidate - objectPosition.xyz;
    var local = vec3<f32>(rotation.x * relative.x - rotation.y * relative.z, relative.y, rotation.y * relative.x + rotation.x * relative.z);
    local = vec3<f32>(local.x, cos(rotation.w)*local.y+sin(rotation.w)*local.z, -sin(rotation.w)*local.y+cos(rotation.w)*local.z);
    var localNormal = vec3<f32>(0.0);
    var penetration = 0.0;
    if (objectPosition.w < 0.5) {
      let q = abs(local) - shape.xyz;
      let outside = max(q, vec3<f32>(0.0));
      let signedDistance = length(outside) + min(max(q.x, max(q.y, q.z)), 0.0);
      penetration = thickness - signedDistance;
      if (length(outside) > 1e-8) {
        localNormal = safeNormal(outside * sign(local));
      } else if (q.x >= q.y && q.x >= q.z) {
        localNormal = vec3<f32>(select(-1.0, 1.0, local.x >= 0.0), 0.0, 0.0);
      } else if (q.y >= q.z) {
        localNormal = vec3<f32>(0.0, select(-1.0, 1.0, local.y >= 0.0), 0.0);
      } else {
        localNormal = vec3<f32>(0.0, 0.0, select(-1.0, 1.0, local.z >= 0.0));
      }
    } else {
      var delta = local;
      if (objectPosition.w > 1.5) { delta.y -= clamp(delta.y, -rotation.z, rotation.z); }
      let distance = length(delta);
      localNormal = safeNormal(delta);
      if (distance < 1e-8) { localNormal = vec3<f32>(0.0, 1.0, 0.0); }
      penetration = shape.w + thickness - distance;
    }
    if (penetration > 0.0) {
      let pitchedNormal=vec3<f32>(localNormal.x,cos(rotation.w)*localNormal.y-sin(rotation.w)*localNormal.z,sin(rotation.w)*localNormal.y+cos(rotation.w)*localNormal.z);
      let worldNormal = vec3<f32>(rotation.x * pitchedNormal.x + rotation.y * pitchedNormal.z, pitchedNormal.y, -rotation.y * pitchedNormal.x + rotation.x * pitchedNormal.z);
      candidate += worldNormal * penetration;
      contactNormal += worldNormal;
    }
  }
  if (candidate.y < thickness) {
    candidate.y = thickness;
    contactNormal += vec3<f32>(0.0, 1.0, 0.0);
  }
  vertices[i].contact = vec4<f32>(candidate - point, select(0.0, 1.0, hits > 0.0 || dot(contactNormal, contactNormal) > 0.0));
  vertices[i].gradient = vec4<f32>(safeNormal(contactNormal), 0.0);
}

@compute @workgroup_size(128)
fn applyContacts(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  positions[i] = vec4<f32>(positions[i].xyz + vertices[i].contact.xyz, 1.0);
}

@compute @workgroup_size(128)
fn attachments(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  var point = positions[i].xyz;
  let influence = params.control.y;
  let grabbing = params.sceneInfo.w < params.counts.z && params.grabPoint.w > 0.0;
  let areaGrab = grabbing && params.grabBary.w > 0.0;
  let grabInfluence = select(0.0, grabPatch[i].w * params.grabPoint.w, areaGrab);
  let stiffness = (1.0 - exp(-influence * influence * 1000.0 * params.control.x)) * (1.0 - grabInfluence);
  point += bounded((vertices[i].skinned.xyz - point) * stiffness, 0.018);
  if (areaGrab) {
    let desired = params.grabPoint.xyz + grabPatch[i].xyz;
    let grabStiffness = 1.0 - exp(-220.0 * grabInfluence * params.control.x);
    point += bounded((desired - point) * grabStiffness, motionLimit() * grabInfluence);
  } else if (grabbing) {
    let ids = triangle(params.sceneInfo.w);
    var bary = 0.0;
    if (i == ids.x) { bary = params.grabBary.x; }
    if (i == ids.y) { bary = params.grabBary.y; }
    if (i == ids.z) { bary = params.grabBary.z; }
    let grabbed = positions[ids.x].xyz * params.grabBary.x + positions[ids.y].xyz * params.grabBary.y + positions[ids.z].xyz * params.grabBary.z;
    let denominator = invMass(ids.x) * params.grabBary.x * params.grabBary.x + invMass(ids.y) * params.grabBary.y * params.grabBary.y + invMass(ids.z) * params.grabBary.z * params.grabBary.z;
    let correction = (params.grabPoint.xyz - grabbed) * bary * invMass(i) / max(denominator, 1e-8) * params.grabPoint.w;
    point += bounded(correction, 0.02);
  }
  vertices[i].contact = vec4<f32>(bounded(point - positions[i].xyz, motionLimit()), 0.0);
}

@compute @workgroup_size(128)
fn finish(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  var velocity = (positions[i].xyz - vertices[i].previous.xyz) / params.control.x;
  if (vertices[i].contact.w > 0.5) {
    let normal = vertices[i].gradient.xyz;
    let normalVelocity = normal * max(dot(velocity, normal), 0.0);
    velocity = normalVelocity + (velocity - normal * dot(velocity, normal)) * (1.0 - params.material.w);
  }
  vertices[i].velocity = vec4<f32>(bounded(velocity, speedLimit()), 0.0);
}

@compute @workgroup_size(128)
fn updateNormals(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  let range = vertices[i].ranges;
  var normal = vec3<f32>(0.0);
  for (var k = 0u; k < range.w; k++) {
    let ids = triangle(topology[range.z + k]);
    normal += cross(positions[ids.y].xyz - positions[ids.x].xyz, positions[ids.z].xyz - positions[ids.x].xyz);
  }
  normal = safeNormal(normal) * params.settings.x;
  if (dot(normal, normal) < 0.1) { normal = vertices[i].baseNormal.xyz; }
  normals[i] = vec4<f32>(normal, 0.0);
}

var<workgroup> pickDistances: array<f32, 128>;
var<workgroup> pickTriangles: array<u32, 128>;
var<workgroup> pickBarys: array<vec2<f32>, 128>;
@compute @workgroup_size(128)
fn pickPartial(@builtin(global_invocation_id) gid: vec3<u32>, @builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
  let i = gid.x;
  var distance = 1e30;
  var bary = vec2<f32>(0.0);
  if (i < params.counts.z) {
    let ids = triangle(i);
    let a = positions[ids.x].xyz;
    let edge1 = positions[ids.y].xyz - a;
    let edge2 = positions[ids.z].xyz - a;
    let p = cross(params.rayDirection.xyz, edge2);
    let determinant = dot(edge1, p);
    if (abs(determinant) > 1e-10) {
      let inverse = 1.0 / determinant;
      let t = params.rayOrigin.xyz - a;
      let u = dot(t, p) * inverse;
      let q = cross(t, edge1);
      let v = dot(params.rayDirection.xyz, q) * inverse;
      let hitDistance = dot(edge2, q) * inverse;
      if (u >= 0.0 && v >= 0.0 && u + v <= 1.0 && hitDistance > 0.0) {
        distance = hitDistance;
        bary = vec2<f32>(u, v);
      }
    }
  }
  pickDistances[lid.x] = distance;
  pickTriangles[lid.x] = i;
  pickBarys[lid.x] = bary;
  workgroupBarrier();
  for (var stride = 64u; stride > 0u; stride >>= 1u) {
    if (lid.x < stride && pickDistances[lid.x + stride] < pickDistances[lid.x]) {
      pickDistances[lid.x] = pickDistances[lid.x + stride];
      pickTriangles[lid.x] = pickTriangles[lid.x + stride];
      pickBarys[lid.x] = pickBarys[lid.x + stride];
    }
    workgroupBarrier();
  }
  if (lid.x == 0u) {
    let base = params.offsets.z + wid.x * 4u;
    putFloat(base, pickDistances[0]);
    atomicStore(&scratch[base + 1u], pickTriangles[0]);
    putFloat(base + 2u, pickBarys[0].x);
    putFloat(base + 3u, pickBarys[0].y);
  }
}
@compute @workgroup_size(1)
fn pickFinish() {
  var nearest = 1e30;
  var best = 0xffffffffu;
  let groups = (params.counts.z + 127u) / 128u;
  for (var k = 0u; k < groups; k++) {
    let base = params.offsets.z + k * 4u;
    let distance = getFloat(base);
    if (distance < nearest) { nearest = distance; best = base; }
  }
  putFloat(4u, nearest);
  atomicStore(&scratch[5u], 0xffffffffu);
  if (best != 0xffffffffu) {
    atomicStore(&scratch[5u], atomicLoad(&scratch[best + 1u]));
    atomicStore(&scratch[6u], atomicLoad(&scratch[best + 2u]));
    atomicStore(&scratch[7u], atomicLoad(&scratch[best + 3u]));
  }
}

@compute @workgroup_size(1)
fn diagnosticSummary() {
  var minimumY = 1e30;
  var maximumSpeed = 0.0;
  var poseSquaredError = 0.0;
  var finiteCount = 0u;
  var gap = 0.0;
  var seamCount = 0.0;
  for (var i = 0u; i < params.counts.x; i++) {
    let p = positions[i].xyz;
    if (all(abs(p) < vec3<f32>(1e10))) { finiteCount += 1u; }
    minimumY = min(minimumY, p.y);
    maximumSpeed = max(maximumSpeed, length(vertices[i].velocity.xyz));
    let poseDifference = p - vertices[i].skinned.xyz;
    poseSquaredError += dot(poseDifference, poseDifference);
  }
  for (var i = 0u; i < params.counts.y; i++) {
    let link = constraints[i];
    if (link.kind == 2u) {
      gap += distance(positions[link.ids.x].xyz, positions[link.ids.y].xyz);
      seamCount += 1.0;
    }
  }
  putFloat(8u, minimumY);
  putFloat(9u, maximumSpeed);
  atomicStore(&scratch[10u], finiteCount);
  putFloat(11u, gap / max(seamCount, 1.0));
  putFloat(13u, sqrt(poseSquaredError / f32(max(params.counts.x, 1u))));
}
