const TAU = Math.PI * 2;
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const subtract = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const normalize = (v) => {
  const length = Math.hypot(...v) || 1;
  return v.map((component) => component / length);
};

export function createCamera() {
  return { target: [0, 0.95, 0], yaw: 0.45, pitch: 0.15, distance: 3.8, fov: 38 };
}

export function getCameraPosition(camera) {
  const horizontal = Math.cos(camera.pitch) * camera.distance;
  return [
    camera.target[0] + Math.sin(camera.yaw) * horizontal,
    camera.target[1] + Math.sin(camera.pitch) * camera.distance,
    camera.target[2] + Math.cos(camera.yaw) * horizontal,
  ];
}

function cameraBasis(camera) {
  const eye = getCameraPosition(camera);
  const forward = normalize(subtract(camera.target, eye));
  const right = normalize(cross(forward, [0, 1, 0]));
  return { eye, forward, right, up: cross(right, forward) };
}

export function orbitCamera(camera, dx, dy) {
  camera.yaw -= dx * 0.006;
  camera.pitch = clamp(camera.pitch + dy * 0.006, -1.4, 1.45);
}

export function panCamera(camera, dx, dy, viewportHeight) {
  const { right, up } = cameraBasis(camera);
  const scale = 2 * camera.distance * Math.tan(camera.fov * Math.PI / 360) / Math.max(1, viewportHeight);
  for (let i = 0; i < 3; i++) camera.target[i] += (-right[i] * dx + up[i] * dy) * scale;
}

export function zoomCamera(camera, delta) {
  camera.distance = clamp(camera.distance * Math.exp(clamp(delta, -1000, 1000) * 0.001), 0.35, 18);
}

export function moveCamera(camera, movement, dt, speed = 1.2) {
  const { forward, right } = cameraBasis(camera);
  const direction = forward.map((v, i) => v * (movement.forward ?? 0)
    + right[i] * (movement.right ?? 0) + (i === 1 ? movement.up ?? 0 : 0));
  const step = clamp(dt, 0, 0.1) * speed / Math.max(1, Math.hypot(...direction));
  for (let i = 0; i < 3; i++) camera.target[i] += direction[i] * step;
}

export function cameraRay(camera, x, y, width, height) {
  const { eye, forward, right, up } = cameraBasis(camera);
  const tangent = Math.tan(camera.fov * Math.PI / 360);
  const sx = (2 * x / Math.max(1, width) - 1) * tangent * width / Math.max(1, height);
  const sy = (1 - 2 * y / Math.max(1, height)) * tangent;
  return { origin: eye, direction: normalize(forward.map((v, i) => v + right[i] * sx + up[i] * sy)) };
}

export function projectPoint(camera, point, width, height) {
  const { eye, forward, right, up } = cameraBasis(camera);
  const relative = subtract(point, eye);
  const depth = dot(relative, forward);
  if (depth <= 0.001) return null;
  const tangent = Math.tan(camera.fov * Math.PI / 360);
  return [
    width / 2 + dot(relative, right) / (depth * tangent) * height / 2,
    height / 2 - dot(relative, up) / (depth * tangent) * height / 2,
  ];
}

const gizmoAxisNames = ['x', 'y', 'z'];
const gizmoAxisColors = ['#ed8b81', '#9bcea0', '#83bce2'];
function gizmoSegmentDistance(p, a, b) {
  const dx = b[0] - a[0], dy = b[1] - a[1];
  const t = clamp(((p.x - a[0]) * dx + (p.y - a[1]) * dy) / Math.max(1e-8, dx * dx + dy * dy), 0, 1);
  return Math.hypot(p.x - a[0] - dx * t, p.y - a[1] - dy * t);
}

export function transformObjectGizmo(objects, selectedId, mode, camera, width, height) {
  const object = (objects || []).find((item) => item.id === selectedId);
  if (!object || !['translate', 'rotate'].includes(mode) || width <= 0 || height <= 0) return null;
  const center = object.position || [0, 0, 0];
  const projected = projectPoint(camera, center, width, height);
  if (!projected) return null;
  const pivot = { x: projected[0], y: projected[1] };
  const distance = Math.hypot(...subtract(getCameraPosition(camera), center));
  const size = distance * Math.tan(camera.fov * Math.PI / 360) * 0.22;
  const axes = {};
  for (let index = 0; index < 3; index++) {
    const name = gizmoAxisNames[index];
    const vector = gizmoAxisNames.map((_, i) => Number(i === index));
    let points;
    if (mode === 'translate') {
      const tip = projectPoint(camera, center.map((v, i) => v + vector[i] * size), width, height);
      if (!tip) continue;
      points = [projected.slice(0, 2), tip.slice(0, 2)];
    } else {
      const u = gizmoAxisNames.map((_, i) => Number(i === (index + 1) % 3));
      const v = gizmoAxisNames.map((_, i) => Number(i === (index + 2) % 3));
      points = [];
      for (let step = 0; step <= 64; step++) {
        const angle = step / 64 * TAU;
        const point = projectPoint(camera, center.map((value, i) => value + size * (u[i] * Math.cos(angle) + v[i] * Math.sin(angle))), width, height);
        if (!point) continue;
        points.push(point.slice(0, 2));
      }
      if (points.length < 2) continue;
    }
    const tip = mode === 'translate' ? points[1] : points[0];
    const dx = tip[0] - pivot.x, dy = tip[1] - pivot.y;
    const screenLength = Math.hypot(dx, dy);
    axes[name] = { name, index, vector, color: gizmoAxisColors[index], x: tip[0], y: tip[1],
      dx: screenLength ? dx / screenLength : 0, dy: screenLength ? dy / screenLength : 0,
      length: screenLength, tip: [...tip], points };
  }
  return { objectId: object.id, mode, center: [...center], size, pivot, screen: [...projected], axes };
}

export function hitObjectGizmo(p, gizmo) {
  if (!gizmo || !p) return null;
  const point = Array.isArray(p) ? { x: p[0], y: p[1] } : p;
  if (!Number.isFinite(point.x) || !Number.isFinite(point.y)) return null;
  let best = null;
  for (const [name, axis] of Object.entries(gizmo.axes || {})) {
    const points = axis.points || [];
    let distance = Infinity;
    if (gizmo.mode === 'translate') {
      if (points.length >= 2) distance = gizmoSegmentDistance(point, points[0], points[1]);
    } else {
      for (let i = 1; i < points.length; i++) distance = Math.min(distance, gizmoSegmentDistance(point, points[i - 1], points[i]));
    }
    if (distance <= 12 && (!best || distance < best.distance)) best = { axis: name, axisIndex: axis.index, kind: gizmo.mode, objectId: gizmo.objectId, distance };
  }
  return best;
}

function multiply(a, b) {
  const out = new Float32Array(16);
  for (let column = 0; column < 4; column++) {
    for (let row = 0; row < 4; row++) {
      out[column * 4 + row] = a[row] * b[column * 4] + a[4 + row] * b[column * 4 + 1]
        + a[8 + row] * b[column * 4 + 2] + a[12 + row] * b[column * 4 + 3];
    }
  }
  return out;
}

function lookAt(eye, target) {
  const forward = normalize(subtract(target, eye));
  const right = normalize(cross(forward, [0, 1, 0]));
  const up = cross(right, forward);
  return new Float32Array([
    right[0], up[0], -forward[0], 0,
    right[1], up[1], -forward[1], 0,
    right[2], up[2], -forward[2], 0,
    -dot(right, eye), -dot(up, eye), dot(forward, eye), 1,
  ]);
}

function perspective(fov, aspect, near, far) {
  const f = 1 / Math.tan(fov * Math.PI / 360);
  return new Float32Array([f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, far / (near - far), -1, 0, 0, far * near / (near - far), 0]);
}

function orthographic(left, right, bottom, top, near, far) {
  return new Float32Array([
    2 / (right - left), 0, 0, 0, 0, 2 / (top - bottom), 0, 0,
    0, 0, 1 / (near - far), 0,
    -(right + left) / (right - left), -(top + bottom) / (top - bottom), near / (near - far), 1,
  ]);
}

function transform(position = [0, 0, 0], scale = [1, 1, 1], yaw = 0, inverseScale = false, pitch = 0, orientation = null) {
  const [x, y, z] = inverseScale ? scale.map((v) => 1 / Math.max(0.0001, v)) : scale;
  if (orientation?.length === 4) {
    const length = Math.hypot(...orientation) || 1;
    const [qx, qy, qz, qw] = Array.from(orientation, (value) => value / length);
    const xx = qx * qx, yy = qy * qy, zz = qz * qz;
    const xy = qx * qy, xz = qx * qz, yz = qy * qz;
    const wx = qw * qx, wy = qw * qy, wz = qw * qz;
    return new Float32Array([
      (1 - 2 * (yy + zz)) * x, 2 * (xy + wz) * x, 2 * (xz - wy) * x, 0,
      2 * (xy - wz) * y, (1 - 2 * (xx + zz)) * y, 2 * (yz + wx) * y, 0,
      2 * (xz + wy) * z, 2 * (yz - wx) * z, (1 - 2 * (xx + yy)) * z, 0,
      ...(inverseScale ? [0, 0, 0] : position), 1,
    ]);
  }
  const c = Math.cos(yaw), s = Math.sin(yaw);
  const cp = Math.cos(pitch), sp = Math.sin(pitch);
  return new Float32Array([
    c * x, 0, -s * x, 0,
    s * sp * y, cp * y, c * sp * y, 0,
    s * cp * z, -sp * z, c * cp * z, 0,
    ...(inverseScale ? [0, 0, 0] : position), 1,
  ]);
}

function linearColor(hex, fallback = '#7a8b91') {
  const value = /^#[0-9a-f]{6}$/i.test(hex || '') ? hex : fallback;
  return [1, 3, 5].map((offset) => {
    const c = parseInt(value.slice(offset, offset + 2), 16) / 255;
    return c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  });
}

const shader = /* wgsl */ `
struct Frame {
  viewProjection: mat4x4f,
  lightViewProjection: mat4x4f,
  eye: vec4f,
  light: vec4f,
  skin: vec4f,
  eyes: vec4f,
  lips: vec4f,
  boxers: vec4f,
  settings: vec4f,
  headCenter: vec4f,
  headSize: vec4f,
  ranges: vec4f,
  viewport: vec4f,
  scalp: vec4f,
  top: vec4f,
  bottom: vec4f,
  torso: vec4f,
  limbs: vec4f,
  chest: vec4f,
  face: vec4f,
  faceShape: vec4f,
  interior: vec4f,
  seam: vec4f,
};
struct Object {
  model: mat4x4f,
  normalMatrix: mat4x4f,
  color: vec4f,
  settings: vec4f,
};
@group(0) @binding(0) var<uniform> frame: Frame;
@group(1) @binding(0) var<storage, read> positions: array<vec4f>;
@group(1) @binding(1) var<storage, read> normals: array<vec4f>;
@group(1) @binding(2) var<storage, read> restPositions: array<vec4f>;
@group(1) @binding(3) var<uniform> object: Object;
@group(2) @binding(0) var shadowTexture: texture_depth_2d;
@group(2) @binding(1) var shadowSampler: sampler_comparison;
@group(3) @binding(0) var bodyPaintTexture: texture_2d<f32>;
@group(3) @binding(1) var bodyDetailTexture: texture_2d<f32>;

struct VertexOutput {
  @builtin(position) position: vec4f,
  @location(0) world: vec3f,
  @location(1) normal: vec3f,
  @location(2) rest: vec3f,
  @location(3) paint: vec4f,
};
fn localPosition(index: u32) -> vec3f {
  let p = positions[index];
  if (object.settings.y > 1.5) {
    return p.xyz * object.settings.z + vec3f(0.0, p.w * object.settings.w, 0.0);
  }
  return p.xyz;
}
fn transformedVertex(index: u32) -> VertexOutput {
  var out: VertexOutput;
  let world = object.model * vec4f(localPosition(index), 1.0);
  out.position = frame.viewProjection * world;
  out.world = world.xyz;
  out.normal = (object.normalMatrix * vec4f(normals[index].xyz, 0.0)).xyz;
  out.rest = restPositions[index].xyz;
  out.paint = vec4f(0.0);
  return out;
}
@vertex fn vsMain(@builtin(vertex_index) index: u32) -> VertexOutput {
  var out = transformedVertex(index);
  if (object.settings.x < 0.5) {
    let texel = vec2i(i32(index % 1024u), i32(index / 1024u));
    out.paint = textureLoad(bodyPaintTexture, texel, 0);
  }
  return out;
}
@vertex fn vsWire(@builtin(vertex_index) index: u32) -> VertexOutput {
  var out = transformedVertex(index);
  out.position.z -= 0.00008 * out.position.w;
  return out;
}
@vertex fn vsShadow(@builtin(vertex_index) index: u32) -> @builtin(position) vec4f {
  return frame.lightViewProjection * object.model * vec4f(localPosition(index), 1.0);
}
fn hash31(p: vec3f) -> f32 {
  var q = fract(p * 0.1031);
  q += vec3f(dot(q, q.yzx + vec3f(33.33)));
  return fract((q.x + q.y) * q.z);
}
fn ellipse(p: vec2f, radii: vec2f, softness: f32) -> f32 {
  let radius = length(p / radii);
  let edge = max(softness, 0.001);
  return 1.0 - smoothstep(1.0 - edge, 1.0 + edge, radius);
}
fn displayColor(color: vec3f) -> vec3f {
  let mapped = clamp((color * (2.51 * color + vec3f(0.03))) / (color * (2.43 * color + vec3f(0.59)) + vec3f(0.14)), vec3f(0.0), vec3f(1.0));
  return pow(mapped, vec3f(1.0 / 2.2));
}
fn shadowVisibility(world: vec3f, normal: vec3f) -> f32 {
  let lightClip = frame.lightViewProjection * vec4f(world, 1.0);
  let lightNdc = lightClip.xyz / lightClip.w;
  let uv = lightNdc.xy * vec2f(0.5, -0.5) + vec2f(0.5);
  if (any(uv < vec2f(0.001)) || any(uv > vec2f(0.999)) || lightNdc.z < 0.0 || lightNdc.z > 1.0) {
    return 1.0;
  }
  let bias = 0.00045 + 0.0012 * (1.0 - max(0.0, dot(normal, normalize(frame.light.xyz))));
  let texel = 1.0 / vec2f(textureDimensions(shadowTexture));
  var visibility = 0.0;
  for (var y = -1; y <= 1; y++) {
    for (var x = -1; x <= 1; x++) {
      visibility += textureSampleCompareLevel(shadowTexture, shadowSampler, uv + vec2f(f32(x), f32(y)) * texel, lightNdc.z - bias);
    }
  }
  return visibility / 9.0;
}
fn gridLine(p: vec2f, spacing: f32) -> f32 {
  let coordinate = p / spacing;
  let cell = abs(fract(coordinate - vec2f(0.5)) - vec2f(0.5)) / max(fwidth(coordinate), vec2f(0.0001));
  return 1.0 - min(min(cell.x, cell.y), 1.0);
}
fn earCoordinates(h: vec3f) -> vec2f {
  let center = vec2f((frame.faceShape.z - frame.headCenter.z) / frame.headSize.z,
    (frame.faceShape.y - frame.headCenter.y) / frame.headSize.y);
  return (h.zy - center) / vec2f(0.255, 0.30);
}
fn earMask(h: vec3f) -> f32 {
  let radius = length(earCoordinates(h));
  let edge = 0.025;
  return (1.0 - smoothstep(1.0 - edge, 1.0 + edge, radius))
    * smoothstep(0.80, 0.93, abs(h.x));
}
fn beardMask(rest: vec3f, h: vec3f) -> f32 {
  let ax = abs(h.x);
  let mouthY = (frame.face.y - frame.headCenter.y) / frame.headSize.y;
  let eyeY = (frame.face.x - frame.headCenter.y) / frame.headSize.y;
  let chinY = (frame.faceShape.x - frame.headCenter.y) / frame.headSize.y;
  let edge = 0.014;
  // One band along the jaw: stays low at the chin, then rises to the ear lobe at the back.
  let curveT = smoothstep(0.30, 0.98, ax);
  let bandCenter = mix(chinY + 0.15, eyeY - 0.50, curveT);
  let bandHalf = mix(0.12, 0.09, curveT);
  let wobble = 0.010 * sin(rest.x * 150.0 + rest.z * 60.0) + 0.006 * sin(rest.x * 310.0 - rest.y * 90.0);
  let jawBand = 1.0 - smoothstep(bandHalf - edge + wobble, bandHalf + edge + wobble, abs(h.y - bandCenter));
  // Stay on the face: above the under-jaw line, on the front half of the head.
  let lowerLine = chinY + 0.12 * smoothstep(0.20, 0.95, ax);
  let headBounds = smoothstep(lowerLine - edge, lowerLine + edge, h.y)
    * (1.0 - smoothstep(0.96, 1.06, ax)) * smoothstep(-0.08, 0.06, h.z);
  let lipCurve = h.y - mouthY - 0.13 * h.x * h.x;
  let cleanLips = ellipse(vec2f(h.x, lipCurve), vec2f(0.34, 0.09), 0.20);
  return jawBand * headBounds * (1.0 - cleanLips) * (1.0 - earMask(h));
}
fn scalpMask(h: vec3f) -> f32 {
  let front = smoothstep(-0.08, 0.78, h.z);
  let temple = smoothstep(0.45, 0.92, abs(h.x));
  let forehead = 0.58 + 0.16 * smoothstep(0.3, 0.76, abs(h.x));
  let hairline = mix(-0.53, mix(forehead, 0.1, temple * 0.85), front);
  let sideburn = (1.0 - smoothstep(0.13, 0.22, abs(h.z - 0.25)))
    * smoothstep(0.7, 0.88, abs(h.x)) * smoothstep(-0.42, -0.32, h.y);
  let ear = earMask(h);
  let edge = 0.012 * sin(h.x * 31.0 + h.z * 17.0) + 0.006 * sin(h.x * 73.0 - h.z * 29.0);
  let cap = smoothstep(hairline - 0.016 + edge, hairline + 0.02 + edge, h.y);
  return max(cap, sideburn) * (1.0 - ear) * smoothstep(-0.72, -0.54, h.y);
}
fn scalpStrands(h: vec3f) -> f32 {
  let longitude = atan2(h.x, h.z);
  let crownFlow = longitude * 105.0 + h.y * 13.0 + sin(h.y * 7.0 + longitude * 3.0) * 1.4;
  let attenuation = 0.75;
  let fine = sin(crownFlow) * 0.08 + sin(crownFlow * 1.73 + h.y * 9.0) * 0.035;
  return 0.96 + fine * attenuation;
}
fn clothingMasks(rest: vec3f) -> vec2f {
  let edge = 0.0007;
  let ax = abs(rest.x);
  let legRegion = 1.0 - smoothstep(frame.limbs.z + 0.012, frame.limbs.z + 0.018, ax);
  let hem = select(frame.ranges.x, select(frame.ranges.x - 0.1 * frame.ranges.z / 1.9, frame.limbs.y + 0.025, frame.bottom.w > 1.5), frame.bottom.w > 0.5);
  let bottom = smoothstep(hem - edge, hem + edge, rest.y)
    * (1.0 - smoothstep(frame.ranges.y - edge, frame.ranges.y + edge, rest.y)) * legRegion;
  let arm = smoothstep(frame.torso.z * 1.08, frame.torso.z * 1.3, ax);
  let sleeveY = select(mix(frame.limbs.w, frame.torso.y, 0.3), frame.limbs.x + 0.02, frame.bottom.w > 1.5);
  let topHem = mix(frame.ranges.y - 0.012, sleeveY, arm);
  let front = smoothstep(0.015, 0.09, rest.z);
  let neckRadius = frame.headSize.x * 0.67;
  let neckline = select(frame.torso.x - 0.022 * front, frame.torso.x - 0.14 * front, frame.bottom.w > 1.5);
  let collarRise = select(smoothstep(0.0, neckRadius, ax), clamp(ax / neckRadius, 0.0, 1.0), frame.bottom.w > 1.5);
  let topLimit = mix(neckline, frame.torso.y + 0.025, collarRise);
  let top = smoothstep(topHem - edge, topHem + edge, rest.y)
    * (1.0 - smoothstep(topLimit - edge, topLimit + edge, rest.y)) * step(0.5, frame.bottom.w);
  return vec2f(top, bottom);
}
struct Surface {
  albedo: vec3f,
  roughness: f32,
};
fn bodyMarks(rest: vec3f) -> vec4f {
  let garment = clothingMasks(rest);
  let bare = 1.0 - max(garment.x, garment.y);
  let anterior = smoothstep(frame.chest.z * 0.35, frame.chest.z * 0.72, rest.z);
  let chestMark = ellipse(vec2f(abs(rest.x) - frame.chest.x, rest.y - frame.chest.y),
    vec2f(frame.chest.w * 3.0 * (1.0 + 0.55 * frame.headCenter.w), frame.chest.w * 3.0 * (0.9 + 0.50 * frame.headCenter.w)), 0.27) * anterior * bare;
  let bodyScale = frame.ranges.z / 1.89;
  let navel = ellipse(vec2f(rest.x, rest.y - 1.075 * bodyScale), vec2f(0.0065, 0.009) * bodyScale, 0.28) * anterior * bare;
  let markColor = frame.skin.rgb * vec3f(0.69, 0.46, 0.42);
  return vec4f(markColor, clamp(chestMark * 0.72 + navel * 0.85, 0.0, 1.0));
}
fn skinSurface(rest: vec3f) -> Surface {
  var surface: Surface;
  let poreDetail = 0.65;
  let pores = mix(0.5, hash31(floor(rest * 1400.0)), poreDetail);
  let broad = sin(rest.x * 31.0 + rest.y * 23.0) * sin(rest.z * 29.0 - rest.y * 17.0);
  var color = frame.skin.rgb * (0.995 + (pores - 0.5) * 0.025 + broad * 0.008);
  var roughness = clamp(frame.settings.z, 0.15, 1.0);
  let h = (rest - frame.headCenter.xyz) / frame.headSize.xyz;
  let front = smoothstep(0.34, 0.7, h.z);
  let face = front * (1.0 - smoothstep(1.0, 1.12, abs(h.y)));
  let cheeks = ellipse(vec2f(abs(h.x) - 0.47, h.y + 0.17), vec2f(0.24, 0.21), 0.6) * face;
  color = mix(color, color * vec3f(1.08, 0.91, 0.9), cheeks * 0.36);

  if (frame.settings.x > 0.5) {
    let beard = beardMask(rest, h);
    let coarse = smoothstep(0.25, 0.80, hash31(floor(rest * 700.0)));
    let fine = hash31(floor(rest * 1900.0));
    let strands = 0.5 + 0.5 * sin(abs(rest.x) * 420.0 + rest.z * 90.0 + coarse * 6.283185);
    let stubble = coarse * 0.40 + fine * 0.35 + strands * 0.25;
    var beardColor = frame.scalp.rgb * mix(0.55, 0.92, stubble);
    let sheen = smoothstep(0.55, 0.95, strands);
    beardColor = mix(beardColor, frame.skin.rgb * 0.45, sheen * 0.25);
    color = mix(color, beardColor, beard * (0.92 + stubble * 0.05));
    roughness = mix(roughness, 0.94, beard);
  }
  let garment = clothingMasks(rest);

  let eyeLocal = vec2f(abs(h.x) - 0.335, (rest.y - frame.face.x) / frame.headSize.y);
  let eyeShape = eyeLocal + vec2f(0.0, eyeLocal.x * 0.09);
  if (frame.top.w > 0.5) {
    let lid = ellipse(eyeShape - vec2f(0.0, 0.012), vec2f(0.195, 0.062), 0.5) * face;
    color = mix(color, frame.skin.rgb * vec3f(0.91, 0.79, 0.75), lid * 0.22);
    let lidCurve = eyeShape.y + 0.014 - 0.75 * eyeShape.x * eyeShape.x;
    let lineWidth = 0.004;
    let lashLine = (1.0 - smoothstep(0.003, 0.003 + lineWidth, abs(lidCurve)))
      * (1.0 - smoothstep(0.15, 0.19, abs(eyeShape.x))) * face;
    color = mix(color, frame.skin.rgb * vec3f(0.37, 0.26, 0.24), lashLine * 0.76);
  } else {
    let eyelid = ellipse(eyeShape, vec2f(0.205, 0.074), 0.17) * face;
    let sclera = ellipse(eyeShape, vec2f(0.181, 0.043), 0.13) * face;
    color = mix(color, frame.skin.rgb * vec3f(0.63, 0.45, 0.41), eyelid * 0.66);
    color = mix(color, vec3f(0.68, 0.69, 0.65), sclera);
    let irisP = eyeLocal * vec2f(frame.headSize.x / frame.headSize.y, 1.0);
    let irisR = length(irisP);
    let iris = (1.0 - smoothstep(0.046, 0.057, irisR)) * sclera;
    let irisNoise = 0.76 + 0.25 * sin(atan2(irisP.y, irisP.x) * 31.0 + irisR * 380.0);
    color = mix(color, frame.eyes.rgb * irisNoise, iris);
    let pupil = (1.0 - smoothstep(0.020, 0.028, irisR)) * sclera;
    color = mix(color, vec3f(0.003, 0.005, 0.007), pupil);
    let glint = ellipse(irisP - vec2f(-0.013, 0.020), vec2f(0.008, 0.011), 0.2) * sclera;
    color = mix(color, vec3f(0.94, 0.97, 1.0), glint * 0.92);
    roughness = mix(roughness, 0.23, sclera);
  }
  let browP = vec2f(abs(h.x) - 0.34, (rest.y - frame.face.w) / frame.headSize.y + pow((abs(h.x) - 0.31) * 1.2, 2.0));
  let brow = ellipse(browP, vec2f(0.205, 0.032), 0.3) * face;
  color = mix(color, frame.scalp.rgb * 0.85, brow * (0.68 + pores * 0.2));
  let mouthP = vec2f(h.x, (rest.y - frame.face.y) / frame.headSize.y);
  let mouthCurve = mouthP.y - 0.13 * mouthP.x * mouthP.x;
  let lips = ellipse(vec2f(mouthP.x, mouthCurve), vec2f(0.285, 0.05), 0.16) * face;
  color = mix(color, frame.lips.rgb * (0.91 + pores * 0.15), lips);
  let mouthLine = ellipse(vec2f(mouthP.x, mouthCurve + 0.005), vec2f(0.263, 0.0055), 0.2) * face;
  color = mix(color, frame.lips.rgb * 0.42, mouthLine * 0.68);
  let nostril = ellipse(vec2f(abs(h.x) - 0.105, (rest.y - (frame.face.z - 0.008)) / frame.headSize.y), vec2f(0.047, 0.025), 0.35) * face;
  color = mix(color, frame.skin.rgb * 0.24, nostril * 0.7);
  let ear = earMask(h);
  let earP = earCoordinates(h);
  let earRadius = length(earP);
  let earEdge = 0.035;
  let concha = ellipse(earP - vec2f(0.02, -0.02), vec2f(0.54, 0.65), 0.22) * ear;
  color = mix(color, frame.skin.rgb * vec3f(0.70, 0.47, 0.40), concha * 0.62);
  let helix = (1.0 - smoothstep(0.055, 0.055 + earEdge, abs(earRadius - 0.82))) * ear;
  color = mix(color, frame.skin.rgb * vec3f(1.10, 1.01, 0.94), helix * 0.70);
  let innerRadius = length((earP - vec2f(-0.11, 0.08)) / vec2f(0.49, 0.62));
  let antihelix = (1.0 - smoothstep(0.075, 0.075 + earEdge * 1.8, abs(innerRadius - 1.0)))
    * (1.0 - smoothstep(0.05, 0.55, earP.x)) * ear;
  color = mix(color, frame.skin.rgb * vec3f(1.05, 0.94, 0.87), antihelix * 0.65);
  let canal = ellipse(earP - vec2f(0.20, -0.16), vec2f(0.16, 0.23), 0.30) * ear;
  color = mix(color, frame.skin.rgb * vec3f(0.43, 0.27, 0.23), canal * 0.68);
  let tragus = ellipse(earP - vec2f(0.43, -0.23), vec2f(0.18, 0.28), 0.32) * ear;
  color = mix(color, frame.skin.rgb * vec3f(1.07, 0.98, 0.91), tragus * 0.60);
  let scalp = scalpMask(h) * frame.scalp.w;
  color = mix(color, frame.scalp.rgb * scalpStrands(h), scalp);
  roughness = mix(roughness, 0.84, scalp);

  let bottomColor = select(frame.boxers.rgb, frame.bottom.rgb, frame.bottom.w > 0.5);
  color = mix(color, bottomColor, garment.y);
  color = mix(color, frame.top.rgb, garment.x);
  let fatFoldX=abs(rest.x);
  let bellyFoldY=1.008+0.020*min(1.0,fatFoldX/0.29);
  let bellyFold=exp(-pow(fatFoldX/0.23,2.0))*exp(-pow((rest.y-bellyFoldY)/0.014,2.0));
  let chestFold=exp(-pow((fatFoldX-0.11)/0.10,2.0))*exp(-pow((rest.y-1.290)/0.014,2.0));
  let folds=frame.headCenter.w*smoothstep(0.025,0.075,rest.z)*(bellyFold+chestFold);
  color*=1.0-clamp(folds,0.0,1.0)*0.11;
  roughness = mix(roughness, 0.88, max(garment.x, garment.y));
  surface.albedo = color;
  surface.roughness = roughness;
  return surface;
}
@vertex fn vsPaintBake(@builtin(vertex_index) index: u32) -> @builtin(position) vec4f {
  let p = array<vec2f, 3>(vec2f(-1.0, -1.0), vec2f(3.0, -1.0), vec2f(-1.0, 3.0));
  return vec4f(p[index], 0.0, 1.0);
}
@fragment fn fsPaintBake(@builtin(position) position: vec4f) -> @location(0) vec4f {
  let pixel = vec2u(floor(position.xy));
  let index = pixel.y * 1024u + pixel.x;
  if (index >= arrayLength(&restPositions)) { discard; }
  let surface = skinSurface(restPositions[index].xyz);
  return vec4f(surface.albedo, surface.roughness);
}
@fragment fn fsDetailBake(@builtin(position) position: vec4f) -> @location(0) vec4f {
  let uv = position.xy / 512.0;
  let rest = vec3f((uv.x - 0.5) * 0.72, 0.78 + uv.y * 0.75, frame.chest.z);
  return bodyMarks(rest);
}
@fragment fn fsMain(input: VertexOutput, @builtin(front_facing) frontFacing: bool) -> @location(0) vec4f {
  var n = normalize(input.normal);
  if (!frontFacing) { n = -n; }
  var surface: Surface;
  surface.albedo = object.color.rgb;
  surface.roughness = 0.46;
  let seamWidth = max(fwidth(input.rest.x) * 0.75, 0.0005);
  if (object.settings.x < 0.5) {
    surface.albedo = input.paint.rgb;
    surface.roughness = input.paint.a;
    // The per-vertex appearance bake loses small face features on coarse meshes; when the
    // per-pixel shading mode is selected the head is evaluated analytically per fragment.
    let headLocal = (input.rest - frame.headCenter.xyz) / frame.headSize.xyz;
    let headWeight = (1.0 - smoothstep(1.03, 1.18, abs(headLocal.x)))
      * (1.0 - smoothstep(1.05, 1.25, abs(headLocal.y)))
      * smoothstep(0.4, 0.6, frame.settings.y);
    if (headWeight > 0.0) {
      let headSurface = skinSurface(input.rest);
      surface.albedo = mix(surface.albedo, headSurface.albedo, headWeight);
      surface.roughness = mix(surface.roughness, headSurface.roughness, headWeight);
    }
    let detailUv = vec2f(input.rest.x / 0.72 + 0.5, (input.rest.y - 0.78) / 0.75);
    if (frontFacing && all(detailUv >= vec2f(0.0)) && all(detailUv <= vec2f(1.0))) {
      let detail = textureLoad(bodyDetailTexture, vec2i(detailUv * 512.0), 0);
      let anterior = smoothstep(frame.chest.z * 0.35, frame.chest.z * 0.72, input.rest.z);
      surface.albedo = mix(surface.albedo, detail.rgb, detail.a * anterior);
    }
    if (!frontFacing) {
      surface.albedo = frame.interior.rgb;
      surface.roughness = 0.72;
    } else {
      let spineX = 1.0 - smoothstep(0.008, 0.013 + seamWidth, abs(input.rest.x));
      let spineY = smoothstep(0.78, 0.82, input.rest.y) * (1.0 - smoothstep(1.56, 1.62, input.rest.y));
      let back = 1.0 - smoothstep(-0.025, 0.005, input.rest.z);
      let seam = spineX * spineY * back * clamp(frame.interior.w, 0.0, 1.0);
      surface.albedo = mix(surface.albedo, frame.seam.rgb, seam);
      surface.roughness = mix(surface.roughness, 0.88, seam);
    }
  } else if (object.settings.x < 1.5) {
    let distanceFade = 1.0 - smoothstep(2.5, 13.0, distance(input.world.xz, frame.eye.xz));
    let grid = gridLine(input.world.xz, 0.25) * 0.24 + gridLine(input.world.xz, 1.0) * 0.42;
    let axis = 1.0 - smoothstep(0.001, 0.004 + max(fwidth(input.world.x), fwidth(input.world.z)), min(abs(input.world.x), abs(input.world.z)));
    surface.albedo = mix(vec3f(0.008, 0.014, 0.020), vec3f(0.026, 0.040, 0.047), grid * distanceFade);
    surface.albedo = mix(surface.albedo, vec3f(0.026, 0.075, 0.079), axis * distanceFade * 0.48);
    surface.roughness = 0.94;
  }
  let l = normalize(frame.light.xyz);
  let v = normalize(frame.eye.xyz - input.world);
  let h = normalize(l + v);
  let nl = max(dot(n, l), 0.0);
  let nv = max(dot(n, v), 0.001);
  let nh = max(dot(n, h), 0.0);
  let vh = max(dot(v, h), 0.0);
  let alpha = surface.roughness * surface.roughness;
  let a2 = alpha * alpha;
  let denominator = nh * nh * (a2 - 1.0) + 1.0;
  let distribution = a2 / max(3.14159265 * denominator * denominator, 0.0001);
  let k = pow(surface.roughness + 1.0, 2.0) / 8.0;
  let geometry = (nv / (nv * (1.0 - k) + k)) * (nl / (nl * (1.0 - k) + k));
  let fresnel = vec3f(0.035) + vec3f(0.965) * pow(1.0 - vh, 5.0);
  let specular = distribution * geometry * fresnel / max(4.0 * nv * nl, 0.001);
  let shadow = shadowVisibility(input.world, n);
  let key = vec3f(1.0, 0.91, 0.81) * 1.55;
  let ambient = mix(vec3f(0.20, 0.23, 0.25), vec3f(0.34, 0.41, 0.46), n.y * 0.5 + 0.5);
  let fill = vec3f(0.30, 0.49, 0.57) * max(dot(n, normalize(vec3f(3.0, 2.0, -3.0))), 0.0) * 0.66;
  let rim = vec3f(0.09, 0.19, 0.21) * pow(1.0 - nv, 3.0) * max(n.z * -0.4 + 0.6, 0.0);
  var color = surface.albedo * (ambient + fill + key * nl * (0.2 + shadow * 0.8)) + specular * key * nl * shadow + rim;
  if (object.settings.x > 0.5 && object.settings.x < 1.5) {
    let fog = 1.0 - exp(-distance(input.world, frame.eye.xyz) * 0.035);
    color = mix(color, vec3f(0.0036, 0.0065, 0.009), fog);
  }
  return vec4f(displayColor(color), 1.0);
}
@fragment fn fsWire() -> @location(0) vec4f {
  return vec4f(0.35, 0.82, 0.77, 0.33);
}
struct BackgroundOutput {
  @builtin(position) position: vec4f,
  @location(0) uv: vec2f,
};
@vertex fn vsBackground(@builtin(vertex_index) index: u32) -> BackgroundOutput {
  let p = array<vec2f, 3>(vec2f(-1.0, -1.0), vec2f(3.0, -1.0), vec2f(-1.0, 3.0));
  var out: BackgroundOutput;
  out.position = vec4f(p[index], 0.9999, 1.0);
  out.uv = p[index] * 0.5 + vec2f(0.5);
  return out;
}
@fragment fn fsBackground(input: BackgroundOutput) -> @location(0) vec4f {
  let glow = exp(-dot((input.uv - vec2f(0.48, 0.46)) * vec2f(1.3, 1.0), (input.uv - vec2f(0.48, 0.46)) * vec2f(1.3, 1.0)) * 3.2);
  let color = mix(vec3f(0.035, 0.052, 0.075), vec3f(0.083, 0.139, 0.159), glow * 0.9);
  return vec4f(color, 1.0);
}
struct OverlayOutput {
  @builtin(position) position: vec4f,
  @location(0) color: vec4f,
};
@vertex fn vsOverlay(@location(0) position: vec3f, @location(1) color: vec4f) -> OverlayOutput {
  var out: OverlayOutput;
  out.position = frame.viewProjection * vec4f(position, 1.0);
  out.color = color;
  return out;
}
@fragment fn fsOverlay(input: OverlayOutput) -> @location(0) vec4f {
  return input.color;
}
`;

function boxData() {
  const positions = [], normals = [], indices = [];
  const faces = [
    [[1, 0, 0], [[0.5, -0.5, -0.5], [0.5, 0.5, -0.5], [0.5, 0.5, 0.5], [0.5, -0.5, 0.5]]],
    [[-1, 0, 0], [[-0.5, -0.5, 0.5], [-0.5, 0.5, 0.5], [-0.5, 0.5, -0.5], [-0.5, -0.5, -0.5]]],
    [[0, 1, 0], [[-0.5, 0.5, 0.5], [0.5, 0.5, 0.5], [0.5, 0.5, -0.5], [-0.5, 0.5, -0.5]]],
    [[0, -1, 0], [[-0.5, -0.5, -0.5], [0.5, -0.5, -0.5], [0.5, -0.5, 0.5], [-0.5, -0.5, 0.5]]],
    [[0, 0, 1], [[0.5, -0.5, 0.5], [0.5, 0.5, 0.5], [-0.5, 0.5, 0.5], [-0.5, -0.5, 0.5]]],
    [[0, 0, -1], [[-0.5, -0.5, -0.5], [-0.5, 0.5, -0.5], [0.5, 0.5, -0.5], [0.5, -0.5, -0.5]]],
  ];
  for (const [normal, vertices] of faces) {
    const offset = positions.length / 4;
    for (const vertex of vertices) { positions.push(...vertex, 1); normals.push(...normal, 0); }
    indices.push(offset, offset + 1, offset + 2, offset, offset + 2, offset + 3);
  }
  return { positions: new Float32Array(positions), normals: new Float32Array(normals), indices: new Uint32Array(indices) };
}

function sphereData(capsule = false, slices = 48, stacks = 32) {
  const positions = [], normals = [], indices = [];
  const rings = [];
  for (let row = 0; row <= stacks; row++) {
    const angle = row / stacks * Math.PI;
    rings.push({ angle, side: row <= stacks / 2 ? 1 : -1 });
    if (capsule && row === stacks / 2) rings.push({ angle, side: -1 });
  }
  for (const ring of rings) {
    for (let column = 0; column <= slices; column++) {
      const angle = column / slices * TAU;
      const normal = [Math.sin(ring.angle) * Math.cos(angle), Math.cos(ring.angle), Math.sin(ring.angle) * Math.sin(angle)];
      positions.push(...normal, capsule ? ring.side : 1);
      normals.push(...normal, 0);
    }
  }
  for (let row = 0; row < rings.length - 1; row++) {
    for (let column = 0; column < slices; column++) {
      const a = row * (slices + 1) + column, b = a + slices + 1;
      indices.push(a, a + 1, b, a + 1, b + 1, b);
    }
  }
  return { positions: new Float32Array(positions), normals: new Float32Array(normals), indices: new Uint32Array(indices) };
}

export async function createRenderer(device, canvas, format) {
  const context = canvas.getContext('webgpu');
  if (!context) throw new Error('无法创建 WebGPU 画布上下文。');
  format ||= navigator.gpu.getPreferredCanvasFormat();
  context.configure({ device, format, alphaMode: 'opaque' });

  const module = device.createShaderModule({ label: 'Cloth studio lighting and materials', code: shader });
  const compilation = await module.getCompilationInfo();
  const errors = compilation.messages.filter((message) => message.type === 'error');
  if (errors.length) throw new Error(`渲染着色器编译失败：\n${errors.map((error) => `第 ${error.lineNum} 行，第 ${error.linePos} 列：${error.message}`).join('\n')}`);

  const frameLayout = device.createBindGroupLayout({ label: 'Camera and appearance layout', entries: [
    { binding: 0, visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT, buffer: { type: 'uniform' } },
  ] });
  const objectLayout = device.createBindGroupLayout({ label: 'Shared simulation geometry layout', entries: [
    { binding: 0, visibility: GPUShaderStage.VERTEX, buffer: { type: 'read-only-storage' } },
    { binding: 1, visibility: GPUShaderStage.VERTEX, buffer: { type: 'read-only-storage' } },
    { binding: 2, visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT, buffer: { type: 'read-only-storage' } },
    { binding: 3, visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT, buffer: { type: 'uniform' } },
  ] });
  const shadowLayout = device.createBindGroupLayout({ label: 'Filtered shadow map layout', entries: [
    { binding: 0, visibility: GPUShaderStage.FRAGMENT, texture: { sampleType: 'depth' } },
    { binding: 1, visibility: GPUShaderStage.FRAGMENT, sampler: { type: 'comparison' } },
  ] });
  const paintLayout = device.createBindGroupLayout({ label: 'Cached body paint image layout', entries: [
    { binding: 0, visibility: GPUShaderStage.VERTEX, texture: { sampleType: 'float' } },
    { binding: 1, visibility: GPUShaderStage.FRAGMENT, texture: { sampleType: 'float' } },
  ] });
  const layout = device.createPipelineLayout({ bindGroupLayouts: [frameLayout, objectLayout, shadowLayout, paintLayout] });
  const geometryLayout = device.createPipelineLayout({ bindGroupLayouts: [frameLayout, objectLayout] });
  const simpleLayout = device.createPipelineLayout({ bindGroupLayouts: [frameLayout] });
  const blend = { color: { srcFactor: 'src-alpha', dstFactor: 'one-minus-src-alpha', operation: 'add' }, alpha: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha', operation: 'add' } };
  const sampleCount = 4;
  const depthFormat = 'depth24plus';
  const [mainPipeline, shadowPipeline, wirePipeline, ragdollWirePipeline, paintPipeline, detailPipeline, backgroundPipeline, overlayPipeline] = await Promise.all([
    device.createRenderPipelineAsync({
      label: 'Smooth double-sided studio materials', layout,
      vertex: { module, entryPoint: 'vsMain' }, fragment: { module, entryPoint: 'fsMain', targets: [{ format }] },
      primitive: { topology: 'triangle-list', cullMode: 'none' },
      depthStencil: { format: depthFormat, depthWriteEnabled: true, depthCompare: 'less' }, multisample: { count: sampleCount },
    }),
    device.createRenderPipelineAsync({
      label: 'Real geometry shadow map', layout: geometryLayout,
      vertex: { module, entryPoint: 'vsShadow' }, primitive: { topology: 'triangle-list', cullMode: 'none' },
      depthStencil: { format: 'depth32float', depthWriteEnabled: true, depthCompare: 'less', depthBias: 2, depthBiasSlopeScale: 2 },
    }),
    device.createRenderPipelineAsync({
      label: 'Actual triangle edges', layout: geometryLayout,
      vertex: { module, entryPoint: 'vsWire' }, fragment: { module, entryPoint: 'fsWire', targets: [{ format, blend }] },
      primitive: { topology: 'line-list' },
      depthStencil: { format: depthFormat, depthWriteEnabled: false, depthCompare: 'less-equal' }, multisample: { count: sampleCount },
    }),
    device.createRenderPipelineAsync({
      label: 'Ragdoll wireframe colliders', layout: geometryLayout,
      vertex: { module, entryPoint: 'vsWire' }, fragment: { module, entryPoint: 'fsWire', targets: [{ format, blend }] },
      primitive: { topology: 'line-list' },
      depthStencil: { format: depthFormat, depthWriteEnabled: false, depthCompare: 'always' }, multisample: { count: sampleCount },
    }),
    device.createRenderPipelineAsync({
      label: 'Cached body paint bake', layout: geometryLayout,
      vertex: { module, entryPoint: 'vsPaintBake' }, fragment: { module, entryPoint: 'fsPaintBake', targets: [{ format: 'rgba16float' }] },
      primitive: { topology: 'triangle-list', cullMode: 'none' },
    }),
    device.createRenderPipelineAsync({
      label: 'Cached body detail image bake', layout: geometryLayout,
      vertex: { module, entryPoint: 'vsPaintBake' }, fragment: { module, entryPoint: 'fsDetailBake', targets: [{ format: 'rgba16float' }] },
      primitive: { topology: 'triangle-list', cullMode: 'none' },
    }),
    device.createRenderPipelineAsync({
      label: 'Studio background', layout: simpleLayout,
      vertex: { module, entryPoint: 'vsBackground' }, fragment: { module, entryPoint: 'fsBackground', targets: [{ format }] },
      primitive: { topology: 'triangle-list' },
      depthStencil: { format: depthFormat, depthWriteEnabled: false, depthCompare: 'always' }, multisample: { count: sampleCount },
    }),
    device.createRenderPipelineAsync({
      label: 'Rig and grab overlay', layout: simpleLayout,
      vertex: { module, entryPoint: 'vsOverlay', buffers: [{ arrayStride: 28, attributes: [
        { shaderLocation: 0, offset: 0, format: 'float32x3' }, { shaderLocation: 1, offset: 12, format: 'float32x4' },
      ] }] }, fragment: { module, entryPoint: 'fsOverlay', targets: [{ format, blend }] },
      primitive: { topology: 'line-list' },
      depthStencil: { format: depthFormat, depthWriteEnabled: false, depthCompare: 'always' }, multisample: { count: sampleCount },
    }),
  ]);

  const ownedBuffers = new Set();
  function buffer(dataOrSize, usage, label) {
    const data = typeof dataOrSize === 'number' ? null : dataOrSize;
    const size = Math.max(4, Math.ceil((data ? data.byteLength : dataOrSize) / 4) * 4);
    const result = device.createBuffer({ label, size, usage: usage | GPUBufferUsage.COPY_DST });
    if (data) device.queue.writeBuffer(result, 0, data);
    ownedBuffers.add(result);
    return result;
  }
  function release(resource) {
    if (resource && ownedBuffers.delete(resource)) resource.destroy();
  }
  const frameBuffer = buffer(464, GPUBufferUsage.UNIFORM, 'Camera, lights, and appearance');
  const frameGroup = device.createBindGroup({ layout: frameLayout, entries: [{ binding: 0, resource: { buffer: frameBuffer } }] });
  const shadowSize = 2048;
  const shadowTexture = device.createTexture({ label: '2048px real-time shadow depth', size: [shadowSize, shadowSize], format: 'depth32float', usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING });
  const shadowView = shadowTexture.createView();
  const shadowGroup = device.createBindGroup({ layout: shadowLayout, entries: [
    { binding: 0, resource: shadowView },
    { binding: 1, resource: device.createSampler({ compare: 'less-equal', minFilter: 'linear', magFilter: 'linear', addressModeU: 'clamp-to-edge', addressModeV: 'clamp-to-edge' }) },
  ] });
  function geometry(data, label) {
    const edges = [], seen = new Set(), count = data.positions.length / 4;
    for (let i = 0; i < data.indices.length; i += 3) for (let j = 0; j < 3; j++) {
      const a = data.indices[i + j], b = data.indices[i + (j + 1) % 3], key = Math.min(a, b) * count + Math.max(a, b);
      if (!seen.has(key)) { seen.add(key); edges.push(a, b); }
    }
    return {
      positions: buffer(data.positions, GPUBufferUsage.STORAGE, `${label} positions`),
      normals: buffer(data.normals, GPUBufferUsage.STORAGE, `${label} normals`),
      indices: buffer(data.indices, GPUBufferUsage.INDEX, `${label} triangles`),
      wireIndices: buffer(new Uint32Array(edges), GPUBufferUsage.INDEX, `${label} wire edges`), wireCount: edges.length,
      count: data.indices.length,
    };
  }
  function drawable(shape, label, rest = shape.positions) {
    const uniform = buffer(160, GPUBufferUsage.UNIFORM, `${label} transform`);
    const bindGroup = device.createBindGroup({ layout: objectLayout, entries: [
      { binding: 0, resource: { buffer: shape.positions } },
      { binding: 1, resource: { buffer: shape.normals } },
      { binding: 2, resource: { buffer: rest } },
      { binding: 3, resource: { buffer: uniform } },
    ] });
    return { shape, uniform, bindGroup };
  }
  function updateObject(item, position, scale, yaw, color, settings, pitch = 0, orientation = null) {
    const data = new Float32Array(40);
    data.set(transform(position, scale, yaw, false, pitch, orientation), 0);
    data.set(transform(position, scale, yaw, true, pitch, orientation), 16);
    data.set([...color, 1], 32);
    data.set(settings, 36);
    device.queue.writeBuffer(item.uniform, 0, data);
  }
  const primitives = {
    box: geometry(boxData(), 'Box collider'),
    sphere: geometry(sphereData(), 'Sphere collider'),
    capsule: geometry(sphereData(true), 'Capsule collider'),
  };
  // Ragdoll bodies are debug hulls; a coarse surface is enough and keeps the wire pass cheap.
  const ragdollPrimitives = {
    box: geometry(boxData(), 'Ragdoll box hull'),
    sphere: geometry(sphereData(false, 12, 8), 'Ragdoll sphere hull'),
    capsule: geometry(sphereData(true, 12, 8), 'Ragdoll capsule hull'),
  };
  const floorShape = geometry({
    positions: new Float32Array([-100, 0, -100, 1, -100, 0, 100, 1, 100, 0, 100, 1, 100, 0, -100, 1]),
    normals: new Float32Array([0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0]),
    indices: new Uint32Array([0, 1, 2, 0, 2, 3]),
  }, 'Studio ground');
  const floor = drawable(floorShape, 'Studio ground');
  updateObject(floor, [0, -0.0005, 0], [1, 1, 1], 0, [0.03, 0.04, 0.05], [1, 0, 0, 0]);
  const colliderObjects = new Map();
  const ragdollColliderCache = [];
  let ragdollShapes = [];
  const overlayBuffer = buffer(65536, GPUBufferUsage.VERTEX, 'Rig and grab line vertices');
  const lightDirection = [-3.5, 5, 4];
  const lightTarget = [0, 0.8, 0];
  const lightEye = lightDirection.map((v, i) => v + lightTarget[i]);
  const lightMatrix = multiply(orthographic(-3.2, 3.2, -3.2, 3.2, 0.1, 14), lookAt(lightEye, lightTarget));
  const frameData = new Float32Array(116);
  let body = null, meshMetadata = {}, wireBuffer = null, wireCount = 0, restBuffer = null, bodyIndexBuffer = null;
  let depthTexture = null, colorTexture = null, depthView = null, colorView = null;
  let width = 0, height = 0, disposed = false;
  let bodyPaintTexture = null, bodyPaintView = null, bodyPaintGroup = null, bodyPaintKey = null, bodyPaintUpdates = 0;
  const bodyDetailTexture = device.createTexture({ label: 'Cached chest and navel detail image', size: [512, 512], format: 'rgba16float', usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING });
  const bodyDetailView = bodyDetailTexture.createView();

  function allocateBodyPaint(vertexCount = 1) {
    bodyPaintTexture?.destroy();
    bodyPaintTexture = device.createTexture({ label: 'Cached body appearance image', size: [1024, Math.max(1, Math.ceil(vertexCount / 1024))], format: 'rgba16float', usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING });
    bodyPaintView = bodyPaintTexture.createView();
    bodyPaintGroup = device.createBindGroup({ layout: paintLayout, entries: [{ binding: 0, resource: bodyPaintView }, { binding: 1, resource: bodyDetailView }] });
    bodyPaintKey = null;
  }
  allocateBodyPaint();

  function updateBodyPaint(appearance) {
    if (!body) return;
    const key = JSON.stringify(['skin', 'eyes', 'lips', 'boxers', 'hairColor', 'topColor', 'bottomColor', 'beard', 'scalpHair', 'eyesClosed', 'clothing', 'roughness'].map(name => appearance[name]));
    if (key === bodyPaintKey) return;
    const encoder = device.createCommandEncoder({ label: 'Bake changed body appearance once' });
    const pass = encoder.beginRenderPass({ colorAttachments: [{ view: bodyPaintView, clearValue: { r: 0, g: 0, b: 0, a: 0 }, loadOp: 'clear', storeOp: 'store' }] });
    pass.setPipeline(paintPipeline); pass.setBindGroup(0, frameGroup); pass.setBindGroup(1, body.bindGroup); pass.draw(3); pass.end();
    const detailPass = encoder.beginRenderPass({ colorAttachments: [{ view: bodyDetailView, clearValue: { r: 0, g: 0, b: 0, a: 0 }, loadOp: 'clear', storeOp: 'store' }] });
    detailPass.setPipeline(detailPipeline); detailPass.setBindGroup(0, frameGroup); detailPass.setBindGroup(1, body.bindGroup); detailPass.draw(3); detailPass.end();
    device.queue.submit([encoder.finish()]);
    bodyPaintKey = key; bodyPaintUpdates++;
  }

  function resize() {
    const dpr = Math.min(globalThis.devicePixelRatio || 1, 2);
    const bounds = canvas.getBoundingClientRect();
    const max = device.limits.maxTextureDimension2D;
    const w = Math.max(1, Math.min(max, Math.round((bounds.width || canvas.clientWidth || 1) * dpr)));
    const h = Math.max(1, Math.min(max, Math.round((bounds.height || canvas.clientHeight || 1) * dpr)));
    if (w === width && h === height) return false;
    width = canvas.width = w;
    height = canvas.height = h;
    depthTexture?.destroy();
    colorTexture?.destroy();
    depthTexture = device.createTexture({ label: 'MSAA viewport depth', size: [width, height], sampleCount, format: depthFormat, usage: GPUTextureUsage.RENDER_ATTACHMENT });
    colorTexture = device.createTexture({ label: 'MSAA viewport color', size: [width, height], sampleCount, format, usage: GPUTextureUsage.RENDER_ATTACHMENT });
    depthView = depthTexture.createView();
    colorView = colorTexture.createView();
    return true;
  }

  function setMesh(mesh, solver) {
    if (disposed) return;
    release(body?.uniform);
    release(restBuffer);
    release(bodyIndexBuffer);
    release(wireBuffer);
    restBuffer = buffer(mesh.positions, GPUBufferUsage.STORAGE, 'Immutable rest-surface material coordinates');
    bodyIndexBuffer = buffer(mesh.indices, GPUBufferUsage.INDEX, 'Mannequin triangles');
    body = drawable({ positions: solver.positions, normals: solver.normals, indices: bodyIndexBuffer, count: mesh.indices.length }, 'Simulated mannequin', restBuffer);
    allocateBodyPaint(mesh.vertexCount || mesh.positions.length / 4);
    updateObject(body, [0, 0, 0], [1, 1, 1], 0, [1, 1, 1], [0, 0, 0, 0]);
    meshMetadata = mesh.metadata || {};
    const joints = Object.fromEntries((mesh.bones || []).map((bone) => [bone.name, bone.position]));
    const shoulder = joints['upperArm.L'];
    if (shoulder) {
      const shoulderHalfWidth = Math.abs(shoulder[0]) / 0.94;
      let hipHalfWidth = 0, chestWidth = 0, chestFrontZ = 0;
      for (let i = 0; i < mesh.positions.length; i += 4) {
        const x = Math.abs(mesh.positions[i]), y = mesh.positions[i + 1], z = mesh.positions[i + 2];
        if (x < shoulderHalfWidth * 1.2 && y > (meshMetadata.boxerMin ?? 0.79) - 0.1 && y < (meshMetadata.boxerMax ?? 1.035) + 0.02) {
          hipHalfWidth = Math.max(hipHalfWidth, x);
        }
        if (x < shoulderHalfWidth * 0.9 && y > 1.35 && y < 1.44) {
          chestWidth = Math.max(chestWidth, x);
          chestFrontZ = Math.max(chestFrontZ, z);
        }
      }
      meshMetadata = { ...meshMetadata, appearance: {
        neckBaseY: (joints.neck?.[1] ?? 1.578) - 0.035,
        shoulderY: shoulder[1] + 0.035,
        shoulderHalfWidth,
        elbowY: joints['forearm.L']?.[1],
        wristY: joints['hand.L']?.[1],
        ankleY: joints['foot.L']?.[1],
        chestY: (joints.chest?.[1] ?? 1.38) - 0.013,
        chestHalfWidth: chestWidth * 0.48,
        chestFrontZ,
        hipHalfWidth,
        ...meshMetadata.appearance,
      } };
    }
    const edges = [], seen = new Set();
    const count = mesh.vertexCount || mesh.positions.length / 4;
    for (let i = 0; i < mesh.indices.length; i += 3) {
      for (let j = 0; j < 3; j++) {
        const a = mesh.indices[i + j], b = mesh.indices[i + (j + 1) % 3];
        const key = Math.min(a, b) * count + Math.max(a, b);
        if (!seen.has(key)) { seen.add(key); edges.push(a, b); }
      }
    }
    wireCount = edges.length;
    wireBuffer = buffer(new Uint32Array(edges), GPUBufferUsage.INDEX, 'Unique triangle edges');
  }

  function updateRagdollShapes(list = []) {
    ragdollShapes = Array.isArray(list) ? list : [];
  }

  function updateColliders(colliders) {
    const active = new Set();
    const solid = [], wire = [];
    for (let i = 0; i < colliders.length; i++) {
      const collider = colliders[i];
      const key = collider.id ?? i;
      active.add(key);
      const type = collider.type || 'box';
      const shape = (collider.wireframe ? ragdollPrimitives : primitives)[type];
      if (!shape) continue;
      let item = colliderObjects.get(key);
      if (!item || item.shape !== shape) {
        release(item?.uniform);
        item = drawable(shape, `Collider ${key}`);
        colliderObjects.set(key, item);
      }
      let scale = collider.size || [0.5, 0.5, 0.5];
      let settings = [2, 0, 0, 0];
      if (type === 'sphere') {
        const radius = collider.radius ?? 0.25;
        scale = [radius, radius, radius];
      } else if (type === 'capsule') {
        const radius = collider.radius ?? 0.2;
        const height = collider.height ?? 0.8;
        scale = [1, 1, 1];
        settings = [2, 2, radius, Math.max(0, height / 2)];
      }
      updateObject(item, collider.position || [0, 0, 0], scale, collider.rotation || 0, linearColor(collider.color, '#547b85'), settings, collider.pitch || 0, collider.orientation);
      (collider.wireframe ? wire : solid).push(item);
    }
    for (const [key, item] of colliderObjects) {
      if (!active.has(key)) { release(item.uniform); colliderObjects.delete(key); }
    }
    return { solid, wire };
  }

  function updateOverlay(camera, rigJoints, grab) {
    const vertices = [];
    const { right, up } = cameraBasis(camera);
    const line = (a, b, color) => vertices.push(...a, ...color, ...b, ...color);
    const ring = (center, radius, color) => {
      for (let i = 0; i < 24; i++) {
        const point = (angle) => center.map((v, j) => v + radius * (right[j] * Math.cos(angle) + up[j] * Math.sin(angle)));
        line(point(i / 24 * TAU), point((i + 1) / 24 * TAU), color);
      }
    };
    if (rigJoints) {
      for (const joint of rigJoints) {
        const position = joint.position;
        if (!position) continue;
        const color = joint.selected ? [1, 0.76, 0.38, 1] : [0.36, 0.91, 0.85, 0.84];
        const parent = typeof joint.parent === 'number' && joint.parent >= 0 ? rigJoints[joint.parent] : null;
        if (parent?.position) line(position, parent.position, [0.36, 0.91, 0.85, 0.48]);
        ring(position, joint.selected ? 0.015 : 0.01, color);
      }
    }
    if (grab?.position) {
      ring(grab.position, 0.022, [1, 0.78, 0.39, 1]);
      if (grab.target) {
        line(grab.position, grab.target, [1, 0.78, 0.39, 0.85]);
        ring(grab.target, 0.012, [1, 0.87, 0.59, 1]);
      }
    }
    const maxFloats = Math.floor(overlayBuffer.size / (14 * 4)) * 14;
    const data = new Float32Array(vertices.slice(0, maxFloats));
    if (data.length) device.queue.writeBuffer(overlayBuffer, 0, data);
    return data.length / 7;
  }

  function render({ camera, appearance = {}, colliders = [], wireframe = false, rigJoints = null, grab = null, showGround:groundOption, ragdollShapes:ragdollOption }) {
    if (disposed) return;
    resize();
    const showGround = groundOption??appearance.showGround!==false;
    updateRagdollShapes(ragdollOption??[]);
    const eye = getCameraPosition(camera);
    const viewProjection = multiply(perspective(camera.fov, width / height, 0.02, 120), lookAt(eye, camera.target));
    frameData.set(viewProjection, 0);
    frameData.set(lightMatrix, 16);
    frameData.set([...eye, 1], 32);
    frameData.set([...lightDirection, 0], 36);
    frameData.set([...linearColor(appearance.skin, '#c59576'), 1], 40);
    frameData.set([...linearColor(appearance.eyes, '#526e66'), 1], 44);
    frameData.set([...linearColor(appearance.lips, '#925750'), 1], 48);
    frameData.set([...linearColor(appearance.boxers, '#2c5b62'), 1], 52);
    frameData.set([appearance.beard ? 1 : 0, appearance.faceShading === 'pixel' ? 1 : 0, appearance.roughness ?? 0.7, 0], 56);
    const headCenter = meshMetadata.headCenter || [0, 1.68, 0];
    const headSize = meshMetadata.headSize || [0.12, 0.16, 0.11];
    const scale = (meshMetadata.height ?? 1.9) / 1.9;
    const landmarks = meshMetadata.appearance || {};
    const neckBaseY = landmarks.neckBaseY ?? headCenter[1] - headSize[1] * 1.4;
    const shoulderY = landmarks.shoulderY ?? neckBaseY;
    frameData.set([...headCenter, meshMetadata.bodyWeights?.fat??0], 60);
    frameData.set([...headSize, 0], 64);
    frameData.set([meshMetadata.boxerMin ?? 0.78, meshMetadata.boxerMax ?? 1.04, meshMetadata.height ?? 1.9, 0], 68);
    frameData.set([width, height, 1 / width, 1 / height], 72);
    frameData.set([...linearColor(appearance.hairColor, '#282321'), appearance.scalpHair !== false ? 1 : 0], 76);
    frameData.set([...linearColor(appearance.topColor, '#647c87'), appearance.eyesClosed !== false ? 1 : 0], 80);
    frameData.set([...linearColor(appearance.bottomColor, '#344852'), appearance.clothing === 'tshirt' ? 1 : appearance.clothing === 'jacket' ? 2 : 0], 84);
    frameData.set([neckBaseY, shoulderY, landmarks.shoulderHalfWidth ?? 0.265 * scale, 0], 88);
    frameData.set([landmarks.wristY ?? 0.97 * scale, landmarks.ankleY ?? 0.11 * scale,
      landmarks.hipHalfWidth ?? 0.25 * scale, landmarks.elbowY ?? 1.23 * scale], 92);
    frameData.set([landmarks.chestHalfWidth ?? 0.105 * scale, landmarks.chestY ?? shoulderY - 0.16 * scale,
      landmarks.chestFrontZ ?? 0.13 * scale, 0.0036 * scale], 96);
    const face = meshMetadata.faceLandmarks || {};
    const eyeY = face.eyeY ?? headCenter[1] + headSize[1] * 0.12;
    const noseY = face.noseY ?? headCenter[1] - headSize[1] * 0.205;
    frameData.set([eyeY, face.mouthY ?? headCenter[1] - headSize[1] * 0.365,
      noseY, face.browY ?? eyeY + headSize[1] * 0.18], 100);
    frameData.set([face.chinY ?? headCenter[1] - headSize[1] * 0.90,
      face.earY ?? (eyeY + noseY) * 0.5, face.earZ ?? headCenter[2] - headSize[2] * 0.035, 0], 104);
    frameData.set([...linearColor(appearance.interior, '#571d25'), appearance.seamOpen > 0 ? 1 : 0], 108);
    frameData.set([...linearColor(appearance.seam, '#92989c'), 0], 112);
    device.queue.writeBuffer(frameBuffer, 0, frameData);
    updateBodyPaint(appearance);
    const ragdollColliders = ragdollColliderCache;
    ragdollColliders.length = ragdollShapes.length;
    for (let index = 0; index < ragdollShapes.length; index++) {
      const body = ragdollShapes[index], shape = body.shape || body;
      let item = ragdollColliders[index];
      if (!item) item = ragdollColliders[index] = { wireframe: true };
      item.type = shape.type; item.radius = shape.radius; item.height = shape.height; item.size = shape.size;
      item.position = body.position || shape.position; item.orientation = body.orientation || shape.orientation;
      item.color = body.color || shape.color || '#9fdbc9';
      item.id = `ragdoll:${body.id ?? body.name ?? index}`;
    }
    const { solid:objects, wire:ragdollWire } = updateColliders([...colliders, ...ragdollColliders]);
    const overlayCount = updateOverlay(camera, rigJoints, grab);
    const encoder = device.createCommandEncoder({ label: 'Cloth studio frame' });
    const shadowPass = encoder.beginRenderPass({ label: 'Shadow depth pass', colorAttachments: [], depthStencilAttachment: { view: shadowView, depthClearValue: 1, depthLoadOp: 'clear', depthStoreOp: 'store' } });
    shadowPass.setPipeline(shadowPipeline);
    shadowPass.setBindGroup(0, frameGroup);
    const draw = (pass, item) => {
      pass.setBindGroup(1, item.bindGroup);
      pass.setIndexBuffer(item.shape.indices, 'uint32');
      pass.drawIndexed(item.shape.count);
    };
    if (body) draw(shadowPass, body);
    for (const item of objects) draw(shadowPass, item);
    shadowPass.end();
    const pass = encoder.beginRenderPass({
      label: 'Antialiased studio viewport',
      colorAttachments: [{ view: colorView, resolveTarget: context.getCurrentTexture().createView(), clearValue: showGround ? { r: 0.03, g: 0.05, b: 0.075, a: 1 } : { r: 0, g: 0, b: 0, a: 1 }, loadOp: 'clear', storeOp: 'discard' }],
      depthStencilAttachment: { view: depthView, depthClearValue: 1, depthLoadOp: 'clear', depthStoreOp: 'discard' },
    });
    if (showGround) {
      pass.setPipeline(backgroundPipeline);
      pass.setBindGroup(0, frameGroup);
      pass.draw(3);
    }
    pass.setPipeline(mainPipeline);
    pass.setBindGroup(0, frameGroup);
    pass.setBindGroup(2, shadowGroup);
    pass.setBindGroup(3, bodyPaintGroup);
    if (showGround) draw(pass, floor);
    for (const item of objects) draw(pass, item);
    if (body) draw(pass, body);
    if (wireframe && body) {
      pass.setPipeline(wirePipeline);
      pass.setBindGroup(1, body.bindGroup);
      pass.setIndexBuffer(wireBuffer, 'uint32');
      pass.drawIndexed(wireCount);
    }
    if (ragdollWire.length) {
      pass.setPipeline(ragdollWirePipeline);
      for (const item of ragdollWire) {
        pass.setBindGroup(1, item.bindGroup); pass.setIndexBuffer(item.shape.wireIndices, 'uint32'); pass.drawIndexed(item.shape.wireCount);
      }
    }
    if (overlayCount) {
      pass.setPipeline(overlayPipeline);
      pass.setBindGroup(0, frameGroup);
      pass.setVertexBuffer(0, overlayBuffer);
      pass.draw(overlayCount);
    }
    pass.end();
    device.queue.submit([encoder.finish()]);
  }

  function destroy() {
    if (disposed) return;
    disposed = true;
    for (const resource of ownedBuffers) resource.destroy();
    ownedBuffers.clear();
    colliderObjects.clear();
    shadowTexture.destroy();
    bodyPaintTexture?.destroy();
    bodyDetailTexture.destroy();
    depthTexture?.destroy();
    colorTexture?.destroy();
    context.unconfigure();
  }

  return { setMesh, render, resize, updateRagdollShapes, destroy, get bodyPaintUpdates() { return bodyPaintUpdates; } };
}
