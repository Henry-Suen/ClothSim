export const COLLIDER_KINDS = ['chair', 'sofa', 'box', 'sphere', 'capsule'];
export function createObject(kind, id) {
  if (!COLLIDER_KINDS.includes(kind)) throw new Error('Unknown collider type');
  return { id, kind, position: [kind === 'chair' || kind === 'sofa' ? 0 : .65, 0, -.55], rotation: 0, scale: 1 };
}

export function expandColliders(objects) {
  const result = [];
  for (const object of objects) {
    const s = object.scale, [ox, oy, oz] = object.position;
    const angle = object.rotation * Math.PI / 180, c = Math.cos(angle), n = Math.sin(angle);
    const add = (type, p, size, color, extra = {}) => {
      const x = p[0] * s, z = p[2] * s;
      result.push({ id: `${object.id}-${result.length}`, objectId: object.id, type,
        position: [ox + x * c + z * n, oy + p[1] * s, oz - x * n + z * c],
        size: size.map(v => v * s), rotation: angle, color,
        ...Object.fromEntries(Object.entries(extra).map(([k,v]) => [k, typeof v === 'number' && k !== 'pitch' ? v * s : v])) });
    };
    if (object.kind === 'chair') {
      add('box', [0,.47,0], [.52,.09,.52], '#527570');
      add('box', [0,.775,-.205], [.52,.56,.09], '#527570', { pitch: -12 * Math.PI / 180 });
      for (const x of [-.2,.2]) for (const z of [-.2,.2]) add('box', [x,.215,z], [.045,.43,.045], '#34464b');
    } else if (object.kind === 'sofa') {
      add('box', [0,.22,0], [1.6,.32,.72], '#354e61');
      add('box', [0,.43,.035], [1.36,.12,.58], '#688c92');
      add('box', [0,.69,-.26], [1.6,.6,.18], '#486b75', { pitch: -10 * Math.PI / 180 });
      for (const x of [-.74,.74]) add('box', [x,.52,0], [.16,.4,.72], '#527984');
    } else if (object.kind === 'box') add('box', [0,.225,0], [.45,.45,.45], '#9d8064');
    else if (object.kind === 'sphere') add('sphere', [0,.24,0], [.48,.48,.48], '#a78161', { radius: .24 });
    else add('capsule', [0,.4,0], [.3,.8,.3], '#8a7796', { radius: .15, height: .5 });
  }
  return result;
}

export function rayColliderDistance(origin, direction, colliders) {
  let best = Infinity;
  for (const c of colliders) {
    const co = Math.cos(c.rotation || 0), si = Math.sin(c.rotation || 0);
    const cp = Math.cos(c.pitch || 0), sp = Math.sin(c.pitch || 0);
    const q = origin.map((v,i) => v-c.position[i]);
    const yawO = [co*q[0]-si*q[2],q[1],si*q[0]+co*q[2]];
    const yawD = [co*direction[0]-si*direction[2],direction[1],si*direction[0]+co*direction[2]];
    const o = [yawO[0],cp*yawO[1]+sp*yawO[2],-sp*yawO[1]+cp*yawO[2]];
    const d = [yawD[0],cp*yawD[1]+sp*yawD[2],-sp*yawD[1]+cp*yawD[2]];
    if (c.type === 'sphere') {
      const b = o.reduce((v,x,i)=>v+x*d[i],0), k=o.reduce((v,x)=>v+x*x,0)-c.radius*c.radius, disc=b*b-k;
      if (disc>=0) { const t=-b-Math.sqrt(disc); if(t>0) best=Math.min(best,t); }
    } else if(c.type==='box') {
      let lo=0,hi=Infinity;
      for(let i=0;i<3;i++) { const h=c.size[i]/2; if(Math.abs(d[i])<1e-8){if(Math.abs(o[i])>h){hi=-1;break;}} else {let a=(-h-o[i])/d[i],b=(h-o[i])/d[i];if(a>b)[a,b]=[b,a];lo=Math.max(lo,a);hi=Math.min(hi,b);} }
      if(hi>=lo)best=Math.min(best,lo);
    } else {
      let t=0;
      for(let i=0;i<64 && t<20;i++) { const p=o.map((v,j)=>v+d[j]*t);const yy=p[1]-Math.max(-c.height/2,Math.min(c.height/2,p[1]));const sd=Math.hypot(p[0],yy,p[2])-c.radius;if(sd<.0005){best=Math.min(best,t);break;}t+=sd; }
    }
  }
  if(direction[1]<-1e-8){const t=-origin[1]/direction[1];if(t>=0)best=Math.min(best,t);}
  return best;
}
