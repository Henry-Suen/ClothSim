struct Parameters {
  counts: vec4<u32>,
  offsets: vec4<u32>,
  scratch: vec4<u32>,
  control: vec4<f32>,
  material: vec4<f32>,
  cloth: vec4<f32>,
  sceneInfo: vec4<u32>,
  grabPoint: vec4<f32>,
  grabBary: vec4<f32>,
  resetOffset: vec4<f32>,
  rayOrigin: vec4<f32>,
  rayDirection: vec4<f32>,
  settings: vec4<f32>,
}
struct Vertex {
  rest: vec4<f32>,
  previous: vec4<f32>,
  velocity: vec4<f32>,
  skinned: vec4<f32>,
  boneIds: vec4<u32>,
  boneWeights: vec4<f32>,
  ranges: vec4<u32>,
  contact: vec4<f32>,
  gradient: vec4<f32>,
  baseNormal: vec4<f32>,
}
struct Constraint {
  ids: vec4<u32>,
  rest: f32,
  kind: u32,
  lambda: f32,
  spare: f32,
  deltaA: vec4<f32>,
  deltaB: vec4<f32>,
  deltaC: vec4<f32>,
  deltaD: vec4<f32>,
}
@group(0) @binding(0) var<uniform> params: Parameters;
@group(0) @binding(1) var<storage, read_write> positions: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> normals: array<vec4<f32>>;
@group(0) @binding(3) var<storage, read_write> vertices: array<Vertex>;
@group(0) @binding(4) var<storage, read_write> constraints: array<Constraint>;
@group(0) @binding(5) var<storage, read> topology: array<u32>;
@group(0) @binding(6) var<storage, read> scene: array<vec4<f32>>;
@group(0) @binding(7) var<storage, read_write> scratch: array<atomic<u32>>;

fn invMass(index: u32) -> f32 {
  return 1.0 / max(vertices[index].rest.w * params.cloth.y, 0.000001);
}
fn safeNormal(v: vec3<f32>) -> vec3<f32> {
  return v * inverseSqrt(max(dot(v, v), 1e-18));
}
fn bounded(v: vec3<f32>, maximum: f32) -> vec3<f32> {
  return v * min(1.0, maximum * inverseSqrt(max(dot(v, v), 1e-18)));
}
fn getFloat(index: u32) -> f32 {
  return bitcast<f32>(atomicLoad(&scratch[index]));
}
fn putFloat(index: u32, value: f32) {
  atomicStore(&scratch[index], bitcast<u32>(value));
}
fn skinPoint(index: u32) -> vec3<f32> {
  let point = vec4<f32>(vertices[index].rest.xyz, 1.0);
  var result = vec4<f32>(0.0);
  for (var k = 0u; k < 4u; k++) {
    let bone = min(vertices[index].boneIds[k], params.sceneInfo.x - 1u) * 4u;
    let matrix = mat4x4<f32>(scene[bone], scene[bone + 1u], scene[bone + 2u], scene[bone + 3u]);
    result += (matrix * point) * vertices[index].boneWeights[k];
  }
  return result.xyz;
}
fn triangle(index: u32) -> vec3<u32> {
  let start = params.offsets.y + index * 3u;
  return vec3<u32>(topology[start], topology[start + 1u], topology[start + 2u]);
}
fn cellOf(point: vec3<f32>) -> vec3<i32> {
  return vec3<i32>(floor(point / max(2.0 * params.cloth.x, 0.006)));
}
fn hashCell(cell: vec3<i32>) -> u32 {
  let c = bitcast<vec3<u32>>(cell);
  return ((c.x * 73856093u) ^ (c.y * 19349663u) ^ (c.z * 83492791u)) & params.counts.w;
}
fn connected(a: u32, b: u32) -> bool {
  let range = vertices[a].ranges;
  for (var j = 0u; j < range.y; j++) {
    let encoded = topology[range.x + j];
    let link = constraints[encoded >> 2u];
    if (link.kind != 2u || params.control.w > 0.01) {
      if (link.ids.x == b || link.ids.y == b || (link.kind == 1u && (link.ids.z == b || link.ids.w == b))) {
        return true;
      }
    }
  }
  return false;
}

@compute @workgroup_size(128)
fn skin(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  vertices[i].skinned = vec4<f32>(skinPoint(i), 1.0);
}

@compute @workgroup_size(128)
fn reset(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i < params.counts.x) {
    var point = vertices[i].rest.xyz;
    if (params.resetOffset.w > 0.5) { point = skinPoint(i); }
    point += params.resetOffset.xyz;
    positions[i] = vec4<f32>(point, 1.0);
    vertices[i].previous = positions[i];
    vertices[i].skinned = vec4<f32>(skinPoint(i), 1.0);
    vertices[i].velocity = vec4<f32>(0.0);
    vertices[i].contact = vec4<f32>(0.0);
  }
  if (i < params.counts.y) { constraints[i].lambda = 0.0; }
  if (i == 0u) {
    putFloat(0u, params.cloth.w);
    putFloat(1u, 0.0);
    putFloat(2u, 0.0);
    atomicStore(&scratch[3u], 0u);
    putFloat(12u, 0.0);
  }
}

@compute @workgroup_size(128)
fn predict(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i < params.counts.y) { constraints[i].lambda = 0.0; }
  if (i == 0u) { putFloat(2u, 0.0); }
  if (i >= params.counts.x) { return; }
  let dt = params.control.x;
  let original = positions[i].xyz;
  vertices[i].previous = positions[i];
  vertices[i].contact = vec4<f32>(0.0);
  let velocity = bounded(vertices[i].velocity.xyz, 10.0) * exp(-params.material.z * dt);
  var displacement = velocity * dt + vec3<f32>(0.0, -9.81, 0.0) * dt * dt;
  if (params.control.w > 0.999 && params.control.z > 0.001 && getFloat(12u) < params.cloth.x * 2.0) {
    let desired = params.cloth.w * params.control.z;
    let deficit = clamp(1.0 - getFloat(0u) / max(desired, 1e-6), 0.0, 1.0);
    let force = normals[i].xyz * vertices[i].rest.w * invMass(i) * params.cloth.z * 8.0 * params.control.z * deficit;
    displacement += bounded(force * dt * dt, 0.002);
  }
  positions[i] = vec4<f32>(original + bounded(displacement, 0.035), 1.0);
}

@compute @workgroup_size(128)
fn solveConstraints(@builtin(global_invocation_id) gid: vec3<u32>) {
  let index = gid.x;
  if (index >= params.counts.y) { return; }
  var link = constraints[index];
  link.deltaA = vec4<f32>(0.0);
  link.deltaB = vec4<f32>(0.0);
  link.deltaC = vec4<f32>(0.0);
  link.deltaD = vec4<f32>(0.0);
  if (link.kind == 2u && params.control.w < 0.001) {
    link.lambda = 0.0;
    constraints[index] = link;
    return;
  }
  let a = link.ids.x;
  let b = link.ids.y;
  let pa = positions[a].xyz;
  let pb = positions[b].xyz;
  let wa = invMass(a);
  let wb = invMass(b);
  let dt = params.control.x;
  var compliance = params.material.x;
  var error = 0.0;
  var ga = vec3<f32>(0.0);
  var gb = vec3<f32>(0.0);
  var gc = vec3<f32>(0.0);
  var gd = vec3<f32>(0.0);
  var wc = 0.0;
  var wd = 0.0;
  var degree = max(vertices[a].ranges.y, vertices[b].ranges.y);
  if (link.kind == 1u) {
    let c = link.ids.z;
    let d = link.ids.w;
    let pc = positions[c].xyz;
    let pd = positions[d].xyz;
    let edge = pb - pa;
    let edge2 = dot(edge, edge);
    let n1raw = cross(edge, pc - pa);
    let n2raw = cross(pd - pa, edge);
    let area1 = length(n1raw);
    let area2 = length(n2raw);
    if (edge2 < 1e-12 || area1 < 1e-9 || area2 < 1e-9) {
      constraints[index] = link;
      return;
    }
    let edgeLength = sqrt(edge2);
    let n1 = n1raw / area1;
    let n2 = n2raw / area2;
    let angle = atan2(dot(cross(n1, n2), edge / edgeLength), clamp(dot(n1, n2), -1.0, 1.0));
    error = angle - link.rest;
    error -= 6.28318530718 * floor((error + 3.14159265359) / 6.28318530718);
    gc = -n1 * edgeLength / area1;
    gd = -n2 * edgeLength / area2;
    gb = -(dot(pc - pa, edge) / edge2) * gc - (dot(pd - pa, edge) / edge2) * gd;
    ga = -gb - gc - gd;
    wc = invMass(c);
    wd = invMass(d);
    degree = max(degree, max(vertices[c].ranges.y, vertices[d].ranges.y));
    compliance = params.material.y / max(link.spare, 1e-6);
  } else {
    let difference = pa - pb;
    let distance = length(difference);
    ga = safeNormal(difference);
    gb = -ga;
    error = distance - link.rest;
    if (link.kind == 2u) {
      compliance = params.material.x + pow(1.0 - params.control.w, 3.0) * 0.02;
    }
  }
  let alpha = compliance / (dt * dt);
  let denominator = wa * dot(ga, ga) + wb * dot(gb, gb) + wc * dot(gc, gc) + wd * dot(gd, gd) + alpha;
  var deltaLambda = (-error - alpha * link.lambda) / max(denominator, 1e-10);
  deltaLambda *= min(0.9, 3.0 / f32(max(degree, 1u)));
  let maxDisplacement = max(max(length(ga) * wa, length(gb) * wb), max(length(gc) * wc, length(gd) * wd)) * abs(deltaLambda);
  deltaLambda *= min(1.0, 0.008 / max(maxDisplacement, 1e-10));
  link.lambda += deltaLambda;
  link.deltaA = vec4<f32>(wa * deltaLambda * ga, 0.0);
  link.deltaB = vec4<f32>(wb * deltaLambda * gb, 0.0);
  link.deltaC = vec4<f32>(wc * deltaLambda * gc, 0.0);
  link.deltaD = vec4<f32>(wd * deltaLambda * gd, 0.0);
  constraints[index] = link;
}

@compute @workgroup_size(128)
fn gatherConstraints(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  let range = vertices[i].ranges;
  var correction = vec3<f32>(0.0);
  for (var k = 0u; k < range.y; k++) {
    let entry = topology[range.x + k];
    let link = constraints[entry >> 2u];
    switch (entry & 3u) {
      case 0u: { correction += link.deltaA.xyz; }
      case 1u: { correction += link.deltaB.xyz; }
      case 2u: { correction += link.deltaC.xyz; }
      default: { correction += link.deltaD.xyz; }
    }
  }
  positions[i] = vec4<f32>(positions[i].xyz + bounded(correction, 0.015), 1.0);
}

var<workgroup> volumeValues: array<f32, 128>;
var<workgroup> gradientValues: array<f32, 128>;
var<workgroup> seamValues: array<f32, 128>;
@compute @workgroup_size(128)
fn volumePartial(@builtin(global_invocation_id) gid: vec3<u32>, @builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
  let i = gid.x;
  var value = 0.0;
  var gradient = vec3<f32>(0.0);
  var area = 0.0;
  var denominator = 0.0;
  var seamGap = 0.0;
  if (i < params.counts.x) {
    let range = vertices[i].ranges;
    if (params.settings.y > 0.5) {
      for (var k = 0u; k < range.y; k++) {
        let link = constraints[topology[range.x + k] >> 2u];
        if (link.kind == 2u) {
          seamGap = max(seamGap, distance(positions[link.ids.x].xyz, positions[link.ids.y].xyz));
        }
      }
    }
    for (var k = 0u; k < range.w; k++) {
      let ids = triangle(topology[range.z + k]);
      let a = positions[ids.x].xyz;
      let b = positions[ids.y].xyz;
      let c = positions[ids.z].xyz;
      value += dot(a, cross(b, c)) / 18.0;
      area += length(cross(b - a, c - a)) / 6.0;
      if (i == ids.x) { gradient += cross(b, c) / 6.0; }
      if (i == ids.y) { gradient += cross(c, a) / 6.0; }
      if (i == ids.z) { gradient += cross(a, b) / 6.0; }
    }
    gradient *= params.settings.x;
    vertices[i].gradient = vec4<f32>(gradient, area);
    denominator = invMass(i) * dot(gradient, gradient);
  }
  volumeValues[lid.x] = value * params.settings.x;
  gradientValues[lid.x] = denominator;
  seamValues[lid.x] = seamGap;
  workgroupBarrier();
  for (var stride = 64u; stride > 0u; stride >>= 1u) {
    if (lid.x < stride) {
      volumeValues[lid.x] += volumeValues[lid.x + stride];
      gradientValues[lid.x] += gradientValues[lid.x + stride];
      seamValues[lid.x] = max(seamValues[lid.x], seamValues[lid.x + stride]);
    }
    workgroupBarrier();
  }
  if (lid.x == 0u) {
    putFloat(params.scratch.x + wid.x * 3u, volumeValues[0]);
    putFloat(params.scratch.x + wid.x * 3u + 1u, gradientValues[0]);
    putFloat(params.scratch.x + wid.x * 3u + 2u, seamValues[0]);
  }
}

@compute @workgroup_size(1)
fn volumeFinish() {
  var volume = 0.0;
  var denominator = 0.0;
  var seamGap = 0.0;
  for (var k = 0u; k < params.scratch.y; k++) {
    volume += getFloat(params.scratch.x + k * 3u);
    denominator += getFloat(params.scratch.x + k * 3u + 1u);
    seamGap = max(seamGap, getFloat(params.scratch.x + k * 3u + 2u));
  }
  putFloat(0u, volume);
  putFloat(12u, seamGap);
  var deltaLambda = 0.0;
  if (params.control.w > 0.999 && params.control.z > 0.001 && params.cloth.z > 0.001 && seamGap < params.cloth.x * 2.0) {
    let dt = params.control.x;
    let alpha = 0.0000002 / (max(params.cloth.z, 0.001) * dt * dt);
    let error = volume - params.cloth.w * params.control.z;
    let oldLambda = getFloat(2u);
    deltaLambda = (-error - alpha * oldLambda) / max(denominator + alpha, 1e-10);
    deltaLambda = clamp(deltaLambda, -0.05, 0.05);
    putFloat(2u, oldLambda + deltaLambda);
  }
  putFloat(1u, deltaLambda);
}

@compute @workgroup_size(128)
fn applyVolume(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  let change = invMass(i) * getFloat(1u) * vertices[i].gradient.xyz;
  positions[i] = vec4<f32>(positions[i].xyz + bounded(change, 0.004), 1.0);
}

@compute @workgroup_size(128)
fn hashClear(@builtin(global_invocation_id) gid: vec3<u32>) {
  if (gid.x <= params.counts.w) { atomicStore(&scratch[params.scratch.w + gid.x], 0u); }
  if (gid.x == 0u) { atomicStore(&scratch[3u], 0u); }
}
@compute @workgroup_size(128)
fn hashBuild(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  let bucket = hashCell(cellOf(positions[i].xyz));
  let slot = atomicAdd(&scratch[params.scratch.w + bucket], 1u);
  if (slot < params.scratch.z) {
    atomicStore(&scratch[params.offsets.w + bucket * params.scratch.z + slot], i);
  } else {
    atomicAdd(&scratch[3u], 1u);
  }
}

@compute @workgroup_size(128)
fn contacts(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  let point = positions[i].xyz;
  let thickness = params.cloth.x;
  let separation = 2.0 * thickness;
  let cell = cellOf(point);
  var selfDelta = vec3<f32>(0.0);
  var hits = 0.0;
  for (var z = -1; z <= 1; z++) {
    for (var y = -1; y <= 1; y++) {
      for (var x = -1; x <= 1; x++) {
        let neighborCell = cell + vec3<i32>(x, y, z);
        let bucket = hashCell(neighborCell);
        let count = min(atomicLoad(&scratch[params.scratch.w + bucket]), params.scratch.z);
        for (var k = 0u; k < count; k++) {
          let other = atomicLoad(&scratch[params.offsets.w + bucket * params.scratch.z + k]);
          if (other == i) { continue; }
          let otherPoint = positions[other].xyz;
          if (any(cellOf(otherPoint) != neighborCell)) { continue; }
          let difference = point - otherPoint;
          let distance2 = dot(difference, difference);
          if (distance2 >= separation * separation || connected(i, other)) { continue; }
          let distance = sqrt(max(distance2, 1e-14));
          var direction = difference / distance;
          if (distance2 < 1e-12) {
            direction = safeNormal(vertices[i].rest.xyz - vertices[other].rest.xyz);
            if (dot(direction, direction) < 0.1) {
              direction = vec3<f32>(select(-1.0, 1.0, i > other), 0.0, 0.0);
            }
          }
          let weight = invMass(i) / (invMass(i) + invMass(other));
          selfDelta += direction * (separation - distance) * weight;
          hits += 1.0;
        }
      }
    }
  }
  var candidate = point + selfDelta / max(hits, 1.0) * 0.85;
  var contactNormal = vec3<f32>(0.0);
  if (candidate.y < thickness) {
    candidate.y = thickness;
    contactNormal += vec3<f32>(0.0, 1.0, 0.0);
  }
  for (var k = 0u; k < params.sceneInfo.y; k++) {
    let base = params.sceneInfo.z + k * 3u;
    let objectPosition = scene[base];
    let shape = scene[base + 1u];
    let rotation = scene[base + 2u];
    let relative = candidate - objectPosition.xyz;
    let local = vec3<f32>(rotation.x * relative.x - rotation.y * relative.z, relative.y, rotation.y * relative.x + rotation.x * relative.z);
    var localNormal = vec3<f32>(0.0);
    var penetration = 0.0;
    if (objectPosition.w < 0.5) {
      let q = abs(local) - shape.xyz;
      let outside = max(q, vec3<f32>(0.0));
      let signedDistance = length(outside) + min(max(q.x, max(q.y, q.z)), 0.0);
      penetration = thickness - signedDistance;
      if (length(outside) > 1e-8) {
        localNormal = safeNormal(outside * sign(local));
      } else if (q.x >= q.y && q.x >= q.z) {
        localNormal = vec3<f32>(select(-1.0, 1.0, local.x >= 0.0), 0.0, 0.0);
      } else if (q.y >= q.z) {
        localNormal = vec3<f32>(0.0, select(-1.0, 1.0, local.y >= 0.0), 0.0);
      } else {
        localNormal = vec3<f32>(0.0, 0.0, select(-1.0, 1.0, local.z >= 0.0));
      }
    } else {
      var delta = local;
      if (objectPosition.w > 1.5) { delta.y -= clamp(delta.y, -rotation.z, rotation.z); }
      let distance = length(delta);
      localNormal = safeNormal(delta);
      if (distance < 1e-8) { localNormal = vec3<f32>(0.0, 1.0, 0.0); }
      penetration = shape.w + thickness - distance;
    }
    if (penetration > 0.0) {
      let worldNormal = vec3<f32>(rotation.x * localNormal.x + rotation.y * localNormal.z, localNormal.y, -rotation.y * localNormal.x + rotation.x * localNormal.z);
      candidate += worldNormal * penetration;
      contactNormal += worldNormal;
    }
  }
  vertices[i].contact = vec4<f32>(candidate - point, select(0.0, 1.0, hits > 0.0 || dot(contactNormal, contactNormal) > 0.0));
  vertices[i].gradient = vec4<f32>(safeNormal(contactNormal), 0.0);
}

@compute @workgroup_size(128)
fn applyContacts(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  positions[i] = vec4<f32>(positions[i].xyz + vertices[i].contact.xyz, 1.0);
}

@compute @workgroup_size(128)
fn attachments(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  var point = positions[i].xyz;
  let influence = params.control.y;
  let stiffness = 1.0 - exp(-influence * influence * 1000.0 * params.control.x);
  point += bounded((vertices[i].skinned.xyz - point) * stiffness, 0.018);
  if (params.sceneInfo.w < params.counts.z && params.grabPoint.w > 0.0) {
    let ids = triangle(params.sceneInfo.w);
    var bary = 0.0;
    if (i == ids.x) { bary = params.grabBary.x; }
    if (i == ids.y) { bary = params.grabBary.y; }
    if (i == ids.z) { bary = params.grabBary.z; }
    let grabbed = positions[ids.x].xyz * params.grabBary.x + positions[ids.y].xyz * params.grabBary.y + positions[ids.z].xyz * params.grabBary.z;
    let denominator = invMass(ids.x) * params.grabBary.x * params.grabBary.x + invMass(ids.y) * params.grabBary.y * params.grabBary.y + invMass(ids.z) * params.grabBary.z * params.grabBary.z;
    let correction = (params.grabPoint.xyz - grabbed) * bary * invMass(i) / max(denominator, 1e-8) * params.grabPoint.w;
    point += bounded(correction, 0.02);
  }
  vertices[i].contact = vec4<f32>(point - positions[i].xyz, 0.0);
}

@compute @workgroup_size(128)
fn finish(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  var velocity = (positions[i].xyz - vertices[i].previous.xyz) / params.control.x;
  if (vertices[i].contact.w > 0.5) {
    let normal = vertices[i].gradient.xyz;
    let normalVelocity = normal * max(dot(velocity, normal), 0.0);
    velocity = normalVelocity + (velocity - normal * dot(velocity, normal)) * (1.0 - params.material.w);
  }
  vertices[i].velocity = vec4<f32>(bounded(velocity, 10.0), 0.0);
}

@compute @workgroup_size(128)
fn updateNormals(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= params.counts.x) { return; }
  let range = vertices[i].ranges;
  var normal = vec3<f32>(0.0);
  for (var k = 0u; k < range.w; k++) {
    let ids = triangle(topology[range.z + k]);
    normal += cross(positions[ids.y].xyz - positions[ids.x].xyz, positions[ids.z].xyz - positions[ids.x].xyz);
  }
  normal = safeNormal(normal) * params.settings.x;
  if (dot(normal, normal) < 0.1) { normal = vertices[i].baseNormal.xyz; }
  normals[i] = vec4<f32>(normal, 0.0);
}

var<workgroup> pickDistances: array<f32, 128>;
var<workgroup> pickTriangles: array<u32, 128>;
var<workgroup> pickBarys: array<vec2<f32>, 128>;
@compute @workgroup_size(128)
fn pickPartial(@builtin(global_invocation_id) gid: vec3<u32>, @builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
  let i = gid.x;
  var distance = 1e30;
  var bary = vec2<f32>(0.0);
  if (i < params.counts.z) {
    let ids = triangle(i);
    let a = positions[ids.x].xyz;
    let edge1 = positions[ids.y].xyz - a;
    let edge2 = positions[ids.z].xyz - a;
    let p = cross(params.rayDirection.xyz, edge2);
    let determinant = dot(edge1, p);
    if (abs(determinant) > 1e-10) {
      let inverse = 1.0 / determinant;
      let t = params.rayOrigin.xyz - a;
      let u = dot(t, p) * inverse;
      let q = cross(t, edge1);
      let v = dot(params.rayDirection.xyz, q) * inverse;
      let hitDistance = dot(edge2, q) * inverse;
      if (u >= 0.0 && v >= 0.0 && u + v <= 1.0 && hitDistance > 0.0) {
        distance = hitDistance;
        bary = vec2<f32>(u, v);
      }
    }
  }
  pickDistances[lid.x] = distance;
  pickTriangles[lid.x] = i;
  pickBarys[lid.x] = bary;
  workgroupBarrier();
  for (var stride = 64u; stride > 0u; stride >>= 1u) {
    if (lid.x < stride && pickDistances[lid.x + stride] < pickDistances[lid.x]) {
      pickDistances[lid.x] = pickDistances[lid.x + stride];
      pickTriangles[lid.x] = pickTriangles[lid.x + stride];
      pickBarys[lid.x] = pickBarys[lid.x + stride];
    }
    workgroupBarrier();
  }
  if (lid.x == 0u) {
    let base = params.offsets.z + wid.x * 4u;
    putFloat(base, pickDistances[0]);
    atomicStore(&scratch[base + 1u], pickTriangles[0]);
    putFloat(base + 2u, pickBarys[0].x);
    putFloat(base + 3u, pickBarys[0].y);
  }
}
@compute @workgroup_size(1)
fn pickFinish() {
  var nearest = 1e30;
  var best = 0xffffffffu;
  let groups = (params.counts.z + 127u) / 128u;
  for (var k = 0u; k < groups; k++) {
    let base = params.offsets.z + k * 4u;
    let distance = getFloat(base);
    if (distance < nearest) { nearest = distance; best = base; }
  }
  putFloat(4u, nearest);
  atomicStore(&scratch[5u], 0xffffffffu);
  if (best != 0xffffffffu) {
    atomicStore(&scratch[5u], atomicLoad(&scratch[best + 1u]));
    atomicStore(&scratch[6u], atomicLoad(&scratch[best + 2u]));
    atomicStore(&scratch[7u], atomicLoad(&scratch[best + 3u]));
  }
}

@compute @workgroup_size(1)
fn diagnosticSummary() {
  var minimumY = 1e30;
  var maximumSpeed = 0.0;
  var finiteCount = 0u;
  var gap = 0.0;
  var seamCount = 0.0;
  for (var i = 0u; i < params.counts.x; i++) {
    let p = positions[i].xyz;
    if (all(abs(p) < vec3<f32>(1e10))) { finiteCount += 1u; }
    minimumY = min(minimumY, p.y);
    maximumSpeed = max(maximumSpeed, length(vertices[i].velocity.xyz));
  }
  for (var i = 0u; i < params.counts.y; i++) {
    let link = constraints[i];
    if (link.kind == 2u) {
      gap += distance(positions[link.ids.x].xyz, positions[link.ids.y].xyz);
      seamCount += 1.0;
    }
  }
  putFloat(8u, minimumY);
  putFloat(9u, maximumSpeed);
  atomicStore(&scratch[10u], finiteCount);
  putFloat(11u, gap / max(seamCount, 1.0));
}
